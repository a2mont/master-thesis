bool LoadMesh(const char *filename, int *numnodes, starreal **nodeptr, int *numtets, int **tetptr) {
  FILE *f = NULL;
  starreal (*nodes)[3] = NULL;
  int (*tets)[4] = NULL;
  char *nodename = NULL, *elename = NULL;

  bool result = false;
  int junk, bm, i;
  starreal x, y, z;
  
  printf("Loading files %s.{node/ele}\n", filename);
  
  /* Load .node file */
  nodename = (char*) malloc(strlen(filename) + 5 + 1);
  strcpy(nodename, filename);
  strcat(nodename, ".node");
  f = fopen(nodename, "r");
  
  if (!f) {
    printf("failed to open %s.\n", nodename);
    goto cleanup;
  }
  
  junk = fscanf(f, "%d %d %d %d", numnodes, &junk, &junk, &bm);
  
  nodes = (starreal (*)[3]) malloc(*numnodes * 3 * sizeof(starreal));
  
  if (!nodes) {
    printf("could not allocate memory for %d nodes.\n", *numnodes);
    goto cleanup;
  }
  
  printf("reading %d nodes.\n", *numnodes);
  
  for (i = 0; i < *numnodes; i++) {
    if (bm) {
      junk = fscanf(f, "%d %lf %lf %lf %d", &junk, &x, &y, &z, &junk);
    } else {
      junk = fscanf(f, "%d %lf %lf %lf", &junk, &x, &y, &z);
    }
    
    nodes[i][0] = x;
    nodes[i][1] = y;
    nodes[i][2] = z;
  }
  
  fclose(f);
  
  
  /* Load elements */
  elename = (char*) malloc(strlen(filename) + 4 + 1);
  strcpy(elename, filename);
  strcat(elename, ".ele");
  f = fopen(elename, "r");
  
  if (!f) {
    printf("failed to open %s.\n", elename);
    goto cleanup;
  }
  
  junk = fscanf(f,"%d %d %d", numtets, &junk, &bm);
  
  tets = (int (*)[4]) malloc(*numtets * 4 * sizeof(int));

  if (!tets) {
    printf("could not allocate memory for %d tets.\n", *numtets);
    goto cleanup;
  }
  
  printf("reading %d tets.\n", *numtets);
  
  for (i = 0; i < *numtets; i++) {
    if (bm) {
      junk = fscanf(f,"%d %d %d %d %d %d", &junk, &tets[i][0], &tets[i][1], &tets[i][2], &tets[i][3], &junk);
      /* sometimes, the mesh file stores tet vertices in a different order, this line inverts all tets on read */
      /* junk = fscanf(f,"%d %d %d %d %d %d", &junk, &tets[i][0], &tets[i][1], &tets[i][3], &tets[i][2], &junk); */      
    } else {
      junk = fscanf(f,"%d %d %d %d %d", &junk, &tets[i][0], &tets[i][1], &tets[i][2], &tets[i][3]);
      /* sometimes, the mesh file stores tet vertices in a different order, this line inverts all tets on read */
      /* junk = fscanf(f,"%d %d %d %d %d", &junk, &tets[i][0], &tets[i][1], &tets[i][3], &tets[i][2]); */      
    }
    
    /* convert to 0-based indexing */
    tets[i][0] = tets[i][0] - 1;
    tets[i][1] = tets[i][1] - 1;
    tets[i][2] = tets[i][2] - 1;
    tets[i][3] = tets[i][3] - 1;    
  }
    
    result = true;
  
cleanup:
  if (f)
    fclose(f); 
  if (nodename)
    free(nodename);
  if (elename)
    free(elename);
  
  if (result) {
    *nodeptr = (starreal *) nodes;
    *tetptr = (int *) tets;
  } else {
    if (nodes)
      free(nodes);
    if (tets)
      free(tets);
  }
    
  return result;
}


bool WriteMesh(const char *filename, int numnodes, const starreal nodes[][3], int numtets, const int tets[][4]) {
  FILE *f = NULL;
  char *nodename = NULL, *elename = NULL;
    int i;
  bool result = false;
  
  printf("Writing files %s.{node/ele}\n", filename);
  
  /* Write .node file */
  nodename = (char*) malloc(strlen(filename) + 5 + 1);
  strcpy(nodename, filename);
  strcat(nodename, ".node");
  f = fopen(nodename, "w");
  
  if (!f) 
  {
    printf("failed to open %s.\n", nodename);
    goto cleanup;
  }
    
  printf("writing %d nodes.\n", numnodes);
  
  fprintf(f, "%d 3 0 0\n", numnodes);
  for (i = 0; i < numnodes; ++i) 
  {
    fprintf(f, "%d  %.17g  %.17g  %.17g\n", i+1, nodes[i][0], nodes[i][1], nodes[i][2]);
  }
    
  fclose(f);
  
  
  /* Write elements */
  elename = (char*) malloc(strlen(filename) + 4 + 1);
  strcpy(elename, filename);
  strcat(elename, ".ele");
  f = fopen(elename, "w");
  
  if (!f) {
    printf("failed to open %s.\n", elename);
    goto cleanup;
  }
    
  printf("writing %d tets.\n", numtets);
  fprintf(f, "%d 4 0\n", numtets);
  for (i = 0; i < numtets; ++i) 
  {
    fprintf(f, "%d  %d  %d  %d  %d\n", i, tets[i][0], tets[i][1], tets[i][2], tets[i][3]);
  }
    
  result = true;
    
cleanup:
    
  if (f) 
    fclose(f);
  if (nodename)
    free(nodename);
  if (elename)
    free(elename);
    
    return result;
}

void classifyvertex(int vtag, const starreal vpoint[3], const starreal* vattr, struct vertextype* vtype) {
  /* we can change the classification of a vertex in here. The classification vtype determines how
   the vertex behaves during smoothing. If the vertex must remain fixed, set vtype->fixed to true. If
   the vertex may move on a segment or plane, set vtype->kind to SEGMENTVERTEX or FACETVERTEX, and 
   set vtype->vec to the segment direction or plane normal. */
}

bool progress(struct improvebehavior *improvebehave) {
  /* 
   progress callback. Can be used to update UI, or stop processing by returning false.
   */
    /* printf("*"); */
  return true;
}

void initialize_improvement_options(struct improvebehavior *b)
{
    int i;
    
    /* early termination: if minimum tetrahedron quality reaches this level, improvement will terminate. 
       A value of 1.0 implies that every tetrahedron be perfect, precluding early termination for static
       improvement and any termination at all for dynamic improvement. You should always set this value
       to a modest value less than one for reasonable performance in dynamic improvement. */
    b->goalquality = 1.0;
    
    /* quadric options */
    b->usequadrics = false;              /* use quadric smoothing of surface vertices */
    b->quadricoffset = 0.8;              /* quality to start every quadric at */
    b->quadricscale = 1200;              /* factor to scale quadric error by */
    b->sizecontractquadricscale = 10;    /* factor for scaling during sizing contraction passes */

    /* smoothing options */
    b->nonsmooth = true;                 /* enable non-smooth optimization-based smoothing */
    b->facetsmooth = true;               /* enable smoothing of facet vertices */
    b->segmentsmooth = true;             /* enable smoothing of segment vertices */
    b->cornersmooth = false;             /* enable smoothing of corner vertices */

    /* topological options */
    b->edgeremoval = true;               /* enable edge removal */
    b->edgecontraction = true;           /* enable edge contraction */
    b->boundedgeremoval = true;          /* enable boundary edge removal */
    b->singlefaceremoval = true;         /* enable single face removal (2-3 flips) */
    b->multifaceremoval = true;          /* enable multi face removal */
    b->flip22 = true;                    /* enable 2-2 flips */
    b->flip22volumetol = 0.09;           /* tolerance for volume change in 2-2 flips */
    b->flip22normaltol = 0.2;            /* tolerance for normal change in 2-2 flips */

    /* insertion options */
    b->enableinsert = true;              /* global enable of insertion */
    b->insertbody = true;                /* enable body vertex insertion */
    b->insertfacet = true;               /* enable facet insertion */
    b->insertsegment = true;             /* enable segment insertion */
    b->cavityconsiderdeleted = false;    /* consider enlarging cavity for deleted tets */
    b->cavdepthlimit = 6;                /* only allow initial cavity to includes tets this deep */

    /* sizing options */
    b->sizing = false;                   /* globally enable mesh element size control */
    b->sizingpass = false;               /* enable or disable initial edge length control */
    b->targetedgelength = 0.0;            /* edge length of the ideal edge for this mesh (0 = use initial mean) */
    b->longerfactor = 3.0;                /* factor by which an edge can be longer */
    b->shorterfactor = 0.33;             /* factor by which an edge can be shorter */

    /* edge length ratio control (overrides regular sizing) */
    b->dynsizing = false;                /* control edge length ratios instead of absolute lengths */
    b->minlengthratio = 0.1;             /* min tolerated ratio of minedgelength/maxedgelength */

    /* fine-tuning options */
    b->maxinsertquality = 0.0;   /* never attempt insertion in a tet better than this */

    /* for static improvement only */
    /* quality thresholds for averages */
    for (i = 0; i < NUMMEANTHRESHOLDS; ++i) 
        b->meanthresholds[i] = 0.7/NUMMEANTHRESHOLDS*i; 
    b->mininsertionimprovement = 0.001;  /* demand in improvement for insertion */
    b->minstepimprovement = 0.01;        /* demand at least this much improvement in the mean per step */
    b->insertthreshold = 0.03;           /* insertion into this percentage worst tets */

    /* verbosity & output */
    b->verbosity = 3;
    b->usecolor = true;

    /* callback functions */

    /* sizing tensor field. If NULL, defaults to identity */
    /* b->tensor_cb = &centertensor; */
    b->tensor_cb = NULL;

    /* quality evaluation for tets, must be non-NULL */
    b->quality_cb = &quality_warpedminsine;
    /* optimization information, must be non-NULL if smoothing is enabled */
    b->optinfo_cb = &optinfo_warpedminsine;

    /* classification callback for imposing constraints on the smoothing. Can be NULL. */
    b->classifyvertex_cb = &classifyvertex;

    /* called after each improved tet (for UI updates etc.), can be NULL. Return false to stop remeshing. */
    b->progress_cb = &progress;
}

/* set improvement options by reading them from a file */
void parseimproveconfig(char *filename, struct improvebehavior *b)
{
    char word[100]; /* variable name from config file */
    int value=0;      /* variable value from config file */
    starreal fvalue=0.0; /* variable for floats in config file */
    char str[100];
    char fstr[100];
    
    /* temp stuff for line reading */
    int nbytes = 1000;
    char line[1000];
    int numassigned;
    
    FILE *in = fopen(filename, "r");
    assert(in != NULL);
    
    /* read every line of the file */
    while (fgets(line, nbytes, in) != NULL)
    {
        /* attempt to fetch a variable name and value from the config file */
        numassigned = sscanf(line, "%s %d %s %s", word, &value, fstr, str);
        fvalue = atof(fstr);
        
        /* check if this is a comment */
        if (word[0] == '#' || word[0] == '\n' || numassigned <= 0) continue;
        
        if (false)
        {
            printf("line is '%s'\n", line);
            printf("just read variable %s with value int %d float %g string `%s'\n", word, value, fvalue, str);
        }
        
        /* assign behavior variables based on input */
        if (strcmp(word,"qualmeasure") == 0) 
        {
            switch (value)
            {
                case 0:
                    b->quality_cb = &quality_minsine;
                    b->optinfo_cb = &optinfo_minsine;
                    break;
                case 1:
                    b->quality_cb = &quality_radiusratio;
                    b->optinfo_cb = &optinfo_radiusratio;
                    break;
                case 2:
                    b->quality_cb = &quality_vlrms3ratio;
                    b->optinfo_cb = &optinfo_vlrms3ratio;
                    break;
                case 5:
                    b->quality_cb = &quality_warpedminsine;
                    b->optinfo_cb = &optinfo_warpedminsine;
                    break;
                case 6:
                    b->quality_cb = &quality_vlhlrms4ratio;
                    b->optinfo_cb = &optinfo_vlhlrms4ratio;
                    break;
                default:
                    printf("Warning: didn't understand quality measure %d, using default vlhlrms4ratio.\n", value);
                    b->quality_cb = &quality_vlhlrms4ratio;
                    b->optinfo_cb = &optinfo_vlhlrms4ratio;
                    break;
            }
        }
        if (strcmp(word,"usequadrics") == 0) b->usequadrics = value;
        if (strcmp(word,"quadricoffset") == 0) b->quadricoffset = fvalue;
        if (strcmp(word,"quadricscale") == 0) b->quadricscale = fvalue;
        
        if (strcmp(word,"dynamic") == 0) b->dynamic = value;
        
        if (strcmp(word,"nonsmooth") == 0) b->nonsmooth = value;
        if (strcmp(word,"facetsmooth") == 0) b->facetsmooth = value;
        if (strcmp(word,"segmentsmooth") == 0) b->segmentsmooth = value;
        if (strcmp(word,"cornersmooth") == 0) b->cornersmooth = value;
        
        if (strcmp(word,"edgeremoval") == 0) b->edgeremoval = value;
        if (strcmp(word,"edgecontraction") == 0) b->edgecontraction = value;
        if (strcmp(word,"boundedgeremoval") == 0) b->boundedgeremoval = value;
        if (strcmp(word,"singlefaceremoval") == 0) b->singlefaceremoval = value;
        if (strcmp(word,"multifaceremoval") == 0) b->multifaceremoval = value;
        if (strcmp(word,"flip22") == 0) b->flip22 = value;
        
        if (strcmp(word,"insertthreshold") == 0) b->insertthreshold = fvalue;
        if (strcmp(word,"enableinsert") == 0) b->enableinsert = value;
        if (strcmp(word,"insertfacet") == 0) b->insertfacet = value;
        if (strcmp(word,"insertbody") == 0) b->insertbody = value;
        if (strcmp(word,"insertsegment") == 0) b->insertsegment = value;
        if (strcmp(word,"cavityconsiderdeleted") == 0) b->cavityconsiderdeleted = value;
        if (strcmp(word,"cavdepthlimit") == 0) b->cavdepthlimit = value;
        
        if (strcmp(word,"minstepimprovement") == 0) b->minstepimprovement = fvalue;
        if (strcmp(word,"maxinsertquality") == 0) b->maxinsertquality = fvalue;
        
        if (strcmp(word,"sizing") == 0) b->sizing = value;
        if (strcmp(word,"sizingpass") == 0) b->sizingpass = value;
        if (strcmp(word,"targetedgelength") == 0) b->targetedgelength = fvalue;
        if (strcmp(word,"longerfactor") == 0) b->longerfactor = fvalue;
        if (strcmp(word,"shorterfactor") == 0) b->shorterfactor = fvalue;
        
        if (strcmp(word,"usecolor") == 0) b->usecolor = value;
        
        if (strcmp(word,"verbosity") == 0) b->verbosity = value;
        
        if (strcmp(word,"goalquality") == 0) b->goalquality = fvalue;
    }
}

