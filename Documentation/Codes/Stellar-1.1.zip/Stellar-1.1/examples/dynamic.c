/* 

Pulsar - a dynamic mesh improvement example using libstellar.

Martin Wicke

*/

#include "stellar.h"

#include "tensors.h"
#include "qualitymeasures.h"

/* example mesh input/output and other example callbacks are here */
#include "common.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,
char **argv)
{
    /* input variables */
    int numinnodes = 0;
    starreal (*innodes)[3] = NULL;
    int numintets = 0;
    int (*intets)[4] = NULL;  
    int numattr = 0;
    starreal *inattr = NULL;
    int numignoretets = 0;
    int (*ignoretets)[4] = NULL;
    int numoutnodes = 0;
    starreal (*outnodes)[3] = NULL;
    starreal *outattr = NULL;
    int numouttets = 0;
    int (*outtets)[4] = NULL;
    int *nodemap = NULL;
    starreal quality;
    
    /* set up configuration */
    struct improvebehavior improvebehave;

    /* Check arguments, we need at least two. */
    if (argc < 3) 
    {
        printf("usage: Pulsar input_mesh_filename output_mesh_filename [configuration_file]\n");
        return false;
    }
    
    /* initialize all configuration options to sensible defaults */
    initialize_improvement_options(&improvebehave);
    
    /* If a third argument is given, parse it as a configuration file */
    if (argc == 4)
    {
        printf("Parsing improvement settings from '%s'\n", argv[3]);
        parseimproveconfig(argv[3], &improvebehave);
    }

    /* Load the mesh given as the first argument. */
    if (!LoadMesh(argv[1], &numinnodes, (starreal**) &innodes, &numintets, (int **) &intets)) 
    {
        return false;
    }

    /* Pass this configuration to Stellar library. No copy is made, so it has to be around until Pulsar is done. 
       That also means we can still change things, for example in a callback. */
    stellar_prepare(&improvebehave);

    /* Make space for the nodemap. It will contain a new node index for each old node index.
       If nodemap[i] == j, then innodes[i] == outnodes[j]. */
    nodemap = (int *) malloc(numinnodes * sizeof(int));

    /* Improve this mesh using the dynamic improvement schedule */
    quality = pulsar(numinnodes, innodes,
                     numintets, intets,
                     numattr, inattr,
                     numignoretets, ignoretets,
                     &numoutnodes, (starreal **) &outnodes, &outattr,
                     &numouttets, (int**) &outtets,
                     nodemap);

    printf("Improvement yields mesh with minimum quality %f\n", quality);

    /* We're done. Write the resulting mesh. */
    WriteMesh(argv[2], numoutnodes, (const starreal (*)[3]) outnodes, numouttets, (const int (*)[4]) outtets);

    /* clean up */
    stellar_finalize();

    if (innodes)
        free(innodes);
    if (intets)
        free(intets);
    if (outnodes)
        free(outnodes);
    if (outattr)
        free(outattr);
    if (outtets)
        free(outtets);
    if (nodemap)
        free(nodemap);

    return 0;
}
