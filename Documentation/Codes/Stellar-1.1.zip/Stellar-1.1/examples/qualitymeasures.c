#include "stellar.h"
    
/* In order to use Star's tet orientationa and volume functions, we need this cumbersome definition */
struct behavior behave;

/* Useful functions from inside Pulsar */
#include "vector.h"
#include "util.h"

/* compute the (square) of the minimum sine
 of all the dihedral angles in the tet defined
 by the four vertices (vtx1, vtx2, vtx3, vtx4)
 */
starreal quality_minsine(const starreal point[4][3]) {
  starreal edgelength[3][4]; /* the lengths of each of the edges of the tet */
  starreal facenormal[4][3]; /* the normals of each face of the tet */
  starreal dx, dy, dz;       /* intermediate values of edge lengths */
  starreal facearea2[4];     /* areas of the faces of the tet */
  starreal pyrvolume;        /* volume of tetrahedron */
  starreal sine2, minsine2;  /* the sine (squared) of the dihedral angle */
  int i, j, k, l;          /* loop indices */
  
  /* calculate the volume*6 of the tetrahedron */
  pyrvolume = parallelepiped(point[0], point[1], point[2], point[3]);
  
  /* if the volume is zero, the quality is zero, no reason to continue */
  if (pyrvolume == 0.0)
  {
    return 0.0;
  }
  
  /* for each vertex/face of the tetrahedron */
  for (i = 0; i < 4; i++) {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      k = (i + 3) & 3;
      l = (i + 2) & 3;
    } else {
      k = (i + 2) & 3;
      l = (i + 3) & 3;
    }
    
    /* compute the normal for each face */
    facenormal[i][0] =
    (point[k][1] - point[j][1]) * (point[l][2] - point[j][2]) -
    (point[k][2] - point[j][2]) * (point[l][1] - point[j][1]);
    facenormal[i][1] =
    (point[k][2] - point[j][2]) * (point[l][0] - point[j][0]) -
    (point[k][0] - point[j][0]) * (point[l][2] - point[j][2]);
    facenormal[i][2] =
    (point[k][0] - point[j][0]) * (point[l][1] - point[j][1]) -
    (point[k][1] - point[j][1]) * (point[l][0] - point[j][0]);
    
    /* compute (2 *area)^2 for this face */
    facearea2[i] = facenormal[i][0] * facenormal[i][0] +
    facenormal[i][1] * facenormal[i][1] +
    facenormal[i][2] * facenormal[i][2];
    
    /* compute edge lengths (squared) */
    for (j = i + 1; j < 4; j++) {
      dx = point[i][0] - point[j][0];
      dy = point[i][1] - point[j][1];
      dz = point[i][2] - point[j][2];
      edgelength[i][j] = dx * dx + dy * dy + dz * dz;
    }
  }
  
  minsine2 = HUGEFLOAT;     /* start with absurdly big value for sine */
  
  /* for each edge in the tetrahedron */
  for (i = 0; i < 3; i++) {
    for (j = i + 1; j < 4; j++) {
      k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
      l = 6 - i - j - k;
      
      /* compute the expression for minimum sine, squared, over 4 
       The reason it's over 4 is because the area values we have
       are actually twice the area squared */
      /* if either face area is zero, the sine is zero */
      if (facearea2[k] > 0 && facearea2[l] > 0)
      {
        sine2 = edgelength[i][j] / (facearea2[k] * facearea2[l]);
      }
      else
      {
        sine2 = 0.0;
      }
      
      /* update minimum sine */
      if (sine2 < minsine2)
      {
        minsine2 = sine2;
      }
    }
  }
  
  return sqrt(minsine2) * pyrvolume;
}






/* compute the minimum or maximum angle of the tet defined
 by the four vertices (vtx1, vtx2, vtx3, vtx4)
 */
starreal minmaxangle_raw(const starreal point[4][3], bool get_min) {
  starreal edgelength[3][4]; /* the lengths of each of the edges of the tet */
  starreal facenormal[4][3]; /* the normals of each face of the tet */
  starreal dx, dy, dz;       /* intermediate values of edge lengths */
  starreal pyrvolume;        /* volume of tetrahedron */
  int i, j, k, l;          /* loop indices */
  starreal minangle = HUGEFLOAT;
  starreal maxangle = 0.0;
  starreal angle, tantheta;
  starreal dotproduct;
  
  /* calculate the volume*6 of the tetrahedron */
  pyrvolume = parallelepiped(point[0], point[1], point[2], point[3]);
  
  /* for each vertex/face of the tetrahedron */
  for (i = 0; i < 4; i++) {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      k = (i + 3) & 3;
      l = (i + 2) & 3;
    } else {
      k = (i + 2) & 3;
      l = (i + 3) & 3;
    }
    
    /* compute the normal for each face */
    facenormal[i][0] =
    (point[k][1] - point[j][1]) * (point[l][2] - point[j][2]) -
    (point[k][2] - point[j][2]) * (point[l][1] - point[j][1]);
    facenormal[i][1] =
    (point[k][2] - point[j][2]) * (point[l][0] - point[j][0]) -
    (point[k][0] - point[j][0]) * (point[l][2] - point[j][2]);
    facenormal[i][2] =
    (point[k][0] - point[j][0]) * (point[l][1] - point[j][1]) -
    (point[k][1] - point[j][1]) * (point[l][0] - point[j][0]);
    
    /* compute edge lengths (squared) */
    for (j = i + 1; j < 4; j++) {
      dx = point[i][0] - point[j][0];
      dy = point[i][1] - point[j][1];
      dz = point[i][2] - point[j][2];
      edgelength[i][j] = dx * dx + dy * dy + dz * dz;
    }
  }
  
  /* for each edge in the tetrahedron */
  for (i = 0; i < 3; i++) {
    for (j = i + 1; j < 4; j++) {
      k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
      l = 6 - i - j - k;
      
      /* compute the tangent of the angle using the tangent formula:
       
       tan(theta_ij) = - 6 * V * l_ij
       --------------
       dot(n_k, n_l)
       
       because this formula is accurate in the entire range.
       */
      dotproduct = dot(facenormal[k], facenormal[l]);
      
      if (dotproduct != 0.0)
      {
        tantheta = (-pyrvolume * sqrt(edgelength[i][j])) / dotproduct;
        
        /* now compute the actual angle */
        angle = atan(tantheta);
      }
      else
      {
        angle = PI / 2.0;
      }
      
      /* adjust angle for sign of dot product */
      if (dotproduct > 0)
      {
        angle += PI;
      }
      
      /* make negative angles positive */
      if (angle < 0)
      {
        angle += 2.0 * PI;
      }
      
      if (dotproduct == 0.0) angle = PI / 2.0;
      
      if (angle < minangle) minangle = angle;
      if (angle > maxangle) maxangle = angle;
    }
  }
  
  if (get_min)
    return radtodeg(minangle);
  else
    return radtodeg(maxangle);
}

starreal quality_minangle(const starreal point[4][3]) {
  return minmaxangle_raw(point, true);
}

starreal quality_maxangle(const starreal point[4][3]) {
  return minmaxangle_raw(point, false);
}






/* warp the sine of the dihedral angle to penalize obtuse angles more than acute */
starreal warpsine(starreal sine) {
  return sine * .75; 
}

/* compute the (square) of the minimum sine
 of all the dihedral angles in the tet defined
 by the four vertices (vtx1, vtx2, vtx3, vtx4)
 */
starreal quality_warpedminsine(const starreal point[4][3]) {
  starreal edgelength[3][4]; /* the lengths of each of the edges of the tet */
  starreal facenormal[4][3]; /* the normals of each face of the tet */
  starreal dx, dy, dz;       /* intermediate values of edge lengths */
  starreal facearea2[4];     /* areas of the faces of the tet */
  starreal pyrvolume;        /* volume of tetrahedron */
  starreal sine2, minsine2;  /* the sine (squared) of the dihedral angle */
  int i, j, k, l;          /* loop indices */
  
  /* calculate the volume*6 of the tetrahedron */
  pyrvolume = parallelepiped(point[0], point[1], point[2], point[3]);
  
  /* if the volume is zero, the quality is zero, no reason to continue */
  if (pyrvolume == 0.0)
  {
    return 0.0;
  }
  
  /* for each vertex/face of the tetrahedron */
  for (i = 0; i < 4; i++) {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      k = (i + 3) & 3;
      l = (i + 2) & 3;
    } else {
      k = (i + 2) & 3;
      l = (i + 3) & 3;
    }
    
    /* compute the normal for each face */
    facenormal[i][0] =
    (point[k][1] - point[j][1]) * (point[l][2] - point[j][2]) -
    (point[k][2] - point[j][2]) * (point[l][1] - point[j][1]);
    facenormal[i][1] =
    (point[k][2] - point[j][2]) * (point[l][0] - point[j][0]) -
    (point[k][0] - point[j][0]) * (point[l][2] - point[j][2]);
    facenormal[i][2] =
    (point[k][0] - point[j][0]) * (point[l][1] - point[j][1]) -
    (point[k][1] - point[j][1]) * (point[l][0] - point[j][0]);
    
    /* compute (2 *area)^2 for this face */
    facearea2[i] = facenormal[i][0] * facenormal[i][0] +
    facenormal[i][1] * facenormal[i][1] +
    facenormal[i][2] * facenormal[i][2];
    
    /* compute edge lengths (squared) */
    for (j = i + 1; j < 4; j++) {
      dx = point[i][0] - point[j][0];
      dy = point[i][1] - point[j][1];
      dz = point[i][2] - point[j][2];
      edgelength[i][j] = dx * dx + dy * dy + dz * dz;
    }
  }
  
  minsine2 = HUGEFLOAT;     /* start with absurdly big value for sine */
  
  /* for each edge in the tetrahedron */
  for (i = 0; i < 3; i++) {
    for (j = i + 1; j < 4; j++) {
      k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
      l = 6 - i - j - k;
      
      /* compute the expression for minimum sine, squared, over 4 
       The reason it's over 4 is because the area values we have
       are actually twice the area squared */
      /* if either face area is zero, the sine is zero */
      if (facearea2[k] > 0 && facearea2[l] > 0)
      {
        sine2 = edgelength[i][j] / (facearea2[k] * facearea2[l]);
      }
      else
      {
        sine2 = 0.0;
      }
      
      /* check whether this angle is obtuse */
      if (dot(facenormal[k],facenormal[l]) > 0)
      {
        /* if so, warp it down */
        sine2 = warpsine(sqrt(sine2));
        sine2 *= sine2;
      }
      
      /* update minimum sine */
      if (sine2 < minsine2)
      {
        minsine2 = sine2;
      }
    }
  }
  
  return sqrt(minsine2) * pyrvolume;
}







/* compute the mean of the sines
 of all the dihedral angles in the tet
 */
starreal quality_meansine(const starreal point[4][3])
{
  starreal edgelength[3][4]; /* the lengths of each of the edges of the tet */
  starreal facenormal[4][3]; /* the normals of each face of the tet */
  starreal dx, dy, dz;       /* intermediate values of edge lengths */
  starreal facearea2[4];     /* areas of the faces of the tet */
  starreal pyrvolume;        /* volume of tetrahedron */
  starreal sine2;            /* the sine (squared) of the dihedral angle */
  starreal sinesum=0.0;      /* the accumulating sum of the sines */
  int i, j, k, l;          /* loop indices */
  
  /* calculate the volume*6 of the tetrahedron */
  pyrvolume = parallelepiped(point[0], point[1], point[2], point[3]);
  
  /* for each vertex/face of the tetrahedron */
  for (i = 0; i < 4; i++) {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      k = (i + 3) & 3;
      l = (i + 2) & 3;
    } else {
      k = (i + 2) & 3;
      l = (i + 3) & 3;
    }
    
    /* compute the normal for each face */
    facenormal[i][0] =
    (point[k][1] - point[j][1]) * (point[l][2] - point[j][2]) -
    (point[k][2] - point[j][2]) * (point[l][1] - point[j][1]);
    facenormal[i][1] =
    (point[k][2] - point[j][2]) * (point[l][0] - point[j][0]) -
    (point[k][0] - point[j][0]) * (point[l][2] - point[j][2]);
    facenormal[i][2] =
    (point[k][0] - point[j][0]) * (point[l][1] - point[j][1]) -
    (point[k][1] - point[j][1]) * (point[l][0] - point[j][0]);
    
    /* compute (2 *area)^2 for this face */
    facearea2[i] = facenormal[i][0] * facenormal[i][0] +
    facenormal[i][1] * facenormal[i][1] +
    facenormal[i][2] * facenormal[i][2];
    
    /* compute edge lengths (squared) */
    for (j = i + 1; j < 4; j++) {
      dx = point[i][0] - point[j][0];
      dy = point[i][1] - point[j][1];
      dz = point[i][2] - point[j][2];
      edgelength[i][j] = dx * dx + dy * dy + dz * dz;
    }
  }
  
  /* for each edge in the tetrahedron */
  for (i = 0; i < 3; i++) {
    for (j = i + 1; j < 4; j++) {
      k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
      l = 6 - i - j - k;
      
      /* compute the expression for minimum sine, squared, over 4 
       The reason it's over 4 is because the area values we have
       are actually twice the area squared */
      /* if either face area is zero, the sine is zero */
      if (facearea2[k] > 0 && facearea2[l] > 0)
      {
        sine2 = edgelength[i][j] / (facearea2[k] * facearea2[l]);
      }
      else
      {
        sine2 = 0.0;
      }
      
      /* accumulate sine */
      sinesum += sqrt(sine2);
    }
  }
  
  /* average sine */
  return (sinesum / 6.0) * pyrvolume;
}






/* compute Z, a quantity associated with circumradius computation
 TODO this code is lifted from Jonathan's tetcircumcenter computation
 in primitives.c */
starreal getZ(const starreal *tetorg,
              const starreal *tetdest,
              const starreal *tetfapex,
              const starreal *tettapex)
{
  starreal xot, yot, zot, xdt, ydt, zdt, xft, yft, zft;
  starreal otlength, dtlength, ftlength;
  starreal xcrossdf, ycrossdf, zcrossdf;
  starreal xcrossfo, ycrossfo, zcrossfo;
  starreal xcrossod, ycrossod, zcrossod;
  starreal xct, yct, zct;
  
  /* Use coordinates relative to the apex of the tetrahedron. */
  xot = tetorg[0] - tettapex[0];
  yot = tetorg[1] - tettapex[1];
  zot = tetorg[2] - tettapex[2];
  xdt = tetdest[0] - tettapex[0];
  ydt = tetdest[1] - tettapex[1];
  zdt = tetdest[2] - tettapex[2];
  xft = tetfapex[0] - tettapex[0];
  yft = tetfapex[1] - tettapex[1];
  zft = tetfapex[2] - tettapex[2];
  /* Squares of lengths of the origin, destination, and face apex edges. */
  otlength = xot * xot + yot * yot + zot * zot;
  dtlength = xdt * xdt + ydt * ydt + zdt * zdt;
  ftlength = xft * xft + yft * yft + zft * zft;
  /* Cross products of the origin, destination, and face apex vectors. */
  xcrossdf = ydt * zft - yft * zdt;
  ycrossdf = zdt * xft - zft * xdt;
  zcrossdf = xdt * yft - xft * ydt;
  xcrossfo = yft * zot - yot * zft;
  ycrossfo = zft * xot - zot * xft;
  zcrossfo = xft * yot - xot * yft;
  xcrossod = yot * zdt - ydt * zot;
  ycrossod = zot * xdt - zdt * xot;
  zcrossod = xot * ydt - xdt * yot;
  
  /* Calculate offset (from apex) of circumcenter. */
  xct = (otlength * xcrossdf + dtlength * xcrossfo + ftlength * xcrossod);
  yct = (otlength * ycrossdf + dtlength * ycrossfo + ftlength * ycrossod);
  zct = (otlength * zcrossdf + dtlength * zcrossfo + ftlength * zcrossod);
  
  /* Calculate the length of this vector, which is Z */
  return sqrt(xct * xct + yct * yct + zct * zct);
}




/* the inradius to circumradius ratio */
starreal quality_radiusratio(const starreal point[4][3])
{
  starreal facenormal[4][3]; /* the normals of each face of the tet */
  starreal facearea2[4];     /* areas of the faces of the tet */
  starreal pyrvolume;        /* volume of tetrahedron */
  starreal Z;                /* quantity needed for circumradius */
  starreal facesum=0.0;       /* sum of the areas of the faces */
  int i, j, k, l;          /* loop indices */
  starreal sign;
  starreal qual;
  
  /* calculate the volume*6 of the tetrahedron */
  pyrvolume = parallelepiped(point[0], point[1], point[2], point[3]);
  
  /* if the volume is zero, the quality is zero, no reason to continue */
  if (pyrvolume == 0.0)
  {
    return 0.0;
  }
  
  /* for each vertex/face of the tetrahedron */
  for (i = 0; i < 4; i++) {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      k = (i + 3) & 3;
      l = (i + 2) & 3;
    } else {
      k = (i + 2) & 3;
      l = (i + 3) & 3;
    }
    
    /* compute the normal for each face */
    facenormal[i][0] =
    (point[k][1] - point[j][1]) * (point[l][2] - point[j][2]) -
    (point[k][2] - point[j][2]) * (point[l][1] - point[j][1]);
    facenormal[i][1] =
    (point[k][2] - point[j][2]) * (point[l][0] - point[j][0]) -
    (point[k][0] - point[j][0]) * (point[l][2] - point[j][2]);
    facenormal[i][2] =
    (point[k][0] - point[j][0]) * (point[l][1] - point[j][1]) -
    (point[k][1] - point[j][1]) * (point[l][0] - point[j][0]);
    
    /* compute (2 *area)^2 for this face */
    facearea2[i] = facenormal[i][0] * facenormal[i][0] +
    facenormal[i][1] * facenormal[i][1] +
    facenormal[i][2] * facenormal[i][2];
    facesum += sqrt(facearea2[i]) * 0.5;
  }
  
  /* compute Z */
  Z = getZ(point[0], point[1], point[2], point[3]);
  
  /* now we are ready to compute the radius ratio, which is
   
   (108 * V^2) / Z (A1 + A2 + A3 + A4)
   
   (use 3 instead of 108 because pyrvolume = 6V)
   */
  /* use sqrt for now... */
  sign = (pyrvolume < 0.0) ? -1.0 : 1.0;
  
  qual = sign * sqrt((3.0 * pyrvolume * pyrvolume) / (Z * facesum));
  
  return qual;
}





/* compute the ratio of the tet volume to the cube of
 the rms edge length */
starreal quality_vlrms3ratio(const starreal point[4][3])
{
  starreal edgelength[3][4]; /* the lengths of each of the edges of the tet */
  starreal dx, dy, dz;       /* intermediate values of edge lengths */
  starreal pyrvolume;        /* volume of tetrahedron */
  int i, j, k, l;          /* loop indices */
  starreal edgelengthsum = 0.0;
  starreal lrms;             /* root mean squared of edge length */
  starreal qual;
  
  /* calculate the volume*6 of the tetrahedron */
  pyrvolume = parallelepiped(point[0], point[1], point[2], point[3]);
  
  /* if the volume is zero, the quality is zero, no reason to continue */
  if (pyrvolume == 0.0)
  {
    return 0.0;
  }
  
  /* for each vertex/face of the tetrahedron */
  for (i = 0; i < 4; i++) {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      k = (i + 3) & 3;
      l = (i + 2) & 3;
    } else {
      k = (i + 2) & 3;
      l = (i + 3) & 3;
    }
    
    /* compute edge lengths (squared) */
    for (j = i + 1; j < 4; j++) {
      dx = point[i][0] - point[j][0];
      dy = point[i][1] - point[j][1];
      dz = point[i][2] - point[j][2];
      edgelength[i][j] = dx * dx + dy * dy + dz * dz;
    }
  }
  
  /* for each edge in the tetrahedron */
  for (i = 0; i < 3; i++) {
    for (j = i + 1; j < 4; j++) {
      k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
      l = 6 - i - j - k;
      
      edgelengthsum += edgelength[i][j];
    }
  }
  
  /* compute the root mean square */
  lrms = sqrt((1.0 / 6.0) * edgelengthsum);
  
  /* compute the normalized ratio of volume to lrms^3 */
  qual = (sqrt(2.0) * pyrvolume) / (lrms * lrms * lrms);
  
  return qual;
}







/* compute the ratio of the tet volume times the harmonic mean edge length to the fourth power of
 the rms edge length */
starreal quality_vlhlrms4ratio(const starreal point[4][3])
{
  starreal edgelength[3][4]; /* the lengths of each of the edges of the tet */
  starreal dx, dy, dz;       /* intermediate values of edge lengths */
  starreal pyrvolume;        /* volume of tetrahedron */
  int i, j, k, l;          /* loop indices */
  starreal edgelengthsum = 0.0;
  starreal edgelengthinvsum = 0.0;
  starreal lrms;             /* root mean squared of edge length */
  starreal lh;               /* harmonic mean of edge lengths */
  starreal qual;
    
  /* calculate the volume*6 of the tetrahedron */
  pyrvolume = parallelepiped(point[0], point[1], point[2], point[3]);
  
  /* if the volume is zero, the quality is zero, no reason to continue */
  if (pyrvolume == 0.0)
  {
    return 0.0;
  }
  
  /* for each vertex/face of the tetrahedron */
  for (i = 0; i < 4; i++) {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      k = (i + 3) & 3;
      l = (i + 2) & 3;
    } else {
      k = (i + 2) & 3;
      l = (i + 3) & 3;
    }
    
    /* compute edge lengths (squared) */
    for (j = i + 1; j < 4; j++) {
      dx = point[i][0] - point[j][0];
      dy = point[i][1] - point[j][1];
      dz = point[i][2] - point[j][2];
      edgelength[i][j] = dx * dx + dy * dy + dz * dz;
    }
  }
  
  /* for each edge in the tetrahedron */
  for (i = 0; i < 3; i++) {
    for (j = i + 1; j < 4; j++) {
      k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
      l = 6 - i - j - k;
      
      edgelengthsum += edgelength[i][j];
      edgelengthinvsum += 1./edgelength[i][j];
    }
  }
  
  /* compute the root mean square */
  lrms = sqrt((1.0 / 6.0) * edgelengthsum);
  lh = 1./sqrt((1.0 / 6.0) * edgelengthinvsum);
  
  /* compute the normalized ratio of volume * lh to lrms^4 */
  qual = (sqrt(2.0) * pyrvolume * lh) / (lrms * lrms * lrms * lrms);
  
  return qual;
}






enum tetqualitymetrics
{
  QUALMINSINE,
  QUALRADIUSRATIO,
  QUALVLRMS3RATIO,
  QUALMEANSINE,
  QUALMINSINEANDEDGERATIO,
  QUALWARPEDMINSINE,
  QUALMINANGLE,
  QUALMAXANGLE,
  QUALVLHLRMS4RATIO,
  QUALLENGTHRATIO
};

/* get the information about this tet needed for non-smooth
 optimization of the current quality measure */
void getoptinfo_monster(const starreal point[4][3], struct opttet *opttet, int qualmeasure)
{
  starreal edgelength[3][4];  /* the lengths of each of the edges of the tet */
  starreal edgegrad[3][4][3]; /* the gradient of each edge length wrt vtx1 */
  starreal facenormal[4][3];  /* the normals of each face of the tet */
  starreal facearea[4];       /* areas of the faces of the tet */
  starreal facegrad[4][3];    /* the gradient of each of the face areas wrt vtx1 */
  starreal volume;            /* volume of tetrahedron */
  starreal volumegrad[3] = {0.0, 0.0, 0.0};     /* the gradient of the volume of the tet wrt vtx1 */
  int i, j, k, l;           /* loop indices */
  int edgecount=0;          /* keep track of current edge */
  starreal ejk[3];            /* vector representing edge from j to k */
  starreal ejl[3];            /* vector representing edge from j to l */
  starreal t[3];
  starreal u[3];
  starreal v[3];
  starreal e1[3] = {0.0, 0.0, 0.0};
  starreal e2[3] = {0.0, 0.0, 0.0};
  
  /* temporary variables */
  starreal diff[3];
  starreal term1[3];
  starreal term2[3];
  starreal factor;
  starreal c;
  starreal top, bot;
  starreal gradtop[3];
  starreal gradbot[3];
  starreal gradquot[3];
  
  /* radius ratio vars */
  starreal Z;
  starreal twooverZ;
  starreal gradZtfac, gradZufac, gradZvfac;
  starreal gradZt[3];
  starreal gradZu[3];
  starreal gradZv[3];
  starreal gradZ[3];
  starreal faceareasum;
  starreal rootZareasum;
  starreal facegradsum[3];
  starreal vdott;
  starreal tdotu;
  starreal udotv;
  starreal tlen2;
  starreal ulen2;
  starreal vlen2;
  starreal uminusv[3];
  starreal vminust[3];
  starreal tminusu[3];
  starreal umvlen2;
  starreal vmtlen2;
  starreal tmulen2;
  starreal normfac = sqrt(3.0) * 6.0;
  starreal rnrrgradterm1[3], rnrrgradterm2[3];
  
  /* V / lrms^3 ratio vars */
  starreal edgelengthsum = 0.0;
  starreal lrms = 0;
  starreal gradlrms[3] = {0.,0.,0.};
  starreal vlrmsterm1[3];
  starreal vlrmsterm2[3];
  
  /* V lh / lrms^4 ratio vars */
  starreal edgelengthinvsum = 0.0;
  starreal edgelengthinvsumgrad[3] = {0., 0., 0.};
  starreal edgegradscaled[3];
  starreal vlhlrms4gradterm1[3];
  starreal vlhlrms4gradterm2[3];
  starreal vlhlrms4gradterm3[3];
  starreal lh;
  starreal lhgrad[3];
  
  /* set some vectors */
  vsub(point[1], point[0], t);
  vsub(point[2], point[0], v);
  vsub(point[3], point[0], u);
  
  /* calculate the volume*6 of the tetrahedron using orientation */
  volume = parallelepiped(point[0], point[1], point[2], point[3]) / 6.0;
  opttet->volume = volume;
  
  /* for each vertex/face of the tetrahedron */
  for (i = 0; i < 4; i++) {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      k = (i + 3) & 3;
      l = (i + 2) & 3;
    } else {
      k = (i + 2) & 3;
      l = (i + 3) & 3;
    }
    
    /* compute the normal for each face */
    /* for each vertex i in the loop, the ith face is the face
     opposite i, so that face's normal is found by taking the
     cross product of two edges of the opposite face */
    /* TODO implement this cross product with Orient2D calls? */
    
    /* one edge on opposite face */
    vsub(point[k], point[j], ejk);
    
    /* another edge originating from the same vertex */
    vsub(point[l], point[j], ejl);
    
    /* compute a normal vector to this face */
    cross(ejk, ejl, facenormal[i]);
    
    /* if i=0, this is also the gradient of the volume * 6
     with respect to vertex 0 */
    if (i==0)
    {
      opttet->volumegrad[0] = volumegrad[0] = -facenormal[i][0] / 6.0;
      opttet->volumegrad[1] = volumegrad[1] = -facenormal[i][1] / 6.0;
      opttet->volumegrad[2] = volumegrad[2] = -facenormal[i][2] / 6.0;
    }
    
    /* compute (2 *area)^2 for this face */
    facearea[i] = facenormal[i][0] * facenormal[i][0] +
    facenormal[i][1] * facenormal[i][1] +
    facenormal[i][2] * facenormal[i][2];
    /* now get the real area */
    facearea[i] = sqrt(facearea[i]) / 2.0;
    
    /* compute the gradient of the area for this face */
    if (i==0)
    {
      /* this face doesn't include vtx1, gradient is zero */
      facegrad[i][0] = 0.0;
      facegrad[i][1] = 0.0;
      facegrad[i][2] = 0.0;
    }
    else
    {
      assert(facearea[i] > 0);
      /* gradient scaled by the face's area */
      factor = 1.0 / (4.0 * facearea[i]);
      
      /* handle each face separately */
      switch(i)
      {
          /* compute the area of face 1 using u and v */
        case 1:
          vcopy(u, e1);
          vcopy(v, e2);
          break;
        case 2:
          vcopy(t, e1);
          vcopy(u, e2);
          break;
        case 3:
          vcopy(v, e1);
          vcopy(t, e2);
          break;
      }
      
      /* find the vector from elk to elj */
      vsub(e1, e2, diff);
      
      /* compute first term of gradient */
      c = dot(e2,diff);
      term1[0] = c * e1[0];
      term1[1] = c * e1[1];
      term1[2] = c * e1[2];
      
      /* compute the second term */
      c = dot(e1,diff);
      term2[0] = c * e2[0];
      term2[1] = c * e2[1];
      term2[2] = c * e2[2];
      
      /* now, combine the terms, scaled with the 1/4A */
      facegrad[i][0] = factor * (term1[0] - term2[0]);
      facegrad[i][1] = factor * (term1[1] - term2[1]);
      facegrad[i][2] = factor * (term1[2] - term2[2]);
    }
    
    
    /* compute edge lengths for quality measures that need them */
    if (qualmeasure == QUALMINSINE ||
        qualmeasure == QUALWARPEDMINSINE ||
        qualmeasure == QUALVLRMS3RATIO || 
        qualmeasure == QUALVLHLRMS4RATIO)
    {
      for (j = i + 1; j < 4; j++) {
        
        /* e1 is edge from point i to point j */
        vsub(point[j], point[i], e1);
        edgelength[i][j] = vlength(e1);
        
        /* also compute the gradient of the length of this edge */
        
        /* if vtx1 isn't one of the edge's endpoints, the gradent is zero */
        if (i != 0)
        {
          edgegrad[i][j][0] = 0.0;
          edgegrad[i][j][1] = 0.0;
          edgegrad[i][j][2] = 0.0;
        }
        /* otherwise, it's in the negative direction of this edge,
         and scaled by edge length */
        else
        { 
          factor = -1.0 / edgelength[i][j];
          vscale(factor, e1, edgegrad[i][j]);
        }
      }
    }
  }
  
  /* if the quality measure is minimum sine */
  if ((qualmeasure == QUALMINSINE) ||
      (qualmeasure == QUALWARPEDMINSINE))
  {
    /* for each edge in the tetrahedron */
    for (i = 0; i < 3; i++) {
      for (j = i + 1; j < 4; j++) {
        k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
        l = 6 - i - j - k;
        
        /* compute the sine of this dihedral angle */
        opttet->quality[edgecount] = (3 * volume * edgelength[i][j]) / (2 * facearea[k] * facearea[l]);
        
        /* if we are warping the minimum sine */
        if (qualmeasure == QUALWARPEDMINSINE)
        {
          /* and this is an obtuse angle */
          if (dot(facenormal[k],facenormal[l]) > 0)
          {            
            /* scale the sin down by WARPFACTOR */
            opttet->quality[edgecount] *= 0.75;
          }
        }
        
        /* compute the gradient of the sine
         
         we need the gradient of this expression:
         
         3 * V * lij
         ------------
         2 * Ak * Al
         
         so, find the gradient of the top product, the bottom product, then the quotient
         */
        top = volume * edgelength[i][j];
        bot = facearea[k] * facearea[l];
        
        /* find gradient of top */
        gradproduct(volume, edgelength[i][j], volumegrad, edgegrad[i][j], gradtop);
        
        /* find gradient of bottom */
        gradproduct(facearea[k], facearea[l], facegrad[k], facegrad[l], gradbot);
        
        /* now, find the gradient of the quotient */
        gradquotient(top, bot, gradtop, gradbot, gradquot);
        
        /* now scale with constant factor */
        c = 3.0 / 2.0;
        opttet->qualitygrad[edgecount][0] = c * gradquot[0];
        opttet->qualitygrad[edgecount][1] = c * gradquot[1];
        opttet->qualitygrad[edgecount][2] = c * gradquot[2];
        
        edgecount++;
      }
    }
  }
  
  /* compute stuff for radius ratio */
  if (qualmeasure == QUALRADIUSRATIO)
  {
    /* compute intermediate quantity Z */
    Z = getZ(point[0], point[1], point[2], point[3]);
    
    twooverZ = 2.0 / Z;
    
    /* some dot products */
    vdott = dot(v, t);
    tdotu = dot(t, u);
    udotv = dot(u, v);
    
    /* some vector lengths */
    vsub(u, v, uminusv);
    vsub(v, t, vminust);
    vsub(t, u, tminusu);
    tlen2 = (t[0] * t[0]) + (t[1] * t[1]) + (t[2] * t[2]);
    ulen2 = (u[0] * u[0]) + (u[1] * u[1]) + (u[2] * u[2]);
    vlen2 = (v[0] * v[0]) + (v[1] * v[1]) + (v[2] * v[2]);
    umvlen2 = (uminusv[0] * uminusv[0]) + (uminusv[1] * uminusv[1]) + (uminusv[2] * uminusv[2]);
    vmtlen2 = (vminust[0] * vminust[0]) + (vminust[1] * vminust[1]) + (vminust[2] * vminust[2]);
    tmulen2 = (tminusu[0] * tminusu[0]) + (tminusu[1] * tminusu[1]) + (tminusu[2] * tminusu[2]);
    
    /* compute Z's gradient */
    gradZtfac = twooverZ * 
    (
     (ulen2 * vdott - vlen2 * tdotu) * (ulen2 - vlen2) - 
     (ulen2 * vlen2 + tlen2 * udotv) * (umvlen2)
     );
    gradZufac = twooverZ * 
    (
     (vlen2 * tdotu - tlen2 * udotv) * (vlen2 - tlen2) - 
     (vlen2 * tlen2 + ulen2 * vdott) * (vmtlen2)
     );
    gradZvfac = twooverZ * 
    (
     (tlen2 * udotv - ulen2 * vdott) * (tlen2 - ulen2) - 
     (tlen2 * ulen2 + vlen2 * tdotu) * (tmulen2)
     );
    
    /* compute t, u, v components of gradient */
    vscale(gradZtfac, t, gradZt);
    vscale(gradZufac, u, gradZu);
    vscale(gradZvfac, v, gradZv);
    
    /* add the components together to form grad(Z) */
    vadd(gradZt, gradZu, gradZ);
    vadd(gradZv, gradZ, gradZ);
    
    /* compute sqrt (Z * (sum of face areas)) */
    faceareasum = facearea[0] + facearea[1] + facearea[2] + facearea[3];
    rootZareasum = sqrt(Z * faceareasum);
    
    /* set the actual root normalized radius ratio */
    opttet->quality[0] = (normfac * volume) / rootZareasum;
    
    assert(opttet->quality[0] > 0.0);
    
    /* sum of face gradients */
    vadd(facegrad[0], facegrad[1], facegradsum);
    vadd(facegrad[2], facegradsum, facegradsum);
    vadd(facegrad[3], facegradsum, facegradsum);
    
    /* compute the first term */
    vscale((1.0 / rootZareasum), volumegrad, rnrrgradterm1);
    
    /* compute the second term */
    vscale(Z, facegradsum, facegradsum);
    vscale(faceareasum, gradZ, gradZ);
    vadd(facegradsum, gradZ, rnrrgradterm2);
    vscale(volume / (2 * (rootZareasum * rootZareasum * rootZareasum)), rnrrgradterm2, rnrrgradterm2);
    
    /* finally, compute the gradient of the radius ratio */
    vsub(rnrrgradterm1, rnrrgradterm2, opttet->qualitygrad[0]);
    vscale(normfac, opttet->qualitygrad[0], opttet->qualitygrad[0]);
  }
  
  /* if the quality measure requires lrms */
  if (qualmeasure == QUALVLRMS3RATIO || 
      qualmeasure == QUALVLHLRMS4RATIO)
  {
    /* for each edge in the tetrahedron */
    for (i = 0; i < 3; i++) 
    {
      for (j = i + 1; j < 4; j++) 
      {
        k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
        l = 6 - i - j - k;
        
        /* accumulate edge length sum */
        edgelengthsum += edgelength[i][j] * edgelength[i][j];
      }
    }
    
    /* compute the root mean square */
    lrms = sqrt((1.0 / 6.0) * edgelengthsum);
    
    /* compute gradient of lrms */
    vadd(t, u, gradlrms);
    vadd(v, gradlrms, gradlrms);
    vscale((-1.0 / (6.0 * lrms)), gradlrms, gradlrms);
    
    normfac = 6.0 * sqrt(2.0);
  }
  
  if (qualmeasure == QUALVLRMS3RATIO) 
  {
    /* compute the raw ratio */
    opttet->quality[0] = (normfac * volume) / (lrms * lrms * lrms);
    
    /* compute the terms of the gradient of the ratio */
    vscale((1.0 / (lrms * lrms * lrms)), volumegrad, vlrmsterm1);
    vscale((3.0 * volume) / (lrms * lrms * lrms * lrms), gradlrms, vlrmsterm2);
    
    /* add terms and normalize */
    vsub(vlrmsterm1, vlrmsterm2, opttet->qualitygrad[0]);
    vscale(normfac, opttet->qualitygrad[0], opttet->qualitygrad[0]);
  }
  
  /* if the quality measure requires l_harmonic */
  if (qualmeasure == QUALVLHLRMS4RATIO) {
    /* for each edge in the tetrahedron */
    for (i = 0; i < 3; i++) 
    {
      for (j = i + 1; j < 4; j++) 
      {
        /* accumulate edge length sum */
        edgelengthinvsum += 1./(edgelength[i][j] * edgelength[i][j]);
        
        /* accumulate the gradient of the harmonic mean contributions */
        vscale(-2./(edgelength[i][j] * edgelength[i][j] * edgelength[i][j]), edgegrad[i][j], edgegradscaled);
        vadd(edgelengthinvsumgrad, edgegradscaled, edgelengthinvsumgrad);
      }
    }      
    
    /* compute the harmomic mean */
    lh = 1./sqrt((1.0 / 6.0) * edgelengthinvsum);
    
    /* compute the gradient of the harmonic mean */
    vscale(-0.5*(lh*lh*lh)/6., edgelengthinvsumgrad, lhgrad);
  }
  
  if (qualmeasure == QUALVLHLRMS4RATIO) 
  {
    /* compute the raw ratio */
    opttet->quality[0] = (normfac * volume * lh) / (lrms * lrms * lrms * lrms);
        
    /* compute the terms of the gradient of the ratio */
    vscale(lh/(lrms * lrms * lrms * lrms), volumegrad, vlhlrms4gradterm1);
    vscale(volume/(lrms * lrms * lrms * lrms), lhgrad, vlhlrms4gradterm2);
    vscale(volume*lh*4.0/(lrms * lrms * lrms * lrms * lrms), gradlrms, vlhlrms4gradterm3);
    
    /* add terms and normalize */
    vadd(vlhlrms4gradterm1, vlhlrms4gradterm2, opttet->qualitygrad[0]);
    vsub(opttet->qualitygrad[0], vlhlrms4gradterm3, opttet->qualitygrad[0]);
    vscale(normfac, opttet->qualitygrad[0], opttet->qualitygrad[0]);
  }
  
  switch (qualmeasure) {
    case QUALMINSINE:
    case QUALWARPEDMINSINE:
      opttet->numqualities = 6;
      break;
    case QUALRADIUSRATIO:
      opttet->numqualities = 1;
      break;
    case QUALVLRMS3RATIO:
      opttet->numqualities = 1;
      break;
    case QUALVLHLRMS4RATIO:
      opttet->numqualities = 1;
      break;
    default:
      printf("Don't know how to compute gradients for this metric: %d\n", qualmeasure);
      assert(false);
  }  
}



void optinfo_minsine(const starreal point[4][3], struct opttet *opttet) {
  getoptinfo_monster(point, opttet, QUALMINSINE);
}

void optinfo_warpedminsine(const starreal point[4][3], struct opttet *opttet) {
  getoptinfo_monster(point, opttet, QUALWARPEDMINSINE);
}

void optinfo_radiusratio(const starreal point[4][3], struct opttet *opttet) {
  getoptinfo_monster(point, opttet, QUALRADIUSRATIO);
}

void optinfo_vlrms3ratio(const starreal point[4][3], struct opttet *opttet) {
  getoptinfo_monster(point, opttet, QUALVLRMS3RATIO);
}

void optinfo_vlhlrms4ratio(const starreal point[4][3], struct opttet *opttet) {
  getoptinfo_monster(point, opttet, QUALVLHLRMS4RATIO);
}


