#pragma once

#include "stellar.h"

/* compute the (square) of the minimum sine
 of all the dihedral angles in the tet */
starreal quality_minsine(const starreal point[4][3]);
void optinfo_minsine(const starreal point[4][3], struct opttet *opttet);

/* compute the minimum angle of the tet */
starreal quality_minangle(const starreal point[4][3]);

/* compute the maximum angle of the tet */
starreal quality_maxangle(const starreal point[4][3]);

/* compute the (square) of the minimum sine
 of all the dihedral angles in the tet, but warp angles. */
starreal quality_warpedminsine(const starreal point[4][3]);
void optinfo_warpedminsine(const starreal point[4][3], struct opttet *opttet);

/* compute the mean of the sines
 of all the dihedral angles in the tet */
starreal quality_meansine(const starreal point[4][3]);

/* the inradius to circumradius ratio */
starreal quality_radiusratio(const starreal point[4][3]);
void optinfo_radiusratio(const starreal point[4][3], struct opttet *opttet);
  
/* compute the ratio of the tet volume to the cube of
 the rms edge length */
starreal quality_vlrms3ratio(const starreal point[4][3]);
void optinfo_vlrms3ratio(const starreal point[4][3], struct opttet *opttet);

/* compute the ratio of the tet volume times the harmonic mean edge length to the fourth power of
 the rms edge length */
starreal quality_vlhlrms4ratio(const starreal point[4][3]);
void optinfo_vlhlrms4ratio(const starreal point[4][3], struct opttet *opttet);

