#include "stellar.h"

/* tensor with denser elements at the origin */
void centertensor(const starreal p[3],
                  starreal E[3][3])
{
  starreal s;
  starreal x = p[0], y = p[1], z = p[2];
  
  s = 0.7 + 3.0 / (sqrt(x*x + y*y + z*z) + 0.4);
  
  E[0][0] = s; E[0][1] = 0.0; E[0][2] = 0.0;
  E[1][0] = 0.0; E[1][1] = s; E[1][2] = 0.0;
  E[2][0] = 0.0; E[2][1] = 0.0; E[2][2] = s;
}

/* tensor with denser elements away from the origin */
void perimetertensor(const starreal p[3],
                     starreal E[3][3])
{
  starreal s;
  starreal x = p[0], y = p[1], z = p[2];
  
  s = (sqrt(x*x + y*y + z*z) + 0.2);
  
  E[0][0] = s; E[0][1] = 0.0; E[0][2] = 0.0;
  E[1][0] = 0.0; E[1][1] = s; E[1][2] = 0.0;
  E[2][0] = 0.0; E[2][1] = 0.0; E[2][2] = s;
}

/* tensor with denser elements on the +x side */
void righttensor(const starreal p[3],
                 starreal E[3][3])
{
  starreal s;
  starreal x = p[0];
  
  s = (x + 1.0);
  if (s < 1.0) s = 1.0;
  
  E[0][0] = s; E[0][1] = 0.0; E[0][2] = 0.0;
  E[1][0] = 0.0; E[1][1] = s; E[1][2] = 0.0;
  E[2][0] = 0.0; E[2][1] = 0.0; E[2][2] = s;
}

