#pragma once

#include "stellar.h"

/* tensor with denser elements at the origin */
void centertensor(const starreal p[3],
                  starreal E[3][3]);

/* tensor with denser elements away from the origin */
void perimetertensor(const starreal p[3],
                     starreal E[3][3]);

/* tensor with denser elements on the +x side */
void righttensor(const starreal p[3],
                 starreal E[3][3]);
