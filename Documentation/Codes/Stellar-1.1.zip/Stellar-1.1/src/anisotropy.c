/* Functions to transform space for anisotropic meshing */

#include "vector.h"

/* transform a point to isotropic space with deformation tensor E */
void tensortransform(starreal p[3], starreal pout[3], starreal E[3][3])
{
    starreal pt[3];
    
    /* copy p to temp in case p = pout */
    pt[0] = p[0];
    pt[1] = p[1];
    pt[2] = p[2];
    
    /* compute pout = Ep */
    pout[0] = (E[0][0] * pt[0]) + (E[0][1] * pt[1]) + (E[0][2] * pt[2]);
    pout[1] = (E[1][0] * pt[0]) + (E[1][1] * pt[1]) + (E[1][2] * pt[2]);
    pout[2] = (E[2][0] * pt[0]) + (E[2][1] * pt[1]) + (E[2][2] * pt[2]);
}

/* transform a tet with the tensor at its barycenter, and return the deformed vertices */
void tensortransformtet(struct tetcomplex *mesh,
                        tag vtx1,
                        tag vtx2,
                        tag vtx3,
                        tag vtx4,
                        starreal point[4][3]) {
  starreal barycenter[3] = {0.0, 0.0, 0.0};
  starreal E[3][3];
  int i;
  
  /* get tet vertices */
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx1))->coord, point[0]);
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx2))->coord, point[1]);
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx3))->coord, point[2]);
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx4))->coord, point[3]);
  
  if (improvebehave->tensor_cb == NULL) 
    return;
  
  /* compute barycenter */
  for (i=0; i<4; i++)
  {
    vadd(point[i], barycenter, barycenter);
  }
  vscale(0.25, barycenter, barycenter);
  
  /* get the tensor at the barycenter */
  improvebehave->tensor_cb(barycenter, E);
  
  tensortransform(point[0], point[0], E);
  tensortransform(point[1], point[1], E);
  tensortransform(point[2], point[2], E);
  tensortransform(point[3], point[3], E);
}

/* transform an edge with the tensor at its barycenter, and return the deformed vertices */
void tensortransformedge(struct tetcomplex *mesh,
                         tag vtx1,
                         tag vtx2,
                         starreal point[2][3]) {
  starreal barycenter[3] = {0.0, 0.0, 0.0};
  starreal E[3][3];
  int i;
  
  /* get tet vertices */
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx1))->coord, point[0]);
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx2))->coord, point[1]);
  
  if (improvebehave->tensor_cb == NULL) 
    return;
  
  /* compute barycenter */
  for (i=0; i<2; i++)
  {
    vadd(point[i], barycenter, barycenter);
  }
  vscale(0.5, barycenter, barycenter);
  
  /* get the tensor at the barycenter */
  improvebehave->tensor_cb(barycenter, E);
  
  tensortransform(point[0], point[0], E);
  tensortransform(point[1], point[1], E);
}
