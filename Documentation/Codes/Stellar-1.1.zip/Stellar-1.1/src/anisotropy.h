#include "structs.h"

void tensortransformtet(struct tetcomplex *mesh,
                        tag vtx1,
                        tag vtx2,
                        tag vtx3,
                        tag vtx4,
                        starreal point[4][3]);

void tensortransformedge(struct tetcomplex *mesh,
                         tag vtx1,
                         tag vtx2,
                         starreal points[2][3]);
