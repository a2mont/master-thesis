#pragma once

#include "structs.h"

/* initialize stack data structure */
void stackinit(struct arraypoolstack *stack, arraypoolulong objectbytes);

/* reset stack data structure */
void stackrestart(struct arraypoolstack *stack);

/* free the stack data structure */
void stackdeinit(struct arraypoolstack *stack);

/* push a new element on the stack, return pointer where new element
 should go */
void* stackpush(struct arraypoolstack *stack);

/* fetch the address of the top stack item */
void* stackpop(struct arraypoolstack *stack);

/* fetch the address of the top stack item, but don't pop it */
void *stacktop(struct arraypoolstack *stack);

/* sort stack from worst quality to best (or best to worst) */
/* TODO do in-place sort of arraypool? */
void sortstack(struct arraypoolstack *stack, bool invert);

/* exactly copy one stack to another */
void copystack(struct arraypoolstack *fromstack,
               struct arraypoolstack *tostack);


/* Compare the qualities in the two stacks, return the ordering of the two in lexicographical ordering.
 Returns -1 if stack1 is of lower quality than stack2, 0 if their qualities are equal, 1 if stack1 is 
 of higher quality than stack2. */
int lexicographicorder(struct arraypoolstack *stack1, struct arraypoolstack *stack2);


/* append the contents of one stack to the top of another */
/* only adds tets if they do not already exist in tostack */
void appendstack(struct arraypoolstack *fromstack,
                 struct arraypoolstack *tostack);

/* print out all the tets in a stack */
void printstack(struct tetcomplex *mesh,
                struct arraypoolstack *tetstack);


/* peer into a stack of tets to see if a tet starting with edge (vtx1, vtx2)
 is in there somewhere */
bool tetinstackedge(struct arraypoolstack *tetstack,
                    tag vtx1, tag vtx2);


/* peer into a stack of tets to see if a tet starting with vtx
 is in there somewhere */
bool tetinstackfirstvert(struct arraypoolstack *tetstack,
                         tag vtx);


/* peer into a stack of vertices to see if a particular tag is present */
bool vertinstack(struct arraypoolstack *vertstack,
                 tag vtx);


/* peer into a stack of tets to see if a tet
 is in there somewhere */
bool tetinstack(struct arraypoolstack *tetstack,
                tag v1,
                tag v2,
                tag v3,
                tag v4);


/* given a mesh and a minimum and maximum edge length,
 fill two stacks with tets edges shorter than the minimum
 or longer than the maximum. Each unique edge is represented
 in just one tet. Order the vertices in the tets
 such that the too short (too long) edge comes first */
void filledgestacks(struct tetcomplex *mesh,
                    struct arraypoolstack *longstack,
                    struct arraypoolstack *shortstack,
                    starreal minlength,
                    starreal maxlength,
                    starreal *minedge,
                    starreal *maxedge,
                    starreal *meanedge);




/* Fill stacks for dynamic size control. The stacks contain identical tets (those
 with minedgelen/maxedgelen < improvebehave->minlengthratio). In contractstack,
 tets are ordered such that the shortest edge comes first. In splitstack, tets are
 ordered such that the longest edge comes first. */
void filldynsizestacks(struct tetcomplex *mesh,
                       struct arraypoolstack *splitstack,
                       struct arraypoolstack *contractstack);


/* given a mesh and a quality threshold,
 return a stack of tets with quality 
 at or below that threshold. this function
 assumes that the stack has already been 
 initialized. */
void fillstackqual(struct tetcomplex *mesh,
                   struct arraypoolstack *stack,
                   starreal threshold,
                   starreal meanquals[],
                   starreal *minqual);

/* given a mesh and a quality threshold,
 return a stack of tets with quality 
 at or below that threshold. this function
 assumes that the stack has already been 
 initialized. */
void fillstackqual_physical(struct tetcomplex *mesh,
                            struct arraypoolstack *stack,
                            starreal threshold,
                            starreal meanquals[],
                            starreal *minqual);
  
/* given a mesh and a percentage p,
 return the worst numtets * p tets in the mesh */
void fillstackpercent(struct tetcomplex *mesh,
                      struct arraypoolstack *stack,
                      starreal percent,
                      starreal meanquals[],
                      starreal *minqual);



/* find the meand and minimum qualities
 of all the tets in the stack (that still exist) */
void stackquality(struct tetcomplex *mesh,
                  struct arraypoolstack *tetstack,
                  starreal meanqual[],
                  starreal *minqual);

/* find the worst quality of all the tets in the stack (that still exist) */
starreal worststackquality(struct tetcomplex *mesh,
                           struct arraypoolstack *tetstack);

/* find the worst quality of all the tets in the stack (that still exist) */
starreal worststackquality_physical(struct tetcomplex *mesh,
                                    struct arraypoolstack *tetstack);

/* find the longest and shortest edge length in a stack of tets */
void longshortstack(struct tetcomplex *mesh,
                    struct arraypoolstack *tetstack,
                    starreal *longest,
                    starreal *shortest);



