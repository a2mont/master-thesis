#pragma once

#include "structs.h"

/* given a vertex in a tet, classifies that vertex */
void vertexclassify(struct tetcomplex *mesh,
                    tag v1,
                    tag v2,
                    tag v3,
                    tag v4);

/* given a tet, classifies each of its vertices according to how many
 degrees of freedom it has. */
void vertexclassify_sim(struct tetcomplex *mesh, tag v1);

/* classify the number of degrees of freedom for all tets in the mesh */
void classifyvertices(struct tetcomplex *mesh);
