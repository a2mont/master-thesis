#pragma once

/*****************************************************************************/
/*                                                                           */
/*  Defines                                                                  */
/*                                                                           */
/*****************************************************************************/
#ifndef PI
#define PI 3.141592653589793238462643383279502884197169399375105820974944592308
#endif

#ifndef __cplusplus
typedef enum {false, true} bool;
#endif

/* maximum number of real attributes carried by vertices and interpolated */
#define MAXNUMATTRIBUTES 12

/* do paranoid checks during improvement */
#define IMPROVEPARANOID false

/* a really big floating point number */
#define HUGEFLOAT 1.0e100

#define NOTINLIST -1

/* the sines of some angles */
#define SINEHALF 0.00872653549837
#define SINE1  0.01745240644
#define SINE2  0.0348994967
#define SINE5  0.08715574275
#define SINE10 0.17364817767
#define SINE13 0.22495105434
#define SINE15 0.2588190451
#define SINE20 0.34202014333
#define SINE25 0.42261826174
#define SINE30 0.5
#define SINE35 0.57357643635
#define SINE40 0.64278760969
#define SINE45 0.70710678119
#define SINEEQUILATERAL 0.94280903946

/* when the journal reaches this size, half it's size (remove the older half
 of the entries) */
#define JOURNALHALFSIZE 1000000

/* vertex types */
#define INPUTVERTEX 0
#define CORNERVERTEX 1
#define SEGMENTVERTEX 2
#define FACETVERTEX 3
#define FREEVERTEX 4
#define UNDEADVERTEX -1

/* types of improvement passes */
#define SMOOTHPASS 0
#define TOPOPASS 1
#define CONTRACTPASS 2
#define INSERTPASS 3
#define DESPERATEPASS 4
#define DEFORMPASS 5
/* types of local improvement passes */
#define SMOOTHPASSLOCAL 6
#define TOPOPASSLOCAL 7
#define CONTRACTPASSLOCAL 8
#define INSERTPASSLOCAL 9
#define FORCEINSERTPASSLOCAL 100
/* size control pass */
#define SIZECONTROLPASS 10
#define CONTRACTALLPASS 11

/* maximum number of quality measure components for non-smooth optimization */
#define MAXQUALITYCOMPONENTS 12 

/* number of "thresholded" means used to approximate mesh quality */
#define NUMMEANTHRESHOLDS 7

/* edge cases */
#define NUMEDGECASES 11
#define NOEDGECASE 0
#define FREEFREEEDGE 1
#define FREEFACETEDGE 2
#define FREESEGMENTEDGE 3
#define FREECORNEREDGE 4
#define FACETFACETEDGE 5
#define FACETSEGMENTEDGE 6
#define FACETCORNEREDGE 7
#define SEGMENTSEGMENTEDGE 8
#define SEGMENTCORNEREDGE 9
#define CORNERCORNEREDGE 10

/* number of passes without improvement before static improvement quits */
#define STATICMAXPASSES 3
/* number of desperate insertion passes that can ever be attempted */
#define DESPERATEMAXPASSES 3

/*****************************************************************************/
/*  Topological improvement options                                          */
/*****************************************************************************/

#define TOPOPARANOID false
#define CONTRACTPARANOID false

/* number of tets to allow in a ring around an edge to be removed */
#define MAXRINGTETS 70
#define MAXRINGTETS2 50

/* maximum number of tets in sandwich set replacement during edge removal */
#define MAXNEWTETS 150

/* maximum number of faces in tree for multi-face removal */
#define MAXFACETREESIZE 50

/* minimum quality to allow a 4-verts-on-boundary tet to be created
 by a topological improvement operation */
#define MIN4BOUNDQUAL SINE1

/* minimum improvement required for edge contraction to succeed */
#define MINCONTRACTIMPROVEMENT 1.0e-06

/* the dot product of two normals must be 1+- this value to be considered coplanar */
#define COPLANARTOL 1e-6

/*****************************************************************************/
/*  Smoothing improvement options                                            */
/*****************************************************************************/

/* do paranoid checks of smoothing process */
#define SMOOTHPARANOID false

/* how close to the worst does a function have to be to be in the
 active set? */
#define ACTIVESETFACTOR 1.03

/* how many tets will we allow incident to one vertex for smoothing? */
#define MAXINCIDENTTETS 700

/* minimum step size */
#define MINSTEPSIZE 1.0e-5

/* maximum iterations in non-smooth line search */
#define MAXLINEITER 50

/* rate must be worse by this much to reset alpha */
#define RATEEPSILON 1.0e-6

/* maximum iterations of non smooth optimization */
#define MAXSMOOTHITER 50

/* minimum quality improvement in a smoothing step */
#define MINSMOOTHITERIMPROVE 1.0e-5

/* if d is within this of zero-length, call it zero */
#define DEPSILON 1.0e-5

/* if closest point computation has a factor smaller than this, make it the origin */
#define NEARESTMIN 1.0e-13

/* the minimum improvement of the minimum quality element for a 
 (topo|smoothing|insertion) pass to "succeed" */
#define MINMINIMPROVEMENT 1.0e-15

#define MINLOCALMEANIMPROVE 0.005

/* determines whether facet/segment vertices are smoothed */
#define SMOOTHFACETVERTICES 0x01
#define SMOOTHSEGMENTVERTICES 0x02
#define SMOOTHCORNERVERTICES 0x04

/*****************************************************************************/
/*  Insertion/cavity improvement options                                     */
/*****************************************************************************/

/* do paranoid checks during insertion */
#define INSERTPARANOID true

/* minimum improvement for a submesh */
#define MINSUBMESHIMPROVEMENT 1.0e-3

/* maximum submesh improvement iterations */
#define MAXSUBMESHITERATIONS 8

/* if a tet is within this number of the worst tet, its close to worst */
#define CLOSETOWORST SINE2

/* how much bigger to allow the improvement stack to be when we've got 
 one of the worst tets */ 
#define TRYHARDFACTOR 15
#define TRYHARDMAXSUBMESHITERATIONS 20
#define TRYHARDMINSUBMESHIMPROVEMENT 1e-10

/* minimum quality of an intermediate tet */
#define MINTETQUALITY 1.0e-14
#define MINSIZETETQUALITY 1.0e-10

/* maximum size of stuff for cavity drilling */
#define MAXCAVITYFACES 10000
#define MAXCAVITYTETS 10000

/* minimum improvement of vertex insertion */
#define MININSERTIONIMPROVEMENT 1.0e-6

/* minimum positivity of orientation for a face to be oriented "toward" */
#define MINFACING 1.0e-7

/* factor by which child cavity qualities are increased */
#define CHILDFAVORFACTOR 1.0

/* maximum difference between two qualities where they are considered 'equal' */
#define MAXQUALDIFFERENCE 1.0e-15

/* maximum number of outgoing faces allowed for a tet */
#define MAXOUTFACES 200

/* maximum number of edges in a cavity dag */
#define MAXCAVITYDAGEDGES 50000

/* perform initial/final smooth of all cavity vertices */
#define INITIALCAVITYSMOOTH true
#define FINALCAVITYSMOOTH true

/* maximum stack size for cavity improvement */
#define MAXCAVITYSTACK 250

/* biggest size for cavity heap */ 
#define MAXCAVITYHEAPSIZE MAXCAVITYTETS

/* deepest level a tet can be */
#define MAXCAVDEPTH 1000

/* failure count on which to perform desperate insertion pass */
#define DESPERATEPASSNUM 2
/* if the quality of the mesh is really terrible, don't bother trying to insert 
 up to max insert quality */
#define QUALFROMDESPERATE SINE15
/* if the minimum quality is high, reach even higher by this much in desperate pass */
#define QUALUPFROMDESPERATE SINE1

/* never attempt insertion on more than this many tets, no matter what */
#define MAXINSERTTETS 4000

/*****************************************************************************/
/*  size control options                                                     */
/*****************************************************************************/

#define SIZESPLITPARANOID 0

/* minimum quality of affect tets after size-control edge contraction */
#define MINCONTRACTQUAL 5.0e-2
#define MINSIZESPLITQUAL 5.0e-2
#define MEANEDGESCALE 0.8
/* maximum number of size control iterations */
/*#define MAXSIZEITERS 30*/
#define MAXSIZEITERS 10
#define CONTROLSHORTFAC 1.35
#define CONTROLLONGFAC 0.85
