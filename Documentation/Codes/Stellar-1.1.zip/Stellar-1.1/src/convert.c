/* 
 
 routines to input/output into flat arrays for tets and nodes
 
 */

#include "convert.h"
#include "vector.h"
#include "util.h"

/* do library input of verts */
void inputverts(int numinnodes,
                double innodes[][3],
                double *inattr,
                int numattr,
                struct proxipool *pool,
                struct inputs *in)
{
  char *vertices;
  struct vertexshort *vertexptr;
  size_t vertexbytes;
  arraypoolulong i;
  unsigned int j;
  struct behavior *behave = &improvebehave->behave;
  
  /* do the job of inputvertexfile by setting the number of vertices
   and the number of attributes */
  in->vertexcount = numinnodes;
  in->attribcount = numattr;
  in->firstnumber = 1;
  behave->firstnumber = 1;
  behave->order = 1;
  if (in->attribcount == 0) {
    behave->weighted = 0;
  }
  
  /* now do the job of inputvertex by converting to an array of chars */
  vertexbytes = sizeof(struct vertexshort) +
  (size_t) in->attribcount * sizeof(starreal);
  vertices = (char *) starmalloc((size_t) (in->vertexcount * vertexbytes));
  
  /* Read the vertices. */
  for (i = 0; i < in->vertexcount; i++) {
    vertexptr = (struct vertexshort *) &vertices[i * vertexbytes];
    
    /* Read the vertex coordinates and attributes. */
    for (j = 0; j < 3; j++) 
    {
      vertexptr->coord[j] = (starreal) innodes[i][j];
    }
    
    for (j = 0; j < numattr; ++j)  
    {
      vertexptr->coord[3+j] = (starreal) inattr[i*numattr + j];
    }
  }
  
  /* initialize the proxiool of vertices */
  proxipoolinit(pool, sizeof(struct vertex),
                (size_t) (in->attribcount * sizeof(starreal)),
                behave->verbose);
  /* do the rest of vertex stuff */
  inputverticessortstore(vertices, in, pool);
  starfree(vertices);
}




/* do library input of tets */
void inputtets(int numintets, 
               int intets[][4], 
               struct behavior *behave,
               struct inputs *in,
               struct proxipool *vertexpool,
               struct outputs *out,
               struct tetcomplex *plex)
{
  arraypoolulong corner[4];
  tag cornertag[4];
  arraypoolulong elementnumber;
  arraypoolulong boundaryfacecount;
  int result;
  int i;
  
  in->tetcount = numintets;
  in->tetattribcount = 0;
  
  /*
  printf("In inputtets, in->tetcount is %d\n", (int) in->tetcount);
  */
  
  tetcomplexinit(plex, vertexpool, behave->verbose);
  
  boundaryfacecount = 0;
  for (elementnumber = in->firstnumber; elementnumber < in->tetcount + in->firstnumber; elementnumber++) 
  {
    /* Read the tetrahedron's four vertices. */
    for (i = 0; i < 4; i++) 
    {
      corner[i] = (arraypoolulong) intets[elementnumber-in->firstnumber][i] + 1;
      cornertag[i] = in->vertextags[corner[i] - behave->firstnumber];
    }
    
    vertexcheckorientation(behave, plex, cornertag[0], cornertag[1],
                           cornertag[2], cornertag[3]);
    
    result = tetcomplexinserttet(plex, cornertag[0], cornertag[1],
                                 cornertag[2], cornertag[3]);
    if (result > 0) {
      boundaryfacecount += (result - 6);
    }
  }
  
  out->vertexcount = in->vertexcount;
  out->tetcount = tetcomplextetcount(plex);
  out->boundaryfacecount = boundaryfacecount;
  out->facecount = 2 * out->tetcount + (out->boundaryfacecount / 2);
  out->edgecount = out->vertexcount + out->facecount - out->tetcount - 1;
}




/* convert mesh vertices back to flat array for simulatar */
void outputvertsarray(proxipool *vpool,
                      int *numoutnodes,
                      double **outnodesptr,
                      double **outattrptr)
{
  struct vertex *thevertex;
  double *attributes, *outattr;
  int vnumber = 0;
  tag vertextag;
  double (*outnodes)[3];
  
  if (improvebehave->verbosity > 5)
  {
    printf("Flattening vertex array\n");
  }
  
  /* fetch the number of vertices */
  *numoutnodes = proxipoolobjects(vpool);
  
  /* allocate memory for the output vertex array */
  outnodes = (double (*)[3]) malloc(sizeof(double) * 3 * (*numoutnodes));
  *outnodesptr = (double *) outnodes;
  if (improvebehave->attribcount != 0)
    outattr = (double *) malloc(sizeof(double) * improvebehave->attribcount * (*numoutnodes));
  else
    outattr = NULL;
  *outattrptr = outattr;
  
  /* fetch the first vertex tag */
  vertextag = proxipooliterate(vpool, NOTATAG);
  
  /* iterate through the list of vertices */
  while (vertextag != NOTATAG) 
  {
    /* fetch the vertex from the pool */
    thevertex = (struct vertex *) proxipooltag2object(vpool, vertextag);
    attributes = (double *) proxipooltag2object2(vpool, vertextag);
    
    /* copy into the output array */
    vcopy(thevertex->coord, outnodes[vnumber]);
    attrcopy(attributes, outattr + vnumber*improvebehave->attribcount);
    
    assert(vnumber == vertextag);
    
    if (vnumber < 1000 && false)
    {
      printf("Just flattened vert %d (%g %g %g)\n", vnumber, outnodes[vnumber][0], outnodes[vnumber][1], outnodes[vnumber][2]);
      printf("vnumber = %d, tag = %d\n", vnumber, (int) vertextag);
    }
    
    /* vertices are numbered consecutively. outnodes[i] == proxypooltag2object[i]->coord */
    vnumber++;
    vertextag = proxipooliterate(vpool, vertextag);
    if (vertextag != NOTATAG)
    {
      assert(vnumber == vertextag);
    }
    
    assert(vnumber <= (*numoutnodes));
  }
  assert(vnumber == (*numoutnodes));
}




/* convert mesh tets back to flat array for simulator */
void outputtetsarray(const struct tetcomplex *mesh,
                     int *numouttets,
                     int **outtetsptr)
{
  struct tetcomplexposition position;
  struct proxipool *pool = mesh->vertexpool;
  struct vertex *vertexptr0;
  struct vertex *vertexptr1;
  struct vertex *vertexptr2;
  struct vertex *vertexptr3;
  tag tet[4];
  arraypoolulong tetnumber = 0;
  starreal vol;
  
  int (*outtets)[4] = 0;
  
  if (improvebehave->verbosity > 1)
  {
    printf("Flattening tet array\n");
  }
  
  /* fetch the number of output tetrahedra */
  *numouttets = tetcomplextetcount((struct tetcomplex *)mesh);
  outtets = (int (*)[4]) malloc(sizeof(int) * 4 * (*numouttets));
  
  /* allocate array for output tets */
  *outtetsptr = (int *) outtets;
  
  /* Iterate through all the (non-ghost) tetrahedra in the complex. */
  tetcomplexiteratorinit((struct tetcomplex*)mesh, &position);
  tetcomplexiteratenoghosts(&position, tet);
  while (tet[0] != STOP) 
  {
    /* fetch tet vertices */
    vertexptr0 = (struct vertex *) proxipooltag2object(pool, tet[0]);
    vertexptr1 = (struct vertex *) proxipooltag2object(pool, tet[1]);
    vertexptr2 = (struct vertex *) proxipooltag2object(pool, tet[2]);
    vertexptr3 = (struct vertex *) proxipooltag2object(pool, tet[3]);
    
    /* copy this tet */
    /*
     outtets[tetnumber][0] = vertexptr0->number;
     outtets[tetnumber][1] = vertexptr1->number;
     outtets[tetnumber][2] = vertexptr2->number;
     outtets[tetnumber][3] = vertexptr3->number;
     */
    /* copy the tag number directly? */
    outtets[tetnumber][0] = tet[0] + 1;
    outtets[tetnumber][1] = tet[1] + 1;
    outtets[tetnumber][2] = tet[2] + 1;
    outtets[tetnumber][3] = tet[3] + 1;
    
    if (tetnumber < 1000 && 0)
    {
      printf("Just flattened tet %d (%d %d %d %d), tags (%d %d %d %d)\n", (int) tetnumber, (int) vertexptr0->number, (int) vertexptr1->number, (int) vertexptr2->number, (int) vertexptr3->number, (int)tet[0], (int)tet[1], (int)tet[2], (int)tet[3]);
      vol = tetvolume((struct tetcomplex*)mesh, tet[0], tet[1], tet[2], tet[3]);
      printf("    has volume %g\n", vol);
      if (vol <= 0.0) starexit(-1);
    }
    
    tetnumber++;
    tetcomplexiteratenoghosts(&position, tet);
    
    assert(tetnumber <= (*numouttets));
  }
  assert(tetnumber == (*numouttets));
}


