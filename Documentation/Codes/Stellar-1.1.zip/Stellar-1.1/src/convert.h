#pragma once

#include "structs.h"

/* do library input of verts */
void inputverts(int numinnodes,
                double innodes[][3],
                double *inattr,
                int numattr,
                struct proxipool *pool,
                struct inputs *in);


/* do library input of tets */
void inputtets(int numintets, 
               int intets[][4], 
               struct behavior *behave,
               struct inputs *in,
               struct proxipool *vertexpool,
               struct outputs *out,
               struct tetcomplex *plex);


/* convert mesh vertices back to flat array for simulatar */
void outputvertsarray(proxipool *vpool,
                      int *numoutnodes,
                      double **outnodesptr,
                      double **outattrptr);


/* convert mesh tets back to flat array for simulator */
void outputtetsarray(const struct tetcomplex *mesh,
                     int *numouttets,
                     int **outtetsptr);

