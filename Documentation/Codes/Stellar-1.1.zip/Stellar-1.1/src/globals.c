/*****************************************************************************/
/*                                                                           */
/*  Global variables                                                         */
/*                                                                           */
/*****************************************************************************/

#include "structs.h"

/* global improvement behavior struct pointer (passed by prepare) */
struct improvebehavior *improvebehave;

/* global statistics */
struct improvestats improvestats;
