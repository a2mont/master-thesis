/*****************************************************************************/
/*                                                                           */
/*  driver functions to direct mesh improvement                              */
/*                                                                           */
/*****************************************************************************/

#include "improve.h"
#include "util.h"
#include "arraypoolstack.h"
#include "timer.h"
#include "topological.h"
#include "insertion.h"
#include "quality.h"
#include "classify.h"
#include "print.h"
#include "size.h"
#include "smoothing.h"
#include "quadric.h"

/* see if new means contains any better means. if so,
   update best means and return true */
bool meanimprove(starreal bestmeans[],
                 starreal newmeans[],
                 int passtype)
{
    int i;
    bool foundbetter = false;
    starreal minimprovement = improvebehave->minstepimprovement;
    
    if (passtype == INSERTPASS)
    {
        minimprovement = improvebehave->mininsertionimprovement;
    }
    if (passtype == DESPERATEPASS)
    {
        minimprovement = improvebehave->mininsertionimprovement;
    }
    
    for (i=0; i<NUMMEANTHRESHOLDS; i++)
    {
        if (newmeans[i] > bestmeans[i])
        {
            /* see if it beats it by the required threshold */
            if (newmeans[i] - bestmeans[i] > minimprovement)
            {
                if (improvebehave->verbosity > 4)
                {
                    textcolor(BRIGHT, GREEN, BLACK);
                    printf("mean improvement = %g, that's enough for success (needs %g)\n", newmeans[i] - bestmeans[i], minimprovement);
                    textcolor(RESET, WHITE, BLACK);
                }
                foundbetter = true;
            }
            else
            {
                if (improvebehave->verbosity > 4)
                {
                    printf("mean improvement = %g, positive but not enough (needs %g)!\n", newmeans[i] - bestmeans[i], minimprovement);
                }
            }
            
            bestmeans[i] = newmeans[i];
        }
    }
    
    if (improvebehave->verbosity > 4)
    {
        printf("overall, mean improvement success = %d\n", foundbetter);
    }
    
    return foundbetter;
}

/* run a pass (smoothing, topo, insertion). return true
   if we have reached the desired quality */
bool pass(int passtype,
          struct tetcomplex* mesh,
          struct arraypoolstack* tetstack,
          starreal threshold,
          bool *minsuccess,
          bool *meansuccess,
          int passnum,
          starreal bestmeans[],
          struct behavior *behave,
          struct inputs *in,
          struct proxipool *vertexpool)
{
    /* quality vars */
    starreal minqualbefore, minqualafter;
    starreal meanqualbefore[NUMMEANTHRESHOLDS], meanqualafter[NUMMEANTHRESHOLDS];
    starreal minedge, maxedge, meanedge;
    
#ifndef NO_TIMER
    /* timing vars */
    struct timeval tv1, tv2;
#endif /* not NO_TIMER */
    
    /* smoothing vars */
    int smoothkinds = 0;
    
    bool desperate = false;
    
    if (improvebehave->facetsmooth) smoothkinds |= SMOOTHFACETVERTICES;
    if (improvebehave->segmentsmooth) smoothkinds |= SMOOTHSEGMENTVERTICES;
    if (improvebehave->cornersmooth) smoothkinds |= SMOOTHCORNERVERTICES;
    
    assert(passtype == SMOOTHPASS ||
           passtype == TOPOPASS ||
           passtype == CONTRACTPASS ||
           passtype == CONTRACTALLPASS ||
           passtype == INSERTPASS ||
           passtype == DESPERATEPASS);
    
    if (improvebehave->verbosity > 1)
    {
        textcolor(BRIGHT, MAGENTA, BLACK);
        printf("\nPerforming improvement pass %d", passnum);
        switch (passtype)
        {
            case SMOOTHPASS:
                printf(" (smoothing)\n");
                break;
            case TOPOPASS:
                printf(" (topological)\n");
                break;
            case CONTRACTALLPASS:
            case CONTRACTPASS:
                printf(" (edge contraction)\n");
                break;
            case INSERTPASS:
            case DESPERATEPASS:
                printf(" (insertion)\n");
                break;
            default:
                printf("whoa, I know what kind of pass %d is\n", passtype);
                starexit(1);
        }
        textcolor(RESET, WHITE, BLACK);
    }
           
    /* start out by appropriately filling the stack */
    if (passtype != CONTRACTALLPASS)
    {
        fillstackqual(mesh, tetstack, threshold, meanqualbefore, &minqualbefore);
    }
    else
    {
        /* in the case of contraction, just get one tet for each edge */
        filledgestacks(mesh, tetstack, NULL, HUGEFLOAT, 0.0, &minedge, &maxedge, &meanedge);
    }
    
    /* get global worst quality; this is what must improve */
    meshquality(mesh, meanqualbefore, &minqualbefore);
    
    /* save timer before pass */
#ifndef NO_TIMER
    gettimeofday(&tv1, NULL);
#endif /* not NO_TIMER */    

    /* run the actual pass */
    switch (passtype)
    {
        case SMOOTHPASS:
            smoothpass(mesh, 
                       tetstack, 
                       NULL, NULL, 
                       threshold, 
                       bestmeans, 
                       meanqualafter, 
                       &minqualafter, 
                       smoothkinds, 
                       false);
#ifndef NO_TIMER
            gettimeofday(&tv2, NULL);
            improvestats.smoothmsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
            break;
        case TOPOPASS:
            topopass(mesh, 
                     tetstack, 
                     NULL, 
                     bestmeans, 
                     meanqualafter, 
                     &minqualafter, 
                     false);
#ifndef NO_TIMER
            gettimeofday(&tv2, NULL);
            improvestats.topomsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
            break;
        case CONTRACTPASS:
            contractworst(mesh, 
                          improvebehave->insertthreshold, 
                          bestmeans, 
                          meanqualafter, 
                          &minqualafter, 
                          true);
#ifndef NO_TIMER
            gettimeofday(&tv2, NULL);
            improvestats.contractmsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
            break;
        case CONTRACTALLPASS:
            contractpass(mesh, 
                         tetstack,
                         NULL,
                         bestmeans, 
                         meanqualafter, 
                         &minqualafter, 
                         true,
                         false);
#ifndef NO_TIMER
            gettimeofday(&tv2, NULL);
            improvestats.contractmsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
            break;
        case DESPERATEPASS:
            desperate = true;
        case INSERTPASS:
            worsttetattack(mesh, 
                           improvebehave->insertthreshold, 
                           meanqualafter, 
                           &minqualafter, 
                           desperate,
                           false);
#ifndef NO_TIMER
            gettimeofday(&tv2, NULL);
            improvestats.insertmsec += msecelapsed(tv1, tv2);
# endif /* not NO_TIMER */
            if (desperate)
            {
                *meansuccess = meanimprove(bestmeans, meanqualafter, DESPERATEPASS);
            }
            else
            {
                *meansuccess = meanimprove(bestmeans, meanqualafter, INSERTPASS);
            }
            break;
        default:
            printf("i don't know how to run pass type %d, dying\n", passtype);
            starexit(1);
    }
    
    /* check for success */
    *meansuccess = meanimprove(bestmeans, meanqualafter, passtype);
    if (minqualafter - minqualbefore < MINMINIMPROVEMENT)
    {
        *minsuccess = false;
    }
    else
    {
        *minsuccess = true;
    }
    
    
#if 0
    /* MW: all this should be handled by the quality metric, or rather, use dynamic meshing */
    /* check whether we have reached the goal quality for minimum or maximum angle */
    if (minqualafter > goalangleminsine || minqualafter > goalanglemaxsine)
    {
        /* sine of target angles */
        starreal biggestangle;
        starreal smallestangle;
      
        /* compute the extreme angles */
        getextremeangles(behave, mesh, &smallestangle, &biggestangle);
        
        /* we must have reached one of these angles */
        /* not necessarily true for non-angle based quality measures */
        /* assert(smallestangle > improvebehave->goalanglemin || biggestangle < improvebehave->goalanglemax); */
        
        if (improvebehave->verbosity > 3)
        {
            if (smallestangle > improvebehave->goalanglemin)
            {
                printf("Smallest angle %g degrees in ABOVE goal angle of %g degrees\n", smallestangle, improvebehave->goalanglemin);
            }
            else
            {
                printf("Smallest angle %g degrees is BELOW goal angle of %g degrees.\n", smallestangle, improvebehave->goalanglemin);
            }
        
            if (biggestangle < improvebehave->goalanglemax)
            {
                printf("Largest angle %g degrees is BELOW goal angle of %g degrees.\n", biggestangle, improvebehave->goalanglemax);
            }
            else
            {
                printf("Largest angle %g degrees is ABOVE goal angle of %g degrees.\n", biggestangle, improvebehave->goalanglemax);
            }
        }
        
        /* if we've reached both thresholds, let the main loop know we're done */
        if (smallestangle > improvebehave->goalanglemin && biggestangle < improvebehave->goalanglemax)
        {
            if (improvebehave->verbosity > 1)
            {
                textcolor(BRIGHT, GREEN, BLACK);
                printf("Both min and max goal angles reached, stopping improvement.\n");
                textcolor(RESET, WHITE, BLACK);
            }
            return true;
        }
    }
#endif  
    
    /* Bryan's simple replacement: quit if we've reached the goal quality*/
    if (minqualafter >= improvebehave->goalquality)
    {
        printf("Goal quality %g reached, halting improvement.\n", improvebehave->goalquality);
        return true;
    } 
    
    return false;
}

/* pre-improvement initialization code */
void improveinit(struct tetcomplex *mesh,
                 struct proxipool *vertexpool,
                 struct arraypoolstack *tetstack,
                 struct behavior *behave,
                 struct inputs *in,
                 starreal bestmeans[NUMMEANTHRESHOLDS])
{
    int consistent;
    starreal minqualbefore;
    starreal meanqualbefore[NUMMEANTHRESHOLDS];
    starreal worstin;
    starreal worstinitqual;
    int i;
  
    improvebehave->attribcount = in->attribcount;
  
    if (improvebehave->attribcount > MAXNUMATTRIBUTES) {
      printf("Requested %d attributes, but MAXNUMATTRIBUTES is %d. Dying.", improvebehave->attribcount, MAXNUMATTRIBUTES);
      starexit(1);
    }
  
    for (i=0; i<NUMMEANTHRESHOLDS; i++)
    {
        bestmeans[i] = 0.0;
    }
    
    /* assure that the mesh is consistent at the outset */
    consistent = mytetcomplexconsistency(mesh);
    assert(consistent);
    
    improvestats.startnumverts = countverts(vertexpool);
    improvestats.startnumtets = counttets(mesh);
    
    if (improvebehave->verbosity > 0)
    {
        printf("Improving mesh.\n");
    }
    
    /* this array pool stores information on vertices */
    arraypoolinit(&improvebehave->vertexinfo, sizeof(struct vertextype), LOG2TETSPERSTACKBLOCK, 0);
    
    /* stack of tets to be improved */
    stackinit(tetstack, sizeof(struct improvetet));
    
    /* this stack stores a journal of improvement steps */
    stackinit(&improvebehave->journal, sizeof(struct journalentry));
    
    /* print out the worst input angle */
    worstin = worstinputangle(mesh);
    if (improvebehave->verbosity > 2)
    {
        printf("The worst input angle is %g radians (%g degrees).\n", worstin, worstin * (180.0 / PI));
    }
    
    /* classify degrees of freedom of all vertices */
    if (improvebehave->verbosity > 2)
    {
        printf("Performing vertex classification.\n");
    }
    classifyvertices(mesh);
    
    /* compute surface quadric information */
    if (improvebehave->verbosity > 2)
    {
        printf("Computing intial surface quadrics\n");
    }
    collectquadrics(mesh);
    if (improvebehave->verbosity > 2)
    {
        checkquadrics(mesh);
    }
    
    /* make sure that all the tets are right-side out before we start */
    worstinitqual = worstquality(mesh);
    if (worstinitqual <= 0.0)
    {
        textcolor(BRIGHT, RED, BLACK);
        printf("***** ALERT Input mesh has non-positive worst quality of %g, dying *****\n", worstinitqual);
        textcolor(RESET, WHITE, BLACK);
        assert(false);
    }
    
    /* build stack for initial quality evaluation */
    fillstackqual(mesh, tetstack, HUGEFLOAT, meanqualbefore, &minqualbefore);
    meanimprove(bestmeans, meanqualbefore, SMOOTHPASS);
    
    /* set initial minimum and thresholded mean qualities */
    for (i=0; i<NUMMEANTHRESHOLDS; i++)
    {
        improvestats.startmeanquals[i] = meanqualbefore[i];
    }
    improvestats.startworstqual = minqualbefore;

    /* fetch the extreme angles */
    getextremeangles(behave, mesh, &improvestats.startminangle, &improvestats.startmaxangle);  
}

/* clean up after mesh improvement */
void improvedeinit(struct tetcomplex *mesh,
                   struct proxipool *vertexpool,
                   struct arraypoolstack *tetstack,
                   struct behavior *behave,
                   struct inputs *in)
{
    int consistent;
    starreal minqualbefore;
    starreal meanqualbefore[NUMMEANTHRESHOLDS];
    starreal worstin;
    int i;
    
    /* check final mesh consistency */
    consistent = mytetcomplexconsistency(mesh);
    if (improvebehave->verbosity > 3)
    {
        printf("\nin the end mesh consistent = %d\n", consistent);
    }
    assert(consistent);
    
    if (IMPROVEPARANOID)
    {
        /* check that the final worst boundary dihedral matches start */
        printf("The worst boundary angle at the start: %g radians (%g degrees).\n", worstin, worstin * (180.0 / PI));
        worstin = worstinputangle(mesh);
        printf("The worst boundary angle at the end: %g radians (%g degrees).\n", worstin, worstin * (180.0 / PI));
    }
    
    if (improvebehave->verbosity > 3)
    {
        /* print out the properties of the worst tetrahedra */
        worsttetreport(mesh, 5.0);
    }
    
    /* record final qualities */
    fillstackqual(mesh, tetstack, HUGEFLOAT, meanqualbefore, &minqualbefore);
    for (i=0; i<NUMMEANTHRESHOLDS; i++)
    {
        improvestats.finishmeanquals[i] = meanqualbefore[i];
    }
    
    improvestats.finishnumverts = countverts(vertexpool);
    improvestats.finishnumtets = counttets(mesh);
    
    /* print final mesh improvement statistics */
    if (improvebehave->verbosity > 2)
    {
        printstats(mesh);
        checkquadrics(mesh);
    }
    
    /* clean up array pools */
    stackdeinit(tetstack);
}

/* top-level function to perform static mesh improvement */
void staticimprove(struct behavior *behave,
                   struct inputs *in,
                   struct proxipool *vertexpool,
                   struct tetcomplex *mesh)
{
    struct arraypoolstack tetstack;         /* stack of tets to be improved */
    int passnum = 1;                        /* current improvement pass */
    int roundsnoimprovement = 0;            /* number of passes since mesh improved */
    bool meansuccess = false;               /* thresholded mean success */
    bool minsuccess = false;                /* minimum quality success */
    starreal bestmeans[NUMMEANTHRESHOLDS];  /* current best thresholded means */
    bool stop, stop1 = false;               /* whether to continue improvement */
    int numdesperate = 0;
    
#ifndef NO_TIMER
    /* timing vars */
    struct timeval tv0, tv2;
    /* get initial time */
    gettimeofday(&tv0, NULL);
    improvestats.starttime = tv0;
#endif /* not NO_TIMER */
    
    /* perform improvement initialization */
    improveinit(mesh, vertexpool, &tetstack, behave, in, bestmeans);
    
    if (improvebehave->verbosity > 1) sizereport(mesh);
    
    /* force off dynamic improvement flag */
    improvebehave->dynamic = false;
    
    /********** INITIAL SMOOTHING AND TOPO PASSES **********/
    
    /* initial global smoothing pass */
    stop = pass(SMOOTHPASS, mesh, &tetstack, 
                HUGEFLOAT, &minsuccess, &meansuccess, passnum++, bestmeans, 
                behave, in, vertexpool);
  
    if(!improvebehave->progress_cb(improvebehave)) {
      goto cleanup;
    }
  
    /* initial global topological improvement pass */
    stop = pass(TOPOPASS, mesh, &tetstack,
                HUGEFLOAT, &minsuccess, &meansuccess, passnum++, bestmeans,
                behave, in, vertexpool);

    if(!improvebehave->progress_cb(improvebehave)) {
      goto cleanup;
    }
  
    /* initial global contraction improvement pass */
    stop = pass(CONTRACTALLPASS, mesh, &tetstack,
                HUGEFLOAT, &minsuccess, &meansuccess, passnum++, bestmeans,
                behave, in, vertexpool);
    
    if(!improvebehave->progress_cb(improvebehave)) {
      goto cleanup;
    }
  
  /***************** SIZE CONTROL *************************/
    if (improvebehave->sizing)
    {
        passnum = sizecontrol(mesh, behave, in, vertexpool, false);
        
        if(!improvebehave->progress_cb(improvebehave)) {
          goto cleanup;
        }
    }
    
    /*************** MAIN IMPROVEMENT LOOP ******************/
    while (roundsnoimprovement < STATICMAXPASSES)
    {
        /* if the mesh is already fine, stop improvement */
        if (stop) break;
        
        /* perform a smoothing pass */
        stop = pass(SMOOTHPASS, mesh, &tetstack, 
                    HUGEFLOAT, &minsuccess, &meansuccess, passnum++, bestmeans,
                    behave, in, vertexpool);

        if (stop) break;

        if(!improvebehave->progress_cb(improvebehave)) {
          break;
        }      
        
        /* if the smoothing pass failed to sufficiently improve the mesh */
        if ((minsuccess == false) && (meansuccess == false))
        {
            /* perform a global topological pass */
            stop = pass(TOPOPASS, mesh, &tetstack,
                        HUGEFLOAT, &minsuccess, &meansuccess, passnum++, bestmeans, 
                        behave, in, vertexpool);
            if (stop) break;
            
            if(!improvebehave->progress_cb(improvebehave)) {
              break;
            }      

            /* if the topo pass also failed */
            if ((minsuccess == false) && (meansuccess == false))
            {
                /* perform a contraction and insertion pass */
                if (improvebehave->enableinsert)
                {
                    /* potentially start with a pass of edge contraction */
                    if (improvebehave->edgecontraction)
                    {
                      stop1 = pass(CONTRACTPASS, mesh, &tetstack, 
                                   HUGEFLOAT, &minsuccess, &meansuccess, passnum++, bestmeans, 
                                   behave, in, vertexpool);
                      if(!improvebehave->progress_cb(improvebehave)) {
                        break;
                      }      
                    }
                    else
                    {
                        stop1 = false;
                    }
                    
                    if (roundsnoimprovement == 1 && numdesperate < DESPERATEMAXPASSES)
                    {
                        stop = pass(DESPERATEPASS, mesh, &tetstack, 
                                    HUGEFLOAT, &minsuccess, &meansuccess, passnum++, bestmeans, 
                                    behave, in, vertexpool);
                        if(!improvebehave->progress_cb(improvebehave)) {
                          break;
                        }
                        numdesperate++;
                        if (improvebehave->verbosity > 2)
                        {
                            printf("Just completed desperate pass %d / %d\n", numdesperate, DESPERATEMAXPASSES);
                        }
                        if (stop || stop1) break;
                    }
                    else
                    {
                        stop = pass(INSERTPASS, mesh, &tetstack, 
                                    HUGEFLOAT, &minsuccess, &meansuccess, passnum++, bestmeans, 
                                    behave, in, vertexpool);
                        if(!improvebehave->progress_cb(improvebehave)) {
                          break;
                        }      
                        if (stop || stop1) break;
                    }
                }
            }
        }
        /* if this pass failed to see any improvement, note it */
        if ((minsuccess == false) && (meansuccess == false))
        {
            roundsnoimprovement++;
            if (improvebehave->verbosity > 2)
            {
                textcolor(BRIGHT, RED, BLACK);
                printf("Last %d passes there has been no improvement.\n", roundsnoimprovement);
                textcolor(RESET, WHITE, BLACK);
            }
        }
        /* reset number of rounds on smoothing success */
        else 
        {
            if (improvebehave->verbosity > 2)
            {
                textcolor(BRIGHT, GREEN, BLACK);
                printf("Resetting failed passes count on success.\n");
                textcolor(RESET, WHITE, BLACK);
            }
            roundsnoimprovement = 0;
        }
    }
  
    /******************** END MAIN IMPROVEMENT LOOP **********************/
cleanup:  
  
#ifndef NO_TIMER
    /* record total time */
    gettimeofday(&tv2, NULL);
    improvestats.totalmsec = msecelapsed(tv0, tv2);
#endif /* not NO_TIMER */
    
    /* perform post-improvement cleanup */
    improvedeinit(mesh, vertexpool, &tetstack, behave, in);
}
