/*****************************************************************************/
/*                                                                           */
/*  driver functions to direct dynamic mesh improvement                      */
/*                                                                           */
/*****************************************************************************/

#include "improvedyn.h"
#include "improve.h"
#include "util.h"
#include "arraypoolstack.h"
#include "timer.h"
#include "topological.h"
#include "insertion.h"
#include "quality.h"
#include "classify.h"
#include "print.h"
#include "size.h"
#include "smoothing.h"
#include "quadric.h"
#include "journal.h"

#define MAXLOCALIMPROVEITERS 10 /*maximum number of iterations to attempt local improvement */

#define VOLUME_EPSILON 1.0e-10	/* Be robust against roundoff error in mesh volume calculations */

/* run an pass (smoothing, topo, insertion). return true
   if we have reached the desired quality */
bool localpass(int passtype,
               int passnum,
               struct tetcomplex* mesh,
               struct arraypoolstack* tetstack,
               starreal threshold,
               bool *minsuccess,
               starreal *minqualafter)
{
    /* quality vars */
    starreal minqualbefore;
    starreal meanqualbefore[NUMMEANTHRESHOLDS];
    starreal meanqualafter[NUMMEANTHRESHOLDS];
    bool success = false;
    struct arraypoolstack outstack;
    struct arraypoolstack influencestack;
    
#ifndef NO_TIMER
    /* timing vars */
    struct timeval tv1, tv2;
#endif /* not NO_TIMER */

    /* smoothing vars */
    int smoothkinds = 0;
  
    char *passname;
    char msg[80];

    if (improvebehave->facetsmooth) smoothkinds |= SMOOTHFACETVERTICES;
    if (improvebehave->segmentsmooth) smoothkinds |= SMOOTHSEGMENTVERTICES;
    if (improvebehave->cornersmooth) smoothkinds |= SMOOTHCORNERVERTICES;
    
    /* output and influence stacks */
    stackinit(&outstack, sizeof(struct improvetet));
    stackinit(&influencestack, sizeof(struct improvetet));
    
    assert(passtype == SMOOTHPASSLOCAL ||
           passtype == TOPOPASSLOCAL ||
           passtype == INSERTPASSLOCAL ||
           passtype == FORCEINSERTPASSLOCAL ||
           passtype == CONTRACTPASSLOCAL);

    minqualbefore = HUGEFLOAT;  
  
    /* compute the stack quality before we start */
    /*
    stackquality(mesh, 
                 tetstack,
                 meanqualbefore,
                 &minqualbefore);
    */
    meshquality(mesh, meanqualbefore, &minqualbefore);
  
    switch (passtype)
    {
      case SMOOTHPASSLOCAL:
        passname = "smoothing";
        break;
      case TOPOPASSLOCAL:
        passname = "topological";
        break;
      case INSERTPASSLOCAL:
        passname = "insertion";
        break;
      case FORCEINSERTPASSLOCAL:
        passname = "forced insertion";
        break;
      case CONTRACTPASSLOCAL:
        passname = "contraction";
        break;
      default:
        passname = "";
        printf("Whoa, I don't know what kind of pass %d is\n", passtype);
        starexit(1);
    }
  
    if (improvebehave->verbosity > 1)
    {
        textcolor(BRIGHT, MAGENTA, BLACK);
        printf("Performing local improvement pass %d on stack of %lu tets, min qual of %g (%s)\n", passnum, tetstack->top+1, minqualbefore, passname);
        textcolor(RESET, WHITE, BLACK);
    }
  
#ifdef WIN32
	  sprintf_s(msg, 80, "Start local %s pass", passname);
#else
    sprintf(msg, "Start local %s pass", passname);
#endif
    journalmarker(msg);

#ifndef NO_TIMER
    /* save timer before pass */
    gettimeofday(&tv1, NULL);
#endif /* not NO_TIMER */
    
    /* run the actual pass */
    switch (passtype)
    {
        case SMOOTHPASSLOCAL:
            success = smoothpass(mesh, 
                       tetstack, 
                       &outstack,
                       &influencestack, 
                       threshold, 
                       NULL,
                       meanqualafter, 
                       minqualafter, 
                       smoothkinds, 
                       false);
            /* copy output stack back to input */
            if (success) 
            {
                copystack(&influencestack, tetstack);
            }
            else
            {
                copystack(&outstack, tetstack);
            }
#ifndef NO_TIMER
            gettimeofday(&tv2, NULL);
            improvestats.smoothlocalmsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
            break;
        case TOPOPASSLOCAL:
            success = topopass(mesh, 
                     tetstack, 
                     &outstack, 
                     NULL, 
                     meanqualafter, 
                     minqualafter,
                     false);
            /* copy output stack back to input */
            copystack(&outstack, tetstack);
#ifndef NO_TIMER
            gettimeofday(&tv2, NULL);
            improvestats.topolocalmsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
            break;
        case INSERTPASSLOCAL:
            success = insertpass(mesh,
                       tetstack,
                       &outstack,
                       meanqualafter,
                       minqualafter,
                       threshold * 1.55,
                       false,
                       false);
            /* copy output stack back to input */
            copystack(&outstack, tetstack);
#ifndef NO_TIMER
            gettimeofday(&tv2, NULL);
            improvestats.insertlocalmsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
            break;
      case FORCEINSERTPASSLOCAL:
        success = insertpass(mesh,
                             tetstack,
                             &outstack,
                             meanqualafter,
                             minqualafter,
                             threshold * 1.55,
                             false,
                             true);
        /* copy output stack back to input */
        copystack(&outstack, tetstack);
#ifndef NO_TIMER
        gettimeofday(&tv2, NULL);
        improvestats.insertlocalmsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
        break;
      case CONTRACTPASSLOCAL:
          success = contractpass(mesh,
                     tetstack,
                     &outstack,
                     NULL,
                     meanqualafter,
                     minqualafter,
                     false,
                     false);
          /* copy output stack back to input */
          copystack(&outstack, tetstack);
#ifndef NO_TIMER
          gettimeofday(&tv2, NULL);
          improvestats.contractlocalmsec += msecelapsed(tv1, tv2);
#endif /* not NO_TIMER */
          break;
        default:
            printf("i don't know how to run pass type %d, dying\n", passtype);
            starexit(1);
    }
    
#ifdef WIN32
	sprintf_s(msg, 80, "Done local %s pass", passname);
#else
    sprintf(msg, "Done local %s pass", passname);
#endif
    journalmarker(msg);
  
    /* mesure tet quality, not stack quality */
    meshquality(mesh, meanqualafter, minqualafter);
  
    if (*minqualafter - minqualbefore < MINMINIMPROVEMENT)
    {
        *minsuccess = false;
    }
    else
    {
        *minsuccess = true;
    }
    
    /* free output stacks */
    stackdeinit(&outstack);
    stackdeinit(&influencestack);
    
    if (improvebehave->verbosity > 1)
    {
        if (success)
        {
            printf("Pass succeeded. Output stack has %lu tets.\n", tetstack->top+1);
        }
        else
        {
            printf("Pass failed.\n Output stack has %lu tets.\n", tetstack->top+1);
        }
    }
    
    /* the minimum quality had better not have worsened (unless we're forcing our luck here)!*/
    if (passtype != FORCEINSERTPASSLOCAL)
      assert(*minqualafter >= minqualbefore);
    
    if (success) return true;
      return false;
}

/* add all tets adjacent to a tet in the stack a to the stack,
   taking care to avoid duplicates */
void stackaddneighbors(struct tetcomplex *mesh,
                       struct arraypoolstack *a)
{
    int i,j,k;
    struct arraypoolstack neighbors;
    
    struct improvetet *fromtet, *neightet;
    
    int numincident;
    bool noghosts;
    /* a list of all the tets incident to a vertex */
    tag incidenttettags[MAXINCIDENTTETS][4];
    
    /* indices to check each vertex's incident tets */
    int indices[][4] = {
                           {0, 1, 2, 3},
                           {1, 0, 3, 2},
                           {2, 0, 1, 3},
                           {3, 0, 2, 1}
                       };
    
    /* setup stack of neighbor tets */
    stackinit(&neighbors, sizeof(struct improvetet));
    
    /* for each tet in a */
    for (i=0; i<=a->top; i++)
    {
        /* get the right tet out of stack */
        fromtet = (struct improvetet *) arraypoolfastlookup(&(a->pool), (unsigned long) i);
        
        /* check that this tet still exists */
        if (tetexists(mesh, 
                      fromtet->verts[0],
                      fromtet->verts[1],
                      fromtet->verts[2],
                      fromtet->verts[3]) == false)
        {
            continue;
        }
        
        /* for each vertex of this tet */
        for (j=0; j<4; j++)
        {
            assert(tetexists(mesh,
                             fromtet->verts[indices[j][0]],
                             fromtet->verts[indices[j][1]],
                             fromtet->verts[indices[j][2]],
                             fromtet->verts[indices[j][3]]));
            
            /* get all incident tets */
            numincident = 0;
            getincidenttets(mesh, 
                            fromtet->verts[indices[j][0]],
                            fromtet->verts[indices[j][1]],
                            fromtet->verts[indices[j][2]],
                            fromtet->verts[indices[j][3]], 
                            incidenttettags,
                            &numincident,
                            &noghosts);
            assert(numincident > 0);
            
            /* push each one onto the neighbor stack */
            for (k=0; k<numincident; k++)
            {
                neightet = (struct improvetet *) stackpush(&neighbors);
                neightet->verts[0] = incidenttettags[k][indices[j][0]];
                neightet->verts[1] = incidenttettags[k][indices[j][1]];
                neightet->verts[2] = incidenttettags[k][indices[j][2]];
                neightet->verts[3] = incidenttettags[k][indices[j][3]];
            }
        }
    }
    
    if (improvebehave->verbosity > 1)
    {
        printf("In stackaddneighbors, built stack of %lu neighbors from %lu in input\n", neighbors.top+1, a->top+1);
    }
    
    /* append the neighbor stack onto a, adding only tets that are not already there */
    appendstack(&neighbors, a);
    
    if (improvebehave->verbosity > 1)
    {
        printf("After appending, a has %lu tets\n", a->top+1);
    }
    
    assert(numincident > 0);
}

/* TEST ROUTINE ONLY */
void localimprovestaticish(struct tetcomplex *mesh,
                  struct arraypoolstack *a,
                  starreal *minqual,
                  starreal q)
{
    bool success = false;
    int iter = 0;
    int subiter = 0;
    int oldstacksize = a->top+1;
    
    *minqual = 0.0;
    
    while (*minqual < q && iter < MAXLOCALIMPROVEITERS*10)
    {
        subiter = 0;
        
        /* try smoothing */
        do
        {
            success = localpass(SMOOTHPASSLOCAL, iter, mesh, a, q, &success, minqual);
        
            if (improvebehave->verbosity > 1)
            {
                printf("After SMOOTHING, stack minimum quality is %g (goal %g)\n", *minqual, q);
            }
            
            if (*minqual >= q) return;
        }
        while (success && subiter < MAXLOCALIMPROVEITERS);
        
        /* start with topological improvement as long as it helps */
        do
        {
            success = localpass(TOPOPASSLOCAL, iter, mesh, a, q, &success, minqual);
            subiter++;
            
            if (improvebehave->verbosity > 1)
            {
                printf("After TOPOLOGICAL improvement, stack minimum quality is %g (goal %g)\n", *minqual, q);
            }

            /* stop at the topo pass if that's enough */
            if (*minqual >= q) return;
        }
        while (success && subiter < MAXLOCALIMPROVEITERS && false);
        
        subiter = 0;
        
        /* now try contraction */
        if (improvebehave->edgecontraction)
        {
            do
            {
                success = localpass(CONTRACTPASSLOCAL, iter, mesh, a, q, &success, minqual);
                subiter++;
                
                if (improvebehave->verbosity > 1)
                {
                    printf("After CONTRACTION, stack minimum quality is %g (goal %g)\n", *minqual, q);
                }
                
                if (*minqual >= q) return;
            }
            while (success && subiter < MAXLOCALIMPROVEITERS && false);
        }
        
        subiter = 0;
        
        /* now try insertion */
        do
        {
            success = localpass(INSERTPASSLOCAL, iter, mesh, a, q, &success, minqual);
            subiter++;
            
            if (improvebehave->verbosity > 1)
            {
                printf("After INSERTION, stack minimum quality is %g (goal %g)\n", *minqual, q);
            }

            if (*minqual >= q) return;
        }
        while (success && subiter < MAXLOCALIMPROVEITERS && false);
        
        subiter = 0;
        
        /* if the stack is still the same size as it was last iteration,
           enlarge it! */
        if (a->top+1 == oldstacksize)
        {
            if (improvebehave->verbosity > 1)
            {
                printf("Enlarging stack by adding all neighors\n");
                stackaddneighbors(mesh, a);
            }
        }
        else
        {
            if (improvebehave->verbosity > 1)
            {
                printf("NOT Enlarging stack, before it was %d, now its %lu\n", oldstacksize, a->top+1);
            }
        }
        
        oldstacksize = a->top+1;
        
        iter++;
    }
}

/* perform mesh improvement on a set of tetrahedra while trying to 
   limit the part of the mesh affected by improvement operations */
void localimprove(struct tetcomplex *mesh,
                  struct arraypoolstack *a,
                  starreal *minqual,
                  starreal q, 
                  int max_local_iterations,
                  bool force_insert)
{
    bool success = false;
    int iter = 0;
    int oldstacksize = a->top+1;

    int max_inner_iterations_topological = max_local_iterations;
    int max_inner_iterations_contraction = 1;
    int max_inner_iterations_insertion = 1;
    int max_inner_iterations_smoothing = 1;
    int max_inner_iterations_forced_insertion = 1;
      
    *minqual = 0.0;
  
    /* try a forced insertion if we feel it's necessary */
    if (force_insert) {
      int subiter = 0;
      do
      {
        success = localpass(FORCEINSERTPASSLOCAL, iter, mesh, a, q, &success, minqual);
        subiter++;
        
        if (improvebehave->verbosity > 1)
        {
          printf("After FORCED INSERTION, stack minimum quality is %g (goal %g)\n", *minqual, q);
        }
        
        if (*minqual >= q) return;
      }
      while (success && subiter < max_inner_iterations_forced_insertion);
    }
      
    while (*minqual < q && iter < max_local_iterations)
    {
        /* start with topological improvement as long as it helps */
				int subiter = 0;
				do
				{
						success = localpass(TOPOPASSLOCAL, iter, mesh, a, q, &success, minqual);
						subiter++;
						
						if (improvebehave->verbosity > 1)
						{
								printf("After TOPOLOGICAL improvement, stack minimum quality is %g (goal %g)\n", *minqual, q);
						}

						/* stop at the topo pass if that's enough */
						if (*minqual >= q) return;
				}
				while (success && subiter < max_inner_iterations_topological);
			
				/* now try a contraction */
				subiter = 0;
				if (improvebehave->edgecontraction)
				{
						do
						{
								success = localpass(CONTRACTPASSLOCAL, iter, mesh, a, q, &success, minqual);
								subiter++;
								
								if (improvebehave->verbosity > 1)
								{
										printf("After CONTRACTION, stack minimum quality is %g (goal %g)\n", *minqual, q);
								}
								
								if (*minqual >= q) return;
						}
						while (success && subiter < max_inner_iterations_contraction);
				}
			
				/* now try an insertion */
				subiter = 0;
				do
				{
						success = localpass(INSERTPASSLOCAL, iter, mesh, a, q, &success, minqual);
						subiter++;
						
						if (improvebehave->verbosity > 1)
						{
								printf("After INSERTION, stack minimum quality is %g (goal %g)\n", *minqual, q);
						}

						if (*minqual >= q) return;
				}
				while (success && subiter < max_inner_iterations_insertion);
			
        /* try smoothing */
				subiter = 0;
				do
				{
						success = localpass(SMOOTHPASSLOCAL, iter, mesh, a, q, &success, minqual);
						subiter++;

						if (improvebehave->verbosity > 1)
						{
								printf("After SMOOTHING, stack minimum quality is %g (goal %g)\n", *minqual, q);
						}
						
						if (*minqual >= q) return;
				}
				while (success && subiter < max_inner_iterations_smoothing);
			
        /* if the stack is still the same size as it was last iteration,
           enlarge it! */
        if (a->top+1 == oldstacksize)
        {
            if (improvebehave->verbosity > 1)
            {
                printf("Enlarging stack by adding all neighors\n");
                stackaddneighbors(mesh, a);
            }
        }
        else
        {
            if (improvebehave->verbosity > 1)
            {
                printf("NOT Enlarging stack, before it was %d, now its %lu\n", oldstacksize, a->top+1);
            }
        }
        
        oldstacksize = a->top+1;
        
        iter++;
    }
}

/* attempt to improve a single tetrahedron's quality to at least q
   while affecting as few nearby tetrahedra as possible */
void improvetet(struct tetcomplex *mesh, 
                tag t[4], 
                starreal q,
                starreal *minqual,
                struct arraypoolstack *affectedstack,   
                bool force_insert)
{
    starreal quality = 0.0;
    struct improvetet *stacktet;
    
    /* the stack of all tets affected during the effort to improve t */
    struct arraypoolstack a;
    
    char msg[80];
#ifdef WIN32
	sprintf_s(msg, 80, "Start improving tet %d", (int) t[0]);
#else
    sprintf(msg, "Start improving tet %d", (int) t[0]);
#endif
    journalmarker(msg);
  
    /* initialize list of affected tets */
    stackinit(&a, sizeof(struct improvetet));
    
    /* start with just a <= t */
    quality = tetquality(mesh, t[0], t[1], t[2], t[3]);
    
    /* if quality is already fine, return */
    if (quality >= q)
    {
        if (improvebehave->verbosity > 1)
        {
            printf("Not improving this tet because it is already fine.\n");
        }
        
        *minqual = quality;
        appendstack(&a, affectedstack);
        stackdeinit(&a);
        return;
    }

    /* check to make sure this tet doesn't have four boundary verts */
	/*
™    numbverts = boundverts(mesh, t[0], t[1], t[2], t[3], btags);
    if (numbverts == 4)
    {
        textcolor(BRIGHT, RED, BLACK);
        printf("EEK, being asked to improve tet with 4 boundary verts, quality is %g\n", quality);
        printf("  vertices are: %d %d %d %d\n", (int)t[0], (int)t[1], (int)t[2], (int)t[3]);
        textcolor(RESET, WHITE, BLACK);
    }
	*/
	
    stacktet = (struct improvetet *) stackpush(&a);
    stacktet->quality = quality;
    stacktet->verts[0] = t[0];
    stacktet->verts[1] = t[1];
    stacktet->verts[2] = t[2];
    stacktet->verts[3] = t[3];
    
    if (improvebehave->verbosity > 1)
    {
        printf("Starting improvetet, stack size is %lu, minqual is %g (goal %g)\n", a.top+1, quality, q);
    }
    
    /* perform contained improvement on tets in a;
       a may grow */
    localimprove(mesh, &a, minqual, q, MAXLOCALIMPROVEITERS, force_insert);
    /* 
    don't use this!
    localimprovestaticish(mesh, &a, minqual, q);
    */
    
    if (improvebehave->verbosity > 1)
    {
        printf("Finished running improvetet on tet (%d %d %d %d). Final quality was %g (goal %g)\n", (int) t[0], (int) t[1], (int) t[2], (int) t[3], *minqual, q);
    }
    
    /* append the tets affected in this improvement pass to the affected stack */
    /* (only adds tets not already on the stack) */
    appendstack(&a, affectedstack);
    if (improvebehave->verbosity > 1)
    {
        printf("The overall affected stack now has %lu tets\n", affectedstack->top + 1);
    }
  
    journalmarker("Done improving tet.");
    
    /* free list of affected tets */
    stackdeinit(&a);
}

starreal getmeshvolume(struct tetcomplex *mesh) {
  struct tetcomplexposition pos; /* position of iterator in the mesh */
  tag tet[4];                    /* the current tet */
  starreal meshvolume = 0.0;
  
  /* initialize the iterator over the mesh */
  tetcomplexiteratorinit(mesh, &pos);
  /* retrieve the first tet in the mesh */
  tetcomplexiteratenoghosts(&pos, tet);
  
  /* for each tet */
  while (tet[0] != STOP) 
  {
    /* compute the volume of this tet */
    meshvolume += tetvolume(mesh, tet[0], tet[1], tet[2], tet[3]);
    
    /* fetch the next tet from the mesh */
    tetcomplexiteratenoghosts(&pos, tet);
  }
  
  return meshvolume;
}

float getchangedvol(struct tetcomplex *mesh, struct arraypoolstack *astack)
{
    /* first, compute the volume of the entire mesh */
    struct tetcomplexposition pos; /* position of iterator in the mesh */
    tag tet[4];                    /* the current tet */
    starreal meshvolume = 0.0;
    starreal stackvolume = 0.0;
    struct improvetet *stacktet;   /* point to stack tet */
    int i;
    int nonexist = 0;
    
    /* initialize the iterator over the mesh */
    tetcomplexiteratorinit(mesh, &pos);
    /* retrieve the first tet in the mesh */
    tetcomplexiteratenoghosts(&pos, tet);
    
    /* for each tet */
    while (tet[0] != STOP) 
    {
        /* compute the volume of this tet */
        meshvolume += tetvolume(mesh, tet[0], tet[1], tet[2], tet[3]);
        
        /* fetch the next tet from the mesh */
        tetcomplexiteratenoghosts(&pos, tet);
    }
    
    if (improvebehave->verbosity > 0)
    {
        printf("Volume of whole mesh is %g\n", meshvolume);
    }
    
    /* now, compute the volume of all the affected tets */
    for (i=0; i<=astack->top; i++)
    {
        /* fetch this item from the stack */
        stacktet = (struct improvetet *) arraypoolfastlookup(&(astack->pool), (unsigned long) i);

        /* check that it exists */
        if (tetexists(mesh, stacktet->verts[0], stacktet->verts[1], stacktet->verts[2], stacktet->verts[3]) == 0)
        {
            nonexist++;
            continue;
        }
        
        /* it exists, compute it's volume */
        stackvolume += tetvolume(mesh, stacktet->verts[0], stacktet->verts[1], stacktet->verts[2], stacktet->verts[3]);
    }
    
    if (improvebehave->verbosity > 0)
    {
        printf("non-existent tets: %d / %lu\n", nonexist, astack->top+1);
    }
    
    if (improvebehave->verbosity > 0)
    {
        printf("Volume of affected stack is %g\n", stackvolume);
        printf("Proportion of mesh affected is %g\n", stackvolume / meshvolume);
    }
    
    assert(stackvolume <= meshvolume || stackvolume - meshvolume < VOLUME_EPSILON);
    
    return (((stackvolume > meshvolume) && (stackvolume - meshvolume < VOLUME_EPSILON)) ? 1 : stackvolume / meshvolume);
}

/* repair any parts of a changing mesh that have fallen
   below an acceptable quality. return the proportion of
   total mesh volume affected during improvement. */
bool dynamicimprove(struct tetcomplex *mesh, int numignoretets, int ignoretets[][4])
{
  int iter = 0;
  bool force_insert = false;
  bool done = false;
  
  int last_stack_size = -1;
  
  /* turn on color printouts */
  improvebehave->usecolor = true;
  
  /* force on dynamic flag */
  improvebehave->dynamic = true;
  
  while (!done && iter < MAXLOCALIMPROVEITERS)
  {
    bool user_abort = false;
    starreal minqual, minqualout;
    starreal meanquals[NUMMEANTHRESHOLDS];
    starreal triggerqual = improvebehave->goalquality;
    starreal goalqual = improvebehave->goalquality;
    
    int starttop;
    
    /* stack of tets worse than quality threshold */
    struct arraypoolstack badstack;
    struct arraypoolstack affectedstack;
    struct improvetet *stacktet;
   
    done = true;
    iter++;

    /* initialize list of bad tets */
    stackinit(&badstack, sizeof(struct improvetet));
    /* initialize list of affected tets */
    stackinit(&affectedstack, sizeof(struct improvetet));
    
    /* build the list of bad tets */
    fillstackqual(mesh, &badstack, triggerqual, meanquals, &minqual);

    printf("Dynamic improvement, iteration %d with %ld bad tets.\n", iter, badstack.top+1);
    
    journalmarker("Start dynamic improve iteration");
    
    /* if we failed to make any progress in the last pass, give up */
    if (last_stack_size == badstack.top+1) {
      printf("Failed to improve any tet last round, still %d tets, giving up.\n", last_stack_size);
      
      stackdeinit(&badstack);
      stackdeinit(&affectedstack);
      return false;
    } else {
      last_stack_size = badstack.top+1;
    }
    
    if (improvebehave->verbosity > 1 && badstack.top != -1)
    {
        textcolor(BRIGHT, RED, BLACK);
        printf("Number of tetrahedra beneath trigger quality is %lu\n", badstack.top+1);
        textcolor(RESET, WHITE, BLACK);
    }
    
    starttop = badstack.top+1;
    
    /* go through each tet on the stack */
    while (badstack.top != STACKEMPTY)
    {
        bool should_ignore = false;
        int i;
      
        /* pull the top tet off the stack */
        stacktet = (struct improvetet *) stackpop(&badstack);
        
        /* check to make sure it still exists */
        if (tetexists(mesh, stacktet->verts[0], 
                            stacktet->verts[1], 
                            stacktet->verts[2], 
                            stacktet->verts[3]) == false)
        {
            continue;
        }
        
        /* if this tet is in the list of tets to ignore, ignore it */
        for (i = 0; i < numignoretets; ++i) {
          if (sametet(stacktet->verts[0], stacktet->verts[1], stacktet->verts[2], stacktet->verts[3],
                      ignoretets[i][0], ignoretets[i][1], ignoretets[i][2], ignoretets[i][3]))
          {
            should_ignore = true;
            printf("Ignoring tet %lu %lu %lu %lu as requested.", (long unsigned int)stacktet->verts[0], (long unsigned int)stacktet->verts[1], (long unsigned int)stacktet->verts[2], (long unsigned int)stacktet->verts[3]);
            break;
          }
        }
        if (should_ignore)
          continue;
      
        if (improvebehave->verbosity > 1)
        {
            textcolor(BRIGHT, YELLOW, BLACK);
            printf("In dynamicimprove, about to improve tet %lu / %d (%d %d %d %d)\n", starttop-badstack.top-1, starttop, (int) stacktet->verts[0], (int) stacktet->verts[1], (int) stacktet->verts[2], (int) stacktet->verts[3]);
            textcolor(RESET, WHITE, BLACK);
        }
        
        /* improve this tet */
        improvetet(mesh, stacktet->verts, goalqual, &minqualout, &affectedstack, force_insert);
        
        if (improvebehave->verbosity > 1)
        {
            printf("In dynamic improve, tet improvement resulted in quality of %g (%g) goal\n", minqualout, goalqual);
        }
        
        if (minqualout < goalqual)
        {
          done = false;
          textcolor(BRIGHT, RED, BLACK);  
          printf("Failed to improve a poor quality tet enough (quality %g).\n", minqualout);          
          textcolor(RESET, WHITE, BLACK);

          /*
          failed_attempts++;
          
          if (!force_insert) {
            printf("Turning forced insertion on.\n");
            force_insert = true;
          } else {
            printf("We already tried forced insertion, giving up\n");
            
            // free the stacks
            stackdeinit(&badstack);
            stackdeinit(&affectedstack);
            
            return false;
          }
          */
        }
      
        if (improvebehave->progress_cb && !improvebehave->progress_cb(improvebehave)) {
          printf("User requested abort.\n");
          user_abort = true;
          break;
        }
    }

    if (user_abort) 
      break;
    
    journalmarker("Done dynamic improve iteration");
    
    /* free the stacks */
    stackdeinit(&badstack);
    stackdeinit(&affectedstack);
  }
    
  return true;
}


starreal meshingtime;
/* improve a mesh, changing it as little as possible to meet a minimum quality
   threshold. Meant to be called when Pulsar is used as a library. Inputs are
   an array of vertex positions (starreal) and an array of tets. Outputs are
   same format. TODO pass in and out with native data structures? */
bool dodynimprove(struct behavior *behave,
                  struct inputs *in,
                  struct proxipool *vertexpool,
                  struct tetcomplex *mesh,
                  int numignoretets,
                  int ignoretets[][4],
                  starreal *volumechange)
{
#ifndef NO_TIMER
    /* timing vars */
    struct timeval tv0, tv2;
#endif /* not NO_TIMER */
    
    int passstartid = 0;
    bool success = false;
    starreal minqualbefore, meanqualbefore[NUMMEANTHRESHOLDS];
    struct arraypoolstack tetstack; /* stack of tets to be improved */
    starreal bestmeans[NUMMEANTHRESHOLDS];
  
    starreal volumebefore, volumeafter;
    
#ifndef NO_TIMER
    /* get initial time */
    gettimeofday(&tv0, NULL);
    improvestats.starttime = tv0;
#endif /* not NO_TIMER */
    
    /* perform improvement initialization */
    improveinit(mesh, vertexpool, &tetstack, behave, in, bestmeans);
    
    /* output initial mesh state */
    /* outputqualmesh(behave, in, vertexpool, mesh, 0, NULL, 0, SMOOTHPASS, 0); */
    
    /***************** SIZE CONTROL *************************/
    if (improvebehave->dynsizing)
    {
            int passnum;
            journalmarker("Start dynamic sizing pass");
            passnum = dynsizecontrol(mesh, behave, in, vertexpool);
    }
    else if (improvebehave->sizing)
    {
            int passnum;
            journalmarker("Start sizing pass");
            passnum = sizecontrol(mesh, behave, in, vertexpool, true);
    } 

    timerstart();
  
    /******************** IMPROVE MESH ************************************/
    /* record state of mesh before deformation */
    passstartid = lastjournalentry();
  
    volumebefore = getmeshvolume(mesh);
    
    success = dynamicimprove(mesh, numignoretets, ignoretets);
    
    meshquality(mesh, meanqualbefore, &minqualbefore);
    if (improvebehave->verbosity > 1)
    {
        printf("The overall mesh worst quality after improvement is %g (require %g)\n", minqualbefore, improvebehave->goalquality);
    }
    
    volumeafter = getmeshvolume(mesh);  
  
    *volumechange = volumeafter - volumebefore;
  
    /* output deformed mesh */
    /*
    outputqualmesh(behave,
                  in, 
                  vertexpool, 
                  mesh, 
                  0, 
                  NULL, 
                  passnum, 
                  DEFORMPASS, 
                  passstartid);
    */
  
    /******************** FINAL CLEANUP AND STATS OUTPUT *****************/

#ifndef NO_TIMER
    /* record total time */
    gettimeofday(&tv2, NULL);
    improvestats.totalmsec = msecelapsed(tv0, tv2);
#endif /* not NO_TIMER */
  
    /* write journal to log file TODO: Make this optional */
    /*
    printf("writing journal to file.\n");
    int i;
    FILE *logfile = fopen("journal.log", "w");
    for (i = 0; i < journal->top; ++i) {
      struct journalentry *entry = (struct journalentry *) arraypoolfastlookup(&(journal->pool), (unsigned long) i);
      printjournalentrystream(logfile, entry, i);
    }
    fclose(logfile);
    */
  
    /* perform post-improvement cleanup */
    improvedeinit(mesh, vertexpool, &tetstack, behave, in);
  
    meshingtime = timerstop();
  
    return success;
}

