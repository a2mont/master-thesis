#pragma once

#include "structs.h"

/* improve a mesh, changing it as little as possible to meet a minimum quality
 threshold. Meant to be called when Pulsar is used as a library. Inputs are
 an array of vertex positions (starreal) and an array of tets. Outputs are
 same format. TODO pass in and out with native data structures? */
bool dodynimprove(struct behavior *behave,
                  struct inputs *in,
                  struct proxipool *vertexpool,
                  struct tetcomplex *mesh,
                  int numignoretets,
                  int ignoretets[][4],
                  starreal *volumechange);
