#pragma once

#include "structs.h"

bool segmentinsert(struct tetcomplex *mesh,
                   tag v1,
                   tag v2,
                   tag v3,
                   tag v4,
                   int numtets,
                   tag tets[][4],
                   tag boundfaces[],
                   tag *vnew,
                   tag newfaces[][3],
                   int *numnewfaces,
                   tag newtets[][4],
                   int *numnewtets,
                   bool boundedge);


/* given a vertex, it's position, and an initial cavity of tets
 and a set of outward-oriented faces of that cavity, dig out an
 optimal cavity around the vertex and connect the central vertex
 to all of the cavity faces, and return a list of the new tets */
void optimalcavity(struct tetcomplex *mesh,
                   tag vtag,
                   tag initialC[][4],
                   int initialCsize,
                   tag initialF[][3],
                   int initialFsize,
                   tag outtets[][4],
                   int *numouttets,
                   starreal *worstdeleted,
                   starreal *worstincavity,
                   bool allowvertexdeletion);


/* given a cavity of tets built around a single vertex,
 try to improve the cavity, and return the final quality */
starreal improvecavity(struct tetcomplex *mesh,
                       tag v,
                       tag tets[][4],
                       int numtets,
                       bool tryhard,
                       struct arraypoolstack *outstack,
                       starreal *shortest, starreal *longest);

/* go after the worst tets. with insertion */
void worsttetattack(struct tetcomplex *mesh,
                    starreal percentinsert,
                    starreal outmeanqual[],
                    starreal *outminqual,
                    bool desperate,
                    bool force);

/* attempt insertion on a stack of tets */
bool insertpass(struct tetcomplex *mesh,
                struct arraypoolstack *tetstack,
                struct arraypoolstack *outstack,
                starreal meanqualafter[],
                starreal *minqualafter,
                starreal okayqual,
                bool quiet,
                bool force);

