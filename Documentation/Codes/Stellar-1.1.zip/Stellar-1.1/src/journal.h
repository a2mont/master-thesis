#pragma once

void printjournalentrystream(FILE* o, struct journalentry *entry, int index);

int lastjournalentry(void);

void journaltopological(struct tetcomplex *mesh, int type, tag verts[], int numverts);
void journalinsert(struct tetcomplex *mesh,
                   tag vert,
                   starreal pos[3],
                   starreal attributes[]);
void journalsmooth(struct tetcomplex *mesh,
                   tag vert,
                   starreal old_vector[3],
                   starreal new_vector[3],
                   starreal old_attributes[],
                   starreal new_attributes[]);
void journalclassify(struct tetcomplex *mesh,
                     tag vert,
                     int old_classification,
                     starreal old_vector[3],
                     int classification,
                     starreal new_vector[3]);
void journalquadric(struct tetcomplex *mesh, 
                    tag vert,
                    struct quadric *oldquadric,
                    struct quadric *newquadric);
void journalmarker(char *context);

void invertjournalupto(struct tetcomplex* mesh, int id);

void journalrangetoindex(int startid, 
                         int endid,
                         int *startindex,
                         int *endindex,
                         int *numops);

void printjournalrangestream(FILE *o, int startindex, int endindex);

void printjournaltop(int numentries);

void findtetfromvertex(struct tetcomplex *mesh,
                       tag vtx,
                       tag outtet[4]);

