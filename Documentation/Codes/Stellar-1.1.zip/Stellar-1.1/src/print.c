/*****************************************************************************/
/*                                                                           */
/*  printing utility functions                                               */
/*                                                                           */
/*****************************************************************************/

#include "print.h"
#include "util.h"
#include "size.h"
#include "timer.h"

/* print the coordinates of the for vertices of a tet for viz purposes
   (prints them in the format of a MATLAB matrix, my ghetto viz tool) */
void printtetverts(struct tetcomplex *mesh, tag *tet)
{
    starreal *point[4];
    int i;
    
    /* get tet vertices */
    point[0] = ((struct vertex *) tetcomplextag2vertex(mesh, tet[0]))->coord;
    point[1] = ((struct vertex *) tetcomplextag2vertex(mesh, tet[1]))->coord;
    point[2] = ((struct vertex *) tetcomplextag2vertex(mesh, tet[2]))->coord;
    point[3] = ((struct vertex *) tetcomplextag2vertex(mesh, tet[3]))->coord;
    
    printf("[");
    for (i=0; i<4; i++)
    {
        printf("%f %f %f", point[i][0], point[i][1], point[i][2]);
        if (i != 3)
        {
            printf(";\n");
        }
    }
    printf("]");
}

/* print the geometric locations of face vertices */
void printfaceverts(struct tetcomplex *mesh, tag *face)
{
    starreal *point[4];
    int i;
    
    /* get tet vertices */
    point[0] = ((struct vertex *) tetcomplextag2vertex(mesh, face[0]))->coord;
    point[1] = ((struct vertex *) tetcomplextag2vertex(mesh, face[1]))->coord;
    point[2] = ((struct vertex *) tetcomplextag2vertex(mesh, face[2]))->coord;
    
    printf("[");
    for (i=0; i<3; i++)
    {
        printf("%f %f %f", point[i][0], point[i][1], point[i][2]);
        if (i != 3)
        {
            printf(";\n");
        }
    }
    printf("]");
}

/* another function that prints a tet with separate vertex args */
void printtetvertssep(struct tetcomplex *mesh,
                      tag vtx1,
                      tag vtx2,
                      tag vtx3,
                      tag vtx4)
{
    tag tet[4];
    tet[0] = vtx1;
    tet[1] = vtx2;
    tet[2] = vtx3;
    tet[3] = vtx4;
    
    printtetverts(mesh, tet);
}

/* print out an array of tets */
void printtets(struct tetcomplex *mesh,
               tag tets[][4],
               int numtets)
{
    int i; /* loop counter */
    
    printf("{");
    for (i=0; i<numtets; i++)
    {
        printtetverts(mesh, tets[i]);
        if (i != numtets-1)
        {
            printf(",\n");
        }
    }
    printf("};\n");
}

/* print out an array of tets */
void printopttets(struct tetcomplex *mesh,
                  struct opttet tets[],
                  int numtets)
{
    int i; /* loop counter */
    
    printf("{");
    for (i=0; i<numtets; i++)
    {
        printtetverts(mesh, tets[i].verts);
        if (i != numtets-1)
        {
            printf(",\n");
        }
    }
    printf("};\n");
}

/* print out an array of faces */
void printfaces(struct tetcomplex *mesh,
                tag faces[][3],
                int numfaces)
{
    int i; /* loop counter */
    
    printf("{");
    for (i=0; i<numfaces; i++)
    {
        printfaceverts(mesh, faces[i]);
        if (i != numfaces-1)
        {
            printf(",\n");
        }
    }
    printf("};\n");
}

/* print out an array of tets as tags*/
void printtetstags(tag tets[][4],
                   int numtets)
{
    int i; /* loop counter */
    
    printf("[");
    for (i=0; i<numtets; i++)
    {
        printf("%d %d %d %d;\n", (int) tets[i][0], (int) tets[i][1], (int) tets[i][2], (int) tets[i][3]);
    }
    printf("]\n");
}

/* print Q and K tables from Klincsek's algorithm for debugging
   purposes */
void printtables(starreal Q[][MAXRINGTETS],
                 int K[][MAXRINGTETS],
                 int ringcount)
{
    int i,j; /* loop counters */
    
    printf("*** Table Q ***\n");
    for (i=1; i<=ringcount; i++)
    {
        printf("[");
        for (j=1; j<=ringcount; j++)
        {
            printf("% f ", Q[i][j]);
        }
        printf("]\n");
    }
    
    printf("*** Table K ***\n");
    for (i=1; i<=ringcount; i++)
    {
        printf("[");
        for (j=1; j<=ringcount; j++)
        {
            printf("%2ul ", K[i][j]);
        }
        printf("]\n");
    }
}

/* print edge and ring around it for ghetto visualization in matlab */
void printring(struct tetcomplex *mesh, tag a, tag b, tag *ring, int ringcount)
{
    int i;
    tag tet[4];
    
    /* output every tet in the ring */
    printf("{\n");
    for (i=0; i<ringcount; i++)
    {
        tet[0] = ring[i];
        if (i == ringcount -1)
        {
            tet[1] = ring[0];
        }
        else
        {
            tet[1] = ring[i+1];
        }
        tet[2] = b;
        tet[3] = a;
        printtetverts(mesh, tet);
        if (i != ringcount -1)
        {
            printf(",\n");
        }
    }
    printf("}\n"); 
}

/* print edge and ring around it for ghetto visualization in matlab */
void printhalfring(struct tetcomplex *mesh, tag a, tag b, tag *ring, int ringcount)
{
    int i;
    tag tet[4];
    
    /* output every tet in the ring */
    printf("{");
    for (i=0; i<ringcount-1; i++)
    {
        tet[0] = ring[i];
        tet[1] = ring[i+1];
        tet[2] = b;
        tet[3] = a;
        /*
        printf("verts (%d %d %d %d)\n", tet[0], tet[1], tet[2], tet[3]);
        */
        printtetverts(mesh, tet);
        if (i != ringcount -2)
        {
            printf(",\n");
        }
    }
    printf("};\n"); 
}

/* print out the info in a opttet */
void printopttet(struct opttet *tet)
{
    int i;
    
    printf("For tet with verts (%d, %d, %d, %d):\n", (int) tet->verts[0], (int) tet->verts[1], (int) tet->verts[2], (int) tet->verts[3]);
    printf("    volume = %f\n", tet->volume);
    printf("    volume gradient = (%f, %f, %f)\n", tet->volumegrad[0], tet->volumegrad[1], tet->volumegrad[2]);
    printf("    qualities:\n");
    for (i=0; i < tet->numqualities; i++)
    {
			printf("  %d: %f, [%f %f %f]\n",i, tet->quality[i], tet->qualitygrad[i][0], tet->qualitygrad[i][1], tet->qualitygrad[i][2]);
    }
}

/* print out B, S, M arrays from findbasis */
void printbasisarrays(starreal S[][3],
                      starreal M[][3],
                      starreal B[][3],
                      int sizeS,
                      int sizeM,
                      int *sizeB,
                      starreal p[])
{
    int i;
    
    printf("\nCurrent basis finding arrays:\n");
    printf("    p: %f %f %f\n",p[0],p[1],p[2]);
    printf("    S: [ ");
    for (i=0; i<sizeS; i++)
    {
        printf("(%f %f %f) ", S[i][0],S[i][1],S[i][2]);
    }
    printf("]\n");
    
    printf("    M: [ ");
    for (i=0; i<sizeM; i++)
    {
        printf("(%f %f %f) ", M[i][0],M[i][1],M[i][2]);
    }
    printf("]\n");
    
    printf("    B: [ ");
    for (i=0; i<*sizeB; i++)
    {
        printf("(%f %f %f) ", B[i][0],B[i][1],B[i][2]);
    }
    printf("]\n\n");
}

/* print out global improvement stats */
void printstatsstream(FILE *o, struct tetcomplex *mesh)
{
    int i, maxa, maxs, maxb, maxl;
    
#ifndef NO_TIMER
    struct timeval now;
#endif /* not NO_TIMER */

    fprintf(o, "Mesh Improvement Statistics:\n\n");
    
    /* smoothing */
    fprintf(o, "Smoothing statistics:\n");
    fprintf(o, "    Optimization smooths:    %d / %d\n", improvestats.nonsmoothsuccesses, improvestats.nonsmoothattempts);
    fprintf(o, "    Free vertex smooths:     %d / %d\n", improvestats.freesmoothsuccesses, improvestats.freesmoothattempts);
    fprintf(o, "    Facet vertex smooths:    %d / %d\n", improvestats.facetsmoothsuccesses, improvestats.facetsmoothattempts);
    fprintf(o, "    Segment vertex smooths:  %d / %d\n", improvestats.segmentsmoothsuccesses, improvestats.segmentsmoothattempts);
    fprintf(o, "    Corner vertex smooths:    %d / %d\n", improvestats.cornersmoothsuccesses, improvestats.cornersmoothattempts);
    
    /* topological */
    fprintf(o, "\nTopological improvement statistics:\n");
    fprintf(o, "    Edge contractions:       %d / %d\n", improvestats.edgecontractions, improvestats.edgecontractionattempts);
    fprintf(o, "    Edge contraction cases:\n");
    fprintf(o, "        free-free            %d / %d\n", improvestats.edgecontractcasesuc[FREEFREEEDGE], improvestats.edgecontractcaseatt[FREEFREEEDGE]);
    fprintf(o, "        free-facet           %d / %d\n", improvestats.edgecontractcasesuc[FREEFACETEDGE], improvestats.edgecontractcaseatt[FREEFACETEDGE]);
    fprintf(o, "        free-segment         %d / %d\n", improvestats.edgecontractcasesuc[FREESEGMENTEDGE], improvestats.edgecontractcaseatt[FREESEGMENTEDGE]);
    fprintf(o, "        free-corner           %d / %d\n", improvestats.edgecontractcasesuc[FREECORNEREDGE], improvestats.edgecontractcaseatt[FREECORNEREDGE]);
    fprintf(o, "        facet-facet          %d / %d\n", improvestats.edgecontractcasesuc[FACETFACETEDGE], improvestats.edgecontractcaseatt[FACETFACETEDGE]);
    fprintf(o, "        facet-segment        %d / %d\n", improvestats.edgecontractcasesuc[FACETSEGMENTEDGE], improvestats.edgecontractcaseatt[FACETSEGMENTEDGE]);
    fprintf(o, "        facet-corner          %d / %d\n", improvestats.edgecontractcasesuc[FACETCORNEREDGE], improvestats.edgecontractcaseatt[FACETCORNEREDGE]);
    fprintf(o, "        segment-segment      %d / %d\n", improvestats.edgecontractcasesuc[SEGMENTSEGMENTEDGE], improvestats.edgecontractcaseatt[SEGMENTSEGMENTEDGE]);
    fprintf(o, "        segment-corner        %d / %d\n", improvestats.edgecontractcasesuc[SEGMENTCORNEREDGE], improvestats.edgecontractcaseatt[SEGMENTCORNEREDGE]);
    fprintf(o, "        corner-corner          %d / %d\n", improvestats.edgecontractcasesuc[CORNERCORNEREDGE], improvestats.edgecontractcaseatt[CORNERCORNEREDGE]);
    fprintf(o, "    Edge removals:           %d / %d\n", improvestats.edgeremovals, improvestats.edgeremovalattempts);
    fprintf(o, "    Boundary edge removals:  %d / %d\n", improvestats.boundaryedgeremovals, improvestats.boundaryedgeremovalattempts);
    
    /* find array bounds */
    maxa = maxs = 0;
    for (i=0; i<MAXRINGTETS; i++)
    {
        if (improvestats.ringsizeattempts[i] != 0) maxa = i;
        if (improvestats.ringsizesuccess[i] != 0) maxs = i;
    }
    
    /* print histograms */
    fprintf(o, "    Attempt ring sizes (max %d):\n", maxa);
    for (i=3; i<=maxa; i++)
    {
        fprintf(o, "    [%d]: %d\n", i, improvestats.ringsizeattempts[i]);
    }
    fprintf(o, "    Success ring sizes (max %d):\n", maxs);
    for (i=3; i<=maxs; i++) 
    {
        fprintf(o, "    [%d]: %d\n", i, improvestats.ringsizesuccess[i]);
    }
    
    fprintf(o, "    Face removals:           %d / %d\n", improvestats.faceremovals, improvestats.faceremovalattempts);
    
    /* find array bounds */
    maxa = maxs = 0;
    for (i=0; i<MAXFACETREESIZE; i++)
    {
        if (improvestats.facesizeattempts[i] != 0) maxa = i;
        if (improvestats.facesizesuccess[i] != 0) maxs = i;
    }
    
    /* print histograms */
    fprintf(o, "    Attempt tree sizes (max %d):\n", maxa);
    for (i=1; i<=maxa; i++)
    {
        fprintf(o, "    [%d]: %d\n", i, improvestats.facesizeattempts[i]);
    }
    fprintf(o, "    Success tree sizes (max %d):\n", maxs);
    for (i=1; i<=maxs; i++)
    {
        fprintf(o, "    [%d]: %d\n", i, improvestats.facesizesuccess[i]);
    }
    fprintf(o, "     2-2 flips:              %d / %d\n", improvestats.flip22successes, improvestats.flip22attempts);
    
    /* insertion stats */
    fprintf(o, "\nVertex insertion stats:\n");
    fprintf(o, "    Body insertions:         %d / %d\n", improvestats.bodyinsertsuccesses, improvestats.bodyinsertattempts);
    fprintf(o, "    Facet insertions:        %d / %d\n", improvestats.facetinsertsuccesses, improvestats.facetinsertattempts);
    fprintf(o, "    Segment insertions:      %d / %d\n", improvestats.segmentinsertsuccesses, improvestats.segmentinsertattempts);
    
    /* find array bounds */
    maxb = maxl = 0;
    for (i=0; i<MAXCAVDEPTH; i++)
    {
        if (improvestats.biggestcavdepths[i] != 0) maxb = i;
        if (improvestats.lexmaxcavdepths[i] != 0) maxl = i;
    }
    fprintf(o, "    Biggest cavity depths (max %d):\n", maxb);
    for (i=0; i<=maxb; i++)
    {
        fprintf(o, "    [%d]: %d\n", i, improvestats.biggestcavdepths[i]);
    }
    fprintf(o, "    Lexmax cavity depths (max %d):\n", maxl);
    for (i=0; i<=maxl; i++)
    {
        fprintf(o, "    [%d]: %d\n", i, improvestats.lexmaxcavdepths[i]);
    }
    
    /* get the current time for animation stuff */
#ifndef NO_TIMER
    gettimeofday(&now, NULL);
    improvestats.totalmsec = msecelapsed(improvestats.starttime, now);
#endif /* not NO_TIMER */
    improvestats.finishnumtets = counttets(mesh);
    
    /* timing stats */
    fprintf(o, "\nTiming stats:\n");
    fprintf(o, "    Smoothing msec: %d\n", improvestats.smoothmsec);
    fprintf(o, "    Topological msec: %d\n", improvestats.topomsec);
    fprintf(o, "    Insertion msec: %d\n", improvestats.insertmsec);
    fprintf(o, "    Contraction msec: %d\n", improvestats.contractmsec);
    fprintf(o, "    Total msec:     %d\n", improvestats.totalmsec);
    fprintf(o, "    maxcavusec:     %d\n", improvestats.biggestcavityusec);
    fprintf(o, "    fincavusec:     %d\n", improvestats.finalcavityusec);
    fprintf(o, "    improvecavusec: %d\n", improvestats.cavityimproveusec);
    
    fprintf(o, "Star/End vertex count:       %d / %d\n", improvestats.startnumverts, improvestats.startnumverts + improvestats.bodyinsertsuccesses + improvestats.facetinsertsuccesses + improvestats.segmentinsertsuccesses);
    fprintf(o, "Start/End tet count:         %d / %d\n\n", improvestats.startnumtets, improvestats.finishnumtets );
    
    /* quality stats */
    fprintf(o, "Quality stats:\n");
    fprintf(o, "    Mean qualities:\n");
    for (i=0; i<NUMMEANTHRESHOLDS; i++)
    {
        fprintf(o, "    [%g]: %g (%g degrees)\n", improvebehave->meanthresholds[i], improvestats.finishmeanquals[i], sintodeg(improvestats.finishmeanquals[i]));
    }
    
    /* quality stats */
    fprintf(o, "\n    StartMean qualities:\n");
    for (i=0; i<NUMMEANTHRESHOLDS; i++)
    {
        fprintf(o, "    [%g]: %g (%g degrees)\n", improvebehave->meanthresholds[i], improvestats.startmeanquals[i], sintodeg(improvestats.startmeanquals[i]));
    }
    fprintf(o, "\n    Startworstqual: %g\n", improvestats.startworstqual);
    fprintf(o, "    Startminangle: %g\n", improvestats.startminangle);
    fprintf(o, "    Startmaxangle: %g\n", improvestats.startmaxangle);
    
    fprintf(o, "    dynchangedvol: %g\n", improvestats.dynchangedvol);
    
    /* cavity sizes */
/*    fprintf(o, "\n    Maxcavity sizes:\n");
    for (i=0; i<1000; i++)
    {
        fprintf(o, "[%d]: %d ", i, improvestats.maxcavitysizes[i]);
    }
    fprintf(o, "\n    Finalcavity sizes:\n");
    for (i=0; i<200; i++)
    {
        fprintf(o, "[%d]: %d ", i, improvestats.finalcavitysizes[i]);
    }*/
    
    sizereportstream(o, mesh);
}

void printstats(struct tetcomplex *mesh)
{
    printstatsstream(stdout, mesh);
}

void printmeans(starreal means[])
{
    int i;
    for (i=0; i<NUMMEANTHRESHOLDS; i++)
    {
        printf("    [%g]: %g (%g degrees)\n", improvebehave->meanthresholds[i], means[i], sintodeg(means[i]));
    }
}
