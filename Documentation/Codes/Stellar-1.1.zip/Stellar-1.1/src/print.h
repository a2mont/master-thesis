#pragma once

#include "structs.h"

/* print the coordinates of the for vertices of a tet for viz purposes
 (prints them in the format of a MATLAB matrix, my ghetto viz tool) */
void printtetverts(struct tetcomplex *mesh, tag *tet);


/* print the geometric locations of face vertices */
void printfaceverts(struct tetcomplex *mesh, tag *face);



/* another function that prints a tet with separate vertex args */
void printtetvertssep(struct tetcomplex *mesh,
                      tag vtx1,
                      tag vtx2,
                      tag vtx3,
                      tag vtx4);


/* print out an array of tets */
void printtets(struct tetcomplex *mesh,
               tag tets[][4],
               int numtets);



/* print out an array of tets */
void printopttets(struct tetcomplex *mesh,
                  struct opttet tets[],
                  int numtets);


/* print out an array of faces */
void printfaces(struct tetcomplex *mesh,
                tag faces[][3],
                int numfaces);


/* print out an array of tets as tags*/
void printtetstags(tag tets[][4],
                   int numtets);


/* print Q and K tables from Klincsek's algorithm for debugging
 purposes */
void printtables(starreal Q[][MAXRINGTETS],
                 int K[][MAXRINGTETS],
                 int ringcount);



/* print edge and ring around it for ghetto visualization in matlab */
void printring(struct tetcomplex *mesh, tag a, tag b, tag *ring, int ringcount);


/* print edge and ring around it for ghetto visualization in matlab */
void printhalfring(struct tetcomplex *mesh, tag a, tag b, tag *ring, int ringcount);


/* print out the info in a opttet */
void printopttet(struct opttet *tet);



/* print out B, S, M arrays from findbasis */
void printbasisarrays(starreal S[][3],
                      starreal M[][3],
                      starreal B[][3],
                      int sizeS,
                      int sizeM,
                      int *sizeB,
                      starreal p[]);



/* print out global improvement stats */
void printstatsstream(FILE *o, struct tetcomplex *mesh);


void printstats(struct tetcomplex *mesh);

void printmeans(starreal means[]);
