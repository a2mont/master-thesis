#pragma once

/*****************************************************************************/
/* Shared function declarations                                              */
/*****************************************************************************/

/* topological.c */
bool inserttet(struct tetcomplex *mesh,
               tag vtx1,
               tag vtx2,
               tag vtx3,
               tag vtx4,
               bool record, bool failonerror);
void deletetet(struct tetcomplex *mesh,
               tag vtx1,
               tag vtx2,
               tag vtx3,
               tag vtx4,
               bool record);
void flip23(struct tetcomplex *mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtxbot,
            tag vtxtop,
            bool record);
void flip22(struct tetcomplex *mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtxbot,
            tag vtxtop,
            bool record);
void flip32(struct tetcomplex *mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtxbot,
            tag vtxtop,
            bool record);
void flip13(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag facetvtx,
            bool record);
void flip31(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag facetvtx,
            bool record);
void flip12(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag segmentvtx,
            bool record);
void flip21(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag segmentvtx,
            bool record);
void flip14(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag facetvtx,
            bool record);
void flip41(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag facetvtx,
            bool record);

/* size.c */
void sizereportstream(FILE *o, struct tetcomplex *mesh);

/* print.c */
void printtetverts(struct tetcomplex *mesh, tag *tet);
void printtetvertssep(struct tetcomplex *mesh,
                      tag vtx1,
                      tag vtx2,
                      tag vtx3,
                      tag vtx4);

/* journal.c */
void findtetfromvertex(tetcomplex *mesh,
                       tag vtx,
                       tag outtet[4]);

/* arraypoolstack.c */
void stackinit(struct arraypoolstack *stack, arraypoolulong objectbytes);
void stackrestart(struct arraypoolstack *stack);
void stackdeinit(struct arraypoolstack *stack);
void* stackpush(struct arraypoolstack *stack);
void* stackpop(struct arraypoolstack *stack);
void fillstackqual(struct tetcomplex *mesh,
                   struct arraypoolstack *stack,
                   starreal threshold,
                   starreal *meanqual,
                   starreal *minqual);
