#pragma once

#include "structs.h"

struct quadric *get_quadric(int vtag);

bool hasquadric(tag vtag);

/* compute the quadric error for a query position of a vertex */
starreal quadricerror_raw(struct quadric *q, starreal v[3]);

/* compute the quadric error for a query position of a vertex */
starreal quadricerrorquery(struct tetcomplex *mesh,
                           tag vtag,
                           starreal v[3]);

/* compute the quadric error for a particular vertex's current position */
starreal quadricerror(struct tetcomplex *mesh,
                      tag vtag);

/* compute the quadric error at a position, normalized to
 be comparable to tetrahedron quality measures */
starreal quadricerrortet_raw(struct quadric *quadric,
                             starreal v[3]);


/* compute the quadric error at a vertex, normalized to
 be comparable to tetrahedron quality measures */
starreal quadricerrortet(struct tetcomplex *mesh,
                         tag vtag);


void quadricgrad_raw(struct quadric *q, starreal v[3], starreal grad[3]);

/* compute the gradient of the quadric error for query point */
void quadricgradquery(struct tetcomplex *mesh,
                      tag vtag,
                      starreal v[3],
                      starreal grad[3]);


/* compute the gradient of the quadric error for a vertex */
void quadricgrad(struct tetcomplex *mesh,
                 tag vtag,
                 starreal grad[3]);


/* compute the gradient of the quadric error, scaled for tet comparison */
void quadricgradtet(struct tetcomplex* mesh,
                    tag vtag,
                    starreal grad[3]);


/* add a quadric for a newly inserted vertex */
bool addquadric(struct tetcomplex *mesh,
                tag vtag,
                tag faces[][3],
                int numfaces);


/* compute a quadric for a vertex whose connectivity has changed. 
 It's current position becomes its original position. */
bool recomputequadric(struct tetcomplex *mesh, tag v0, tag v1, tag v2, tag v3);


/* create quadrics for all surface vertices */ 
void collectquadrics(struct tetcomplex *mesh);

/* do a bunch of checks on quadrics */
void checkquadricsstream(FILE *o, struct tetcomplex *mesh);

void checkquadrics(struct tetcomplex *mesh);


