/*****************************************************************************/
/*                                                                           */
/*  tetrahedron quality functions                                            */
/*                                                                           */
/*****************************************************************************/

#include "quality.h"
#include "util.h"
#include "anisotropy.h"
#include "vector.h"
#include "arraypoolstack.h"
#include "print.h"



/* harness function for quality measure callback */
starreal tetquality(struct tetcomplex *mesh, 
                    tag vtx1, 
                    tag vtx2,
                    tag vtx3,
                    tag vtx4)
{
  /* 
    first, convert tags to positions, and evaluate sizing tensor (if requested)
  */

  starreal point[4][3];      /* the vertices of the tet */
  
  /* get transformed vertices */
  tensortransformtet(mesh, vtx1, vtx2, vtx3, vtx4, point);
  
  return improvebehave->quality_cb((const starreal (*)[]) point);
}







/* harness function for quality measure callback (in physical space) */
starreal tetquality_physical(struct tetcomplex *mesh, 
                            tag vtx1, 
                            tag vtx2,
                            tag vtx3,
                            tag vtx4)
{
  /* 
   first, convert tags to positions, and evaluate sizing tensor (if requested)
   */
  
  starreal point[4][3];      /* the vertices of the tet */
  
  /* get tet vertices */
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx1))->coord, point[0]);
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx2))->coord, point[1]);
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx3))->coord, point[2]);
  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, vtx4))->coord, point[3]);
  
  return improvebehave->quality_cb((const starreal (*)[]) point);
}






void getextremeangles(struct behavior *behave,
                      struct tetcomplex *plex,
                      starreal *outsmallestangle,
                      starreal *outbiggestangle)
{
  struct tetcomplexposition position;
  tag tet[4];
  starreal point[4][3];
  starreal tcenter[3];
  starreal tansquaretable[8];
  starreal aspecttable[16];
  starreal circumtable[16];
  starreal edgelength[3][4];
  starreal facenormal[4][3];
  starreal dx, dy, dz;
  starreal dotproduct;
  starreal tansquare;
  starreal pyrvolume;
  starreal facearea2;
  starreal pyrbiggestface2;
  starreal shortest, longest;
  starreal pyrshortest2, pyrlongest2;
  starreal smallestvolume, biggestvolume;
  starreal pyrminaltitude2;
  starreal minaltitude;
  starreal pyraspect2;
  starreal worstaspect;
  starreal pyrcircumratio2;
  starreal worstcircumratio;
  starreal smallestangle, biggestangle;
  starreal radconst, degconst;
  arraypoolulong anglecount[18];
  arraypoolulong aspectcount[16];
  arraypoolulong circumcount[16];
  int aspectindex;
  int circumindex;
  int tendegree;
  int acutebiggestflag;
  int firstiterationflag;
  int i, ii, j, k, l;

  radconst = PI / 18.0;
  degconst = 180.0 / PI;
  for (i = 0; i < 8; i++) {
    tansquaretable[i] = tan(radconst * (starreal) (i + 1));
    tansquaretable[i] = tansquaretable[i] * tansquaretable[i];
  }
  for (i = 0; i < 18; i++) {
    anglecount[i] = 0;
  }

  aspecttable[0]  =      1.5;      aspecttable[1]  =     2.0;
  aspecttable[2]  =      2.5;      aspecttable[3]  =     3.0;
  aspecttable[4]  =      4.0;      aspecttable[5]  =     6.0;
  aspecttable[6]  =     10.0;      aspecttable[7]  =    15.0;
  aspecttable[8]  =     25.0;      aspecttable[9]  =    50.0;
  aspecttable[10] =    100.0;      aspecttable[11] =   300.0;
  aspecttable[12] =   1000.0;      aspecttable[13] = 10000.0;
  aspecttable[14] = 100000.0;      aspecttable[15] =     0.0;
  for (i = 0; i < 16; i++) {
    aspectcount[i] = 0;
  }

  circumtable[0]  =      0.75;     circumtable[1]  =     1.0;
  circumtable[2]  =      1.5;      circumtable[3]  =     2.0;
  circumtable[4]  =      3.0;      circumtable[5]  =     5.0;
  circumtable[6]  =     10.0;      circumtable[7]  =    15.0;
  circumtable[8]  =     25.0;      circumtable[9]  =    50.0;
  circumtable[10] =    100.0;      circumtable[11] =   300.0;
  circumtable[12] =   1000.0;      circumtable[13] = 10000.0;
  circumtable[14] = 100000.0;      circumtable[15] =     0.0;
  for (i = 0; i < 16; i++) {
    circumcount[i] = 0;
  }

  shortest = 0.0;
  longest = 0.0;
  smallestvolume = 0.0;
  biggestvolume = 0.0;
  minaltitude = 0.0;
  worstaspect = 0.0;
  worstcircumratio = 0.0;
  smallestangle = 100.0;
  biggestangle = 0.0;
  acutebiggestflag = 1;

  firstiterationflag = 1;
  tetcomplexiteratorinit(plex, &position);
  tetcomplexiteratenoghosts(&position, tet);
  while (tet[0] != STOP) {

    tensortransformtet(plex, tet[0], tet[1], tet[2], tet[3], point);
    
    pyrshortest2 = 0.0;
    pyrlongest2 = 0.0;
    pyrbiggestface2 = 0.0;

    for (i = 0; i < 4; i++) {
      j = (i + 1) & 3;
      if ((i & 1) == 0) {
        k = (i + 3) & 3;
        l = (i + 2) & 3;
      } else {
        k = (i + 2) & 3;
        l = (i + 3) & 3;
      }

      facenormal[i][0] =
        (point[k][1] - point[j][1]) * (point[l][2] - point[j][2]) -
        (point[k][2] - point[j][2]) * (point[l][1] - point[j][1]);
      facenormal[i][1] =
        (point[k][2] - point[j][2]) * (point[l][0] - point[j][0]) -
        (point[k][0] - point[j][0]) * (point[l][2] - point[j][2]);
      facenormal[i][2] =
        (point[k][0] - point[j][0]) * (point[l][1] - point[j][1]) -
        (point[k][1] - point[j][1]) * (point[l][0] - point[j][0]);
      facearea2 = facenormal[i][0] * facenormal[i][0] +
                  facenormal[i][1] * facenormal[i][1] +
                  facenormal[i][2] * facenormal[i][2];
      if (facearea2 > pyrbiggestface2) {
        pyrbiggestface2 = facearea2;
      }

      for (j = i + 1; j < 4; j++) {
        dx = point[i][0] - point[j][0];
        dy = point[i][1] - point[j][1];
        dz = point[i][2] - point[j][2];
        edgelength[i][j] = dx * dx + dy * dy + dz * dz;
        if (edgelength[i][j] > pyrlongest2) {
          pyrlongest2 = edgelength[i][j];
        }
        if ((j == 1) || (edgelength[i][j] < pyrshortest2)) {
          pyrshortest2 = edgelength[i][j];
        }
      }
    }
    if (pyrlongest2 > longest) {
      longest = pyrlongest2;
    }
    if ((pyrshortest2 < shortest) || firstiterationflag) {
      shortest = pyrshortest2;
    }

    pyrvolume = (starreal)
      orient3d(behave, point[0], point[1], point[2], point[3]);
    if ((pyrvolume < smallestvolume) || firstiterationflag) {
      smallestvolume = pyrvolume;
    }
    if (pyrvolume > biggestvolume) {
      biggestvolume = pyrvolume;
    }
    pyrminaltitude2 = pyrvolume * pyrvolume / pyrbiggestface2;
    if ((pyrminaltitude2 < minaltitude) || firstiterationflag) {
      minaltitude = pyrminaltitude2;
    }
    pyraspect2 = pyrlongest2 / pyrminaltitude2;
    if (pyraspect2 > worstaspect) {
      worstaspect = pyraspect2;
    }
    aspectindex = 0;
    while ((pyraspect2 >
            aspecttable[aspectindex] * aspecttable[aspectindex]) &&
           (aspectindex < 15)) {
      aspectindex++;
    }
    aspectcount[aspectindex]++;

    tetcircumcenter(behave, point[0], point[1], point[2], point[3], tcenter,
                    (starreal *) NULL, (starreal *) NULL, (starreal *) NULL);
    pyrcircumratio2 = (tcenter[0] * tcenter[0] + tcenter[1] * tcenter[1] +
                       tcenter[2] * tcenter[2]) / pyrshortest2;
    if (pyrcircumratio2 > worstcircumratio) {
      worstcircumratio = pyrcircumratio2;
    }
    circumindex = 0;
    while ((pyrcircumratio2 >
            circumtable[circumindex] * circumtable[circumindex]) &&
           (circumindex < 15)) {
      circumindex++;
    }
    circumcount[circumindex]++;

    for (i = 0; i < 3; i++) {
      for (j = i + 1; j < 4; j++) {
        k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
        l = 6 - i - j - k;
        dotproduct = facenormal[i][0] * facenormal[j][0] +
                     facenormal[i][1] * facenormal[j][1] +
                     facenormal[i][2] * facenormal[j][2];
        if (dotproduct == 0.0) {
          anglecount[9]++;
          if (acutebiggestflag)
          {
              biggestangle = 1.0e+300;
              acutebiggestflag = 0;
          }
        } else {
          tansquare = pyrvolume * pyrvolume * edgelength[k][l] /
                      (dotproduct * dotproduct);
          tendegree = 8;
          for (ii = 7; ii >= 0; ii--) {
            if (tansquare < tansquaretable[ii]) {
              tendegree = ii;
            }
          }
          if (dotproduct < 0.0) {
            anglecount[tendegree]++;
            if (tansquare < smallestangle) {
              smallestangle = tansquare;
            }
            if (acutebiggestflag && (tansquare > biggestangle)) {
              biggestangle = tansquare;
            }
          } else {
            anglecount[17 - tendegree]++;
            if (acutebiggestflag || (tansquare < biggestangle)) {
              biggestangle = tansquare;
              acutebiggestflag = 0;
            }
          }
        }
      }
    }

    tetcomplexiteratenoghosts(&position, tet);
    firstiterationflag = 0;
  }

  shortest = sqrt(shortest);
  longest = sqrt(longest);
  minaltitude = sqrt(minaltitude);
  worstaspect = sqrt(worstaspect);
  worstcircumratio = sqrt(worstcircumratio);
  smallestvolume /= 6.0;
  biggestvolume /= 6.0;
  smallestangle = degconst * atan(sqrt(smallestangle));
  if (acutebiggestflag) {
    biggestangle = degconst * atan(sqrt(biggestangle));
  } else {
    biggestangle = 180.0 - degconst * atan(sqrt(biggestangle));
  }

  *outsmallestangle = smallestangle;
  *outbiggestangle = biggestangle;
}










/* given the two vertices of a known boundary edge,
   compute the angle between it's two incident
   boundary faces */
starreal getboundaryedgeangle(struct tetcomplex *mesh,
                            tag v1,
                            tag v2,
                            tag vleft,
                            tag vright)
{
    starreal point[4][3];      /* the actual positions of the four vertices*/
    starreal e[3][3];          /* edges for normal computation */
    starreal norm[2][3];       /* face normals */
    starreal edgelength;       /* length of boundary edge */
    starreal volume;           /* volume of tet formed by four vertices */
    starreal dotprod;          /* the dot product of the two inward face normals */
    starreal tantheta;         /* tangent of the angle */
    starreal angle;            /* angle we are computing */
    
    /* make sure neither of these are GHOST vertices themselves */
    assert(vleft != GHOSTVERTEX);
    assert(vright != GHOSTVERTEX);
    
    /* fetch actual vertex values */
    tensortransformtet(mesh, v1, v2, vleft, vright, point);
  
    /* e[0] from v1 to v2 */
    vsub(point[1], point[0], e[0]);
    /* e[1] from v1 to right */
    vsub(point[2], point[0], e[1]);
    /* e[2] from v1 to left */
    vsub(point[3], point[0], e[2]);
    
    /* compute the length of the edge in question */
    edgelength = vlength(e[0]);
    
    /* compute face normals, pointing out of the mesh interior */
    cross(e[1], e[0], norm[0]);
    cross(e[0], e[2], norm[1]);
    
    /* compute 6 * volume of the tetrahedron with these four vertices */
    volume = (starreal) orient3d(&improvebehave->behave, point[0], point[1], point[2], point[3]);
    
    /* find the dot product of the two vectors */
    dotprod = dot(norm[0], norm[1]);
    
    /* if the dot product is zero, then the angle is +-90 degrees */
    if (dotprod == 0)
    {
        /* if the volume is negative, angle is 270 degrees */
        angle = (volume > 0) ? PI / 2.0 : (3.0 * PI) / 2.0;
    }
    else
    {
        /* compute the tangent of the angle using the tangent formula:
    
           tan(theta_ij) = - 6 * V * l_ij
                           --------------
                            dot(n_k, n_l)
                        
           because this formula is accurate in the entire range.
        */
        tantheta = (-volume * edgelength) / dotprod;
        
        /* now compute the actual angle */
        angle = atan(tantheta);
        
        if (improvebehave->verbosity > 5)
        {
            printf("Raw arctan answer was %g, volume is %g and dotprod is %g\n", angle, volume, dotprod);
        }
        
        /* adjust angle for sign of dot product */
        if (dotprod > 0)
        {
            angle += PI;
        }
        
        /* make negative angles positive */
        if (angle < 0)
        {
            angle += 2.0 * PI;
        }
        
        if (improvebehave->verbosity > 5)
        {
            printf("Final angle found is %g radians, or %g degrees\n", angle, angle * (180.0 / PI));
        }
        
        /* zero angles must actually be 360 degrees...?? */
        if (angle == 0)
        {
            if (improvebehave->verbosity > 5)
            {
                printf("correcting zero to 360...\n");
            }
            angle = 2.0 * PI;
        }
    }
    
    return angle;
}











/* given an input mesh, find the worst "input" angle.
   that is, find the smallest angle between two faces
   of the boundary */
starreal worstinputangle(struct tetcomplex *mesh)
{
    starreal angle;                     /* angle between two surface faces */
    starreal worstangle = 2.0 * PI;     /* worst input angle */
    starreal minqual, meanqual[NUMMEANTHRESHOLDS];         /* quality of the worst tet in the mesh */
    struct arraypoolstack tetstack;   /* stack of tets  */
    int numboundedges;                /* number of boundary edges for a tet */
    tag edgelist[6][2];               /* list of boundary edges for a tet */
    tag edgefaces[6][2];
    struct improvetet * stacktet;     /* tet we're pulling off the stack */
    int i;
    
    stackinit(&tetstack, sizeof(struct improvetet));
    
    /* fill the stack of tets with all tets in the mesh */
    fillstackqual(mesh, &tetstack, HUGEFLOAT, meanqual, &minqual);
    
    /* go through each tet on the stack */
    while (tetstack.top != STACKEMPTY)
    {
        /* pull the top tet off the stack */
        stacktet = (struct improvetet *) stackpop(&tetstack);
        
        /* check for any boundary edges */
        numboundedges = boundedges(mesh,
                                   stacktet->verts[0], 
                                   stacktet->verts[1], 
                                   stacktet->verts[2], 
                                   stacktet->verts[3],
                                   edgelist,
                                   edgefaces,
                                   NULL,
                                   NULL);
        
        if (numboundedges != 0)
        {
            if (improvebehave->verbosity > 5)
            {
                printf("tet (%d %d %d %d) has %d bound edges:\n", (int) stacktet->verts[0], 
                                                                  (int) stacktet->verts[1], 
                                                                  (int) stacktet->verts[2], 
                                                                  (int) stacktet->verts[3],
                                                                  numboundedges);
            }
            /* for each boundary edge */
            for (i=0; i<numboundedges; i++)
            {
                if (improvebehave->verbosity > 5)
                {
                    printf("testing boundary edge (%d, %d)\n", (int) edgelist[i][0], (int) edgelist[i][1]);
                }
                
                /* compute the angle between the boundary faces */
                angle = getboundaryedgeangle(mesh, edgelist[i][0], edgelist[i][1], edgefaces[i][0], edgefaces[i][1]);
            
                /* if this angle is smaller than what we've seen, update */
                if (angle < worstangle)
                {
                    if (improvebehave->verbosity > 5)
                    {
                        printf("New worst angle of %g radians (%g degrees) found\n", angle, angle * (180.0 / PI));
                    }
                    worstangle = angle;
                }
            }
        }
    }
    
    /* free the stack of tets */
    stackdeinit(&tetstack);
    
    return worstangle; 
}










/* gather some information about the worst tets in the mesh */
/* according to the given quality measure, report information
   about all the tets within degreesfromworst of the worst tet */
void worsttetreport(struct tetcomplex *mesh,
                    starreal degreesfromworst)
{
    starreal minqual, meanqual[NUMMEANTHRESHOLDS];            /* quality of the worst tet in the mesh */
    struct arraypoolstack tetstack;      /* stack of tets  */
    struct improvetet *stacktet;         /* current tet */
    starreal threshold;                    /* tets worse than this will be investigated */  
    int numbadtets=0;                    /* number of naughty tets */
    int numboundverts;                   /* number of boundary verts in the current tet */
    int numboundedges;
    int numboundfaces;
    int boundvertshist[5] = {0,0,0,0,0}; /* histogram of the number of boundary vertices */
    int boundfaceshist[5] = {0,0,0,0,0};
    int boundedgeshist[7] = {0,0,0,0,0,0,0};
    tag boundtags[4];                   /* boundary verts of a particular tet */
    bool bfaces;
    tag boundfacetags[4][3];
    tag boundedgetags[6][2];
    tag boundedgefaces[6][2];
    int i;
    int nbvworst=0, nbeworst=0, nbfworst=0;
    starreal worstseen = 100.0;
    tag worstverts[4] = {0,0,0,0};
    
    /* initialize the tet stack */
    stackinit(&tetstack, sizeof(struct improvetet));
    
    /* fill the stack of tets with all tets in the mesh */
    fillstackqual(mesh, &tetstack, HUGEFLOAT, meanqual, &minqual);
    
    /* set the threshold below which we'll investigate this tet */
    threshold = minqual + sin(degreesfromworst * (PI / 180.0));
    
    /* now go through the stack collecting information */
    while (tetstack.top != STACKEMPTY)
    {
        /* pull the top tet off the stack */
        stacktet = (struct improvetet *) stackpop(&tetstack);
        
        /* don't go any further if this tet isn't one of the worst */
        if (stacktet->quality > threshold) continue;
        
        numbadtets++;
        
        /* fetch the number of boundary vertices for this tet */
        numboundverts = boundverts(mesh, 
                                   stacktet->verts[0],
                                   stacktet->verts[1],
                                   stacktet->verts[2],
                                   stacktet->verts[3],
                                   boundtags);
                                   
        numboundedges = boundedges(mesh, 
                                   stacktet->verts[0],
                                   stacktet->verts[1],
                                   stacktet->verts[2],
                                   stacktet->verts[3],
                                   boundedgetags,
                                   boundedgefaces,
                                   NULL,
                                   NULL);
                                  
        bfaces = boundfaces(mesh,
                            stacktet->verts[0],
                            stacktet->verts[1],
                            stacktet->verts[2],
                            stacktet->verts[3],
                            boundfacetags,
                            &numboundfaces);
                            
        if (stacktet->quality <= worstseen)
        {
            worstseen = stacktet->quality;
            worstverts[0] = stacktet->verts[0];
            worstverts[1] = stacktet->verts[1];
            worstverts[2] = stacktet->verts[2];
            worstverts[3] = stacktet->verts[3]; 
            nbvworst = numboundverts;
            nbeworst = numboundedges;
            nbfworst = numboundfaces;
        }
                                   
        boundvertshist[numboundverts]++;
        boundedgeshist[numboundedges]++;
        boundfaceshist[numboundfaces]++;
    }
    
    /* free the stack of tets */
    stackdeinit(&tetstack);
    
    /* print report */
    printf("\nWorst tet report:\n");
    printf("    Worst overall quality: %g\n", minqual);
    printf("    Worst tet (%d, %d, %d, %d) had %d vertices, %d edges, and %d faces on boundary.\n",
                                                                            (int) worstverts[0],
                                                                            (int) worstverts[1],
                                                                            (int) worstverts[2],
                                                                            (int) worstverts[3],
                                                                            nbvworst,
                                                                            nbeworst,
                                                                            nbfworst);
    printf("    Here is the worst tet:\n");
    printtetvertssep(mesh, worstverts[0], worstverts[1], worstverts[2], worstverts[3]);
    printf("\n");
    printf("    Number of tets within %g degrees of worst: %d\n", degreesfromworst, numbadtets);
    printf("    Number of boundary vertices in these tets:\n");
    for (i=0; i<5; i++)
    {
        printf("        [%d]: %d\n", i, boundvertshist[i]);
    }
    printf("    Number of boundary edges in these tets:\n");
    for (i=0; i<7; i++)
    {
        printf("        [%d]: %d\n", i, boundedgeshist[i]);
    }
    printf("    Number of boundary faces in these tets:\n");
    for (i=0; i<5; i++)
    {
        printf("        [%d]: %d\n", i, boundfaceshist[i]);
    }
    printf("\n");
}







/* compute the mean and minimum element
 qualities in the mesh (multiple thresholded means) */
void meshquality(struct tetcomplex *mesh,
                 starreal *meanqual,
                 starreal *minqual)
{
  struct arraypoolstack tetstack;   /* stack of tets  */
  
  stackinit(&tetstack, sizeof(struct improvetet));
  
  /* fill the stack of tets with all tets in the mesh */
  fillstackqual(mesh, &tetstack, HUGEFLOAT, meanqual, minqual);
  
  improvestats.finishworstqual = *minqual;
  
  /* free the stack of tets */
  stackdeinit(&tetstack);
}


/* compute the mean and minimum element
 qualities in the mesh (multiple thresholded means) */
void meshquality_physical(struct tetcomplex *mesh,
                          starreal *meanqual,
                          starreal *minqual)
{
  struct arraypoolstack tetstack;   /* stack of tets  */
  
  stackinit(&tetstack, sizeof(struct improvetet));
  
  /* fill the stack of tets with all tets in the mesh */
  fillstackqual_physical(mesh, &tetstack, HUGEFLOAT, meanqual, minqual);
  
  improvestats.finishworstqual = *minqual;
  
  /* free the stack of tets */
  stackdeinit(&tetstack);
}





/* return the worst quality of all elements in the mesh */
double worstquality(struct tetcomplex*mesh)
{
  starreal meanqual[NUMMEANTHRESHOLDS];
  starreal minqual;
  
  struct arraypoolstack tetstack;   /* stack of tets  */
  
  stackinit(&tetstack, sizeof(struct improvetet));
  
  /* fill the stack of tets with all tets in the mesh */
  fillstackqual(mesh, &tetstack, HUGEFLOAT, meanqual, &minqual);
  
  /* free the stack of tets */
  stackdeinit(&tetstack);
  
  return minqual;
}



