#pragma once

#include "structs.h"

/* harness function for quality measure callback */
starreal tetquality(struct tetcomplex *mesh, 
                    tag vtx1, 
                    tag vtx2,
                    tag vtx3,
                    tag vtx4);





/* harness function for quality measure callback (in physical space) */
starreal tetquality_physical(struct tetcomplex *mesh, 
                             tag vtx1, 
                             tag vtx2,
                             tag vtx3,
                             tag vtx4);



/* get extreme dihedral angles in any tet in the mesh */
void getextremeangles(struct behavior *behave,
                      struct tetcomplex *plex,
                      starreal *outsmallestangle,
                      starreal *outbiggestangle);


/* given an input mesh, find the worst "input" angle.
 that is, find the smallest angle between two faces
 of the boundary */
starreal worstinputangle(struct tetcomplex *mesh);


/* gather some information about the worst tets in the mesh */
/* according to the given quality measure, report information
 about all the tets within degreesfromworst of the worst tet */
void worsttetreport(struct tetcomplex *mesh,
                    starreal degreesfromworst);





/* compute the mean and minimum element
 qualities in the mesh (multiple thresholded means) */
void meshquality(struct tetcomplex *mesh,
                 starreal *meanqual,
                 starreal *minqual);



/* compute the mean and minimum element
 qualities in the mesh (multiple thresholded means) */
void meshquality_physical(struct tetcomplex *mesh,
                          starreal *meanqual,
                          starreal *minqual);




/* return the worst quality of all elements in the mesh */
double worstquality(struct tetcomplex*mesh);



