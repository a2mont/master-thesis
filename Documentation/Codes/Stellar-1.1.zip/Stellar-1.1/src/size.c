/* size control functions */

#include "size.h"
#include "util.h"
#include "vector.h"
#include "arraypoolstack.h"
#include "anisotropy.h"
#include "journal.h"
#include "topological.h"
#include "insertion.h"
#include "smoothing.h"
#include "quality.h"
#include "timer.h"

/* compute statistics about tetrahedra volumes */
void volumestats(struct tetcomplex *mesh,
                 starreal *minvol,
                 starreal *maxvol,
                 starreal *meanvol)
{
    struct tetcomplexposition pos; /* position of iterator in the mesh */
    tag tet[4];                    /* the current tet */
    starreal volume;               /* the volume of the current tet */
    int numtets = 0;               /* number of tets in the mesh */
    
    *minvol = HUGEFLOAT;
    *maxvol = 0.0;
    *meanvol = 0.0;
    
    /* initialize the iterator over the mesh */
    tetcomplexiteratorinit(mesh, &pos);
    /* retrieve the first tet in the mesh */
    tetcomplexiteratenoghosts(&pos, tet);
    
    /* for each tet */
    while (tet[0] != STOP) 
    {
        /* compute the quality of this tet */
        volume = tetvolume(mesh, tet[0], tet[1], tet[2], tet[3]);
        
        /* keep track of minimum, maximum and average volume */
        if (volume < *minvol) *minvol = volume;
        if (volume > *maxvol) *maxvol = volume;
        *meanvol += volume;
        
        /* fetch the next tet from the mesh */
        tetcomplexiteratenoghosts(&pos, tet);
        numtets++;
    }
    assert(numtets != 0);
    assert(*meanvol > 0.0);
    assert(*minvol > 0.0);
    
    /* compute average */
    *meanvol /= numtets;
}

/* compute the worst min/max edge length ratio for tets in the mesh */
void edgelengthdisparitystats(struct tetcomplex * mesh,
						  starreal *bestdisparity,
						  starreal *worstdisparity,
						  starreal *meandisparity,
						  starreal *mediandisparity,
						  bool anisotropic)
{
	struct tetcomplexposition pos; /* position of iterator in the mesh */
    tag tet[4];                    /* the current tet */
    tag adjacencies[2];
    tag origin;
    tag destin;
    tag apex;
    tag stopvtx;
    tag searchvtx = NOTATAG;
    tag swaptag;
    int writeflag = 0;
    int i;
    starreal edgev[3];
    starreal edgelength;
    starreal edgecoords[2][3];

	/* per-tet min, max edges and lengths */
	starreal tetminedgelen, tetmaxedgelen;
	starreal tetratio;

	/* store tets in a stack to compute median disparity */
    struct arraypoolstack tetstack;
    struct improvetet *stacktet;
    stackinit(&tetstack, sizeof(struct improvetet));

	*worstdisparity = 1.0;
	*bestdisparity = 0.0;
	*meandisparity = 0.0;
    
    /* initialize the iterator over the mesh */
    tetcomplexiteratorinit(mesh, &pos);
    /* retrieve the first tet in the mesh */
    tetcomplexiteratenoghosts(&pos, tet);
    
    /* for each tet */
    while (tet[0] != STOP) 
    {
		tetminedgelen = HUGEFLOAT;
		tetmaxedgelen = 0.0;

        /* Look at all six edges of the tetrahedron. */
        /* Iteration over unique edges taken from Jonathan's outputedges() */
        for (i = 0; i < 6; i++) 
        {
            if (tet[0] < tet[1]) 
            {
                origin = tet[0];
                destin = tet[1];
                apex = tet[2];
                stopvtx = tet[3];
            } 
            else
            {
                origin = tet[1];
                destin = tet[0];
                apex = tet[3];
                stopvtx = tet[2];
            }
            
            searchvtx = apex;
            writeflag = 1;
            do 
            {
                if (!tetcomplexadjacencies(mesh, origin, destin, searchvtx,
                                         adjacencies)) 
                {
                    printf("Error computing edge statistics:\n");
                    printf("  Complex returned tetrahedron that can't be queried.\n");
                    internalerror();
                }
                if (adjacencies[0] == GHOSTVERTEX) 
                {
                    writeflag = searchvtx == apex;
                }
                searchvtx = adjacencies[0];
                if (searchvtx < apex) 
                {
                    writeflag = 0;
                }
            } 
            while (writeflag && (searchvtx != stopvtx) && (searchvtx != GHOSTVERTEX));

          tensortransformedge(mesh, origin, destin, edgecoords);
          vsub(edgecoords[0], edgecoords[1], edgev);
          edgelength = vlength(edgev);
          
			/* keep track of minimum, maximum edge lengths */
			if (edgelength < tetminedgelen) tetminedgelen = edgelength;
			if (edgelength > tetmaxedgelen) tetmaxedgelen = edgelength;
            
            /* The following shift cycles (tet[0], tet[1]) through all the edges   */
            /*   while maintaining the tetrahedron's orientation.  The schedule is */
            /*   i = 0:  0 1 2 3 => 1 2 0 3                                        */
            /*   i = 1:  1 2 0 3 => 1 3 2 0                                        */
            /*   i = 2:  1 3 2 0 => 3 2 1 0                                        */
            /*   i = 3:  3 2 1 0 => 3 0 2 1                                        */
            /*   i = 4:  3 0 2 1 => 0 2 3 1                                        */
            /*   i = 5:  0 2 3 1 => 0 1 2 3 (which isn't used).                    */
            if ((i & 1) == 0) 
            {
                swaptag = tet[0];
                tet[0] = tet[1];
                tet[1] = tet[2];
                tet[2] = swaptag;
            } 
            else
            {
                swaptag = tet[3];
                tet[3] = tet[2];
                tet[2] = tet[1];
                tet[1] = swaptag;
            }
        }

		/* Compute edgelength disparity */
		tetratio = tetminedgelen / tetmaxedgelen;
		if (tetratio > *bestdisparity) *bestdisparity = tetratio;
		if (tetratio < *worstdisparity) *worstdisparity = tetratio;
		(*meandisparity) += tetratio;

		/* push this tet on the median stack */
		stacktet = (struct improvetet *) stackpush(&tetstack);
		stacktet->quality = tetratio;
        
        /* fetch the next tet from the mesh */
        tetcomplexiteratenoghosts(&pos, tet);
    }

	assert(*worstdisparity > 0.0);
	assert(*bestdisparity <= 1.0);
	assert(*meandisparity > 0.0);
    
    /* compute mean */
    *meandisparity /= counttets(mesh);
    
    /* compute median */
    sortstack(&tetstack, false);
    *mediandisparity = ((struct improvetet *) arraypoolfastlookup(&(tetstack.pool), (unsigned long) (tetstack.top + 1) / 2))->quality;
    
    stackdeinit(&tetstack);
}

/* compute statistics about edge lengths in the mesh */
void edgelengthstats(struct tetcomplex *mesh,
                     starreal *minedge,
                     starreal *maxedge,
                     starreal *meanedge,
                     starreal *medianedge,
                     bool anisotropic)
{
    struct tetcomplexposition pos; /* position of iterator in the mesh */
    tag tet[4];                    /* the current tet */
    int numedges = 0;              /* number of edges in the mesh */
    tag adjacencies[2];
    tag origin;
    tag destin;
    tag apex;
    tag stopvtx;
    tag searchvtx = NOTATAG;
    tag swaptag;
    int writeflag = 0;
    int i;
    starreal edge[3];
    starreal edgelength;
    starreal edgecoords[2][3];
    
    /* a hack: store edge lengths in a tet stack to compute median */
    struct arraypoolstack edgestack;
    struct improvetet *edgetet;
    stackinit(&edgestack, sizeof(struct improvetet));
    
    *minedge = HUGEFLOAT;
    *maxedge = 0.0;
    *meanedge = 0.0;
    
    /* initialize the iterator over the mesh */
    tetcomplexiteratorinit(mesh, &pos);
    /* retrieve the first tet in the mesh */
    tetcomplexiteratenoghosts(&pos, tet);
    
    /* for each tet */
    while (tet[0] != STOP) 
    {
        /* Look at all six edges of the tetrahedron. */
        /* Iteration over unique edges taken from Jonathan's outputedges() */
        for (i = 0; i < 6; i++) 
        {
            if (tet[0] < tet[1]) 
            {
                origin = tet[0];
                destin = tet[1];
                apex = tet[2];
                stopvtx = tet[3];
            } 
            else
            {
                origin = tet[1];
                destin = tet[0];
                apex = tet[3];
                stopvtx = tet[2];
            }
            
            searchvtx = apex;
            writeflag = 1;
            do 
            {
                if (!tetcomplexadjacencies(mesh, origin, destin, searchvtx,
                                         adjacencies)) 
                {
                    printf("Error computing edge statistics:\n");
                    printf("  Complex returned tetrahedron that can't be queried.\n");
                    internalerror();
                }
                if (adjacencies[0] == GHOSTVERTEX) 
                {
                    writeflag = searchvtx == apex;
                }
                searchvtx = adjacencies[0];
                if (searchvtx < apex) 
                {
                    writeflag = 0;
                }
            } 
            while (writeflag && (searchvtx != stopvtx) && (searchvtx != GHOSTVERTEX));
            
            /* if this is an edge that hasn't been counted yet */
            if (writeflag) 
            {
                if (anisotropic)
                  tensortransformedge(mesh, origin, destin, edgecoords);
                else {
                  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, origin))->coord, edgecoords[0]);
                  vcopy(((struct vertex *) tetcomplextag2vertex(mesh, destin))->coord, edgecoords[1]);
                }
                  
                vsub(edgecoords[0], edgecoords[1], edge);
                edgelength = vlength(edge);
                
                /* push this edge length on the stack */
                edgetet = (struct improvetet *) stackpush(&edgestack);
                edgetet->quality = edgelength;
                
                /* keep track of minimum, maximum and average edge lengths */
                if (edgelength < *minedge) *minedge = edgelength;
                if (edgelength > *maxedge) *maxedge = edgelength;
                (*meanedge) += edgelength;
                /*
                printf("origcoord is [%g %g %g]\n", origcoord[0], origcoord[1], origcoord[2]);
                printf("destcoord is [%g %g %g]\n", destcoord[0], destcoord[1], destcoord[2]);
                printf("edglength is %g\n", edgelength);
                printf("meanedge for edgenum %d is %g\n", numedges, *meanedge);
                */
                numedges++;
            }
            
            /* The following shift cycles (tet[0], tet[1]) through all the edges   */
            /*   while maintaining the tetrahedron's orientation.  The schedule is */
            /*   i = 0:  0 1 2 3 => 1 2 0 3                                        */
            /*   i = 1:  1 2 0 3 => 1 3 2 0                                        */
            /*   i = 2:  1 3 2 0 => 3 2 1 0                                        */
            /*   i = 3:  3 2 1 0 => 3 0 2 1                                        */
            /*   i = 4:  3 0 2 1 => 0 2 3 1                                        */
            /*   i = 5:  0 2 3 1 => 0 1 2 3 (which isn't used).                    */
            if ((i & 1) == 0) 
            {
                swaptag = tet[0];
                tet[0] = tet[1];
                tet[1] = tet[2];
                tet[2] = swaptag;
            } 
            else
            {
                swaptag = tet[3];
                tet[3] = tet[2];
                tet[2] = tet[1];
                tet[1] = swaptag;
            }
        }
        
        /* fetch the next tet from the mesh */
        tetcomplexiteratenoghosts(&pos, tet);
    }
    assert(numedges != 0);
    assert(*meanedge > 0.0);
    assert(*minedge > 0.0);
    assert(*maxedge < HUGEFLOAT);
    
    /* compute average */
    *meanedge /= numedges;
    
    /* compute median */
    sortstack(&edgestack, false);
    *medianedge = ((struct improvetet *) arraypoolfastlookup(&(edgestack.pool), (unsigned long) (edgestack.top + 1) / 2))->quality;
    
    stackdeinit(&edgestack);
}

/* attempt to collapse edges that are too short */
void sizecontract(struct tetcomplex *mesh,
                  struct arraypoolstack *tetstack, 
									bool requireminqual)
{
    struct arraypoolstack outstack;
    struct improvetet *stacktet, *outtet;
    bool contracted = false;
    starreal minqualbefore, minqualafter;
    
    /* for ring tet query */
    int numringtets;
    tag ringtets[MAXRINGTETS][4];
    tag bfverts[2];
    bool boundedge;
    int i;
		int beforeid;
    
    /* initialize output stack */
    stackinit(&outstack, sizeof(struct improvetet));
    
    /* go through each tet on the stack */
    while (tetstack->top != STACKEMPTY)
    {
        starreal quadricscale = improvebehave->quadricscale;
			
        /* pull the top tet off the stack */
        stacktet = (struct improvetet *) stackpop(tetstack);
        
        /* check that this tet still exists */
        if (!tetexistsa(mesh, stacktet->verts))
        {
            continue;
        }
        
				beforeid = lastjournalentry();
			
				improvebehave->quadricscale = improvebehave->sizecontractquadricscale;
			
        /* try to contract this edge */
        contracted = edgecontract(mesh,
                                  stacktet->verts[0],
                                  stacktet->verts[1],
                                  stacktet->verts[2],
                                  stacktet->verts[3],
                                  &minqualbefore,
                                  &minqualafter,
                                  NULL, NULL,
                                  false);
        
				improvebehave->quadricscale = quadricscale;

				/* if we require maintaining quality, and if the quality wasn't maintained, mark this
					 as failed, even if it succeeded */
				if (contracted && requireminqual && 
						minqualbefore > minqualafter && 
						minqualafter < improvebehave->goalquality) {
					contracted = false;
					invertjournalupto(mesh, beforeid);
				}
			
        if (contracted)
        {
            if (improvebehave->verbosity > 5)
            {
                printf("Succeeded in contracting edge for size control. Qual went from %g to %g\n", minqualbefore, minqualafter);
            }
        }
        else
        {
            /* we couldn't directly contract this edge. but if we can contract any edge
               of a tetrahedron that surrounds this edge, this edge will go away too */
            /* fetch all the tets that surround this edge */
            boundedge = getedgering(mesh,
                                    stacktet->verts[0],
                                    stacktet->verts[1],
                                    stacktet->verts[2],
                                    stacktet->verts[3],
                                    &numringtets, ringtets, bfverts);
            
            if (improvebehave->verbosity > 5)
            {
                printf("Couldn't directly contract short edge (%d %d). Attempting collapse on surrounding tets\n", (int) stacktet->verts[0], (int) stacktet->verts[1]);
                printf("    Edge was boundary edge: %d\n", boundedge);
                printf("    Number surrounding tets: %d\n", numringtets);
            }
            
            /* try to collapse just first edge of each tet */
            for (i=0; i<numringtets; i++)
            {
								beforeid = lastjournalentry();
															
								improvebehave->quadricscale = improvebehave->sizecontractquadricscale;

								contracted = tryedgecontract(mesh,
                                             ringtets[i][0],
                                             ringtets[i][1],
                                             ringtets[i][2],
                                             ringtets[i][3],
                                             NULL,
																						 &minqualbefore,
                                             &minqualafter,
                                             false,
                                             true);
								
								improvebehave->quadricscale = quadricscale;
							
								/* if we require maintaining quality, and if the quality wasn't maintained, mark this
								 as failed, even if it succeeded */
								if (contracted && requireminqual && 
										minqualbefore > minqualafter && 
										minqualafter < improvebehave->goalquality) {
									contracted = false;
									invertjournalupto(mesh, beforeid);
								}
															
								/* if we succeed in contracting an edge, stop trying */
                if (contracted)
                {
                    if (improvebehave->verbosity > 5)
                    {
                        printf("Contraction succeeded on subsidiary tet %d!\n", i);
                    }
                    
                    break;
                }
            }
        }
        
        if (!contracted)
        {
            if (improvebehave->verbosity > 5)
            {
                printf("Couldn't contract any edge in size control. Adding to output stack.\n");
            }
            /* is this tet already on the output stack? */
            if (!tetinstack(&outstack, stacktet->verts[0], stacktet->verts[1], stacktet->verts[2], stacktet->verts[3]))
            {
                /* push tet on output stack */
                outtet = (struct improvetet *) stackpush(&outstack);
                outtet->verts[0] = stacktet->verts[0];
                outtet->verts[1] = stacktet->verts[1];
                outtet->verts[2] = stacktet->verts[2];
                outtet->verts[3] = stacktet->verts[3];
                outtet->quality = stacktet->quality;
            }
        }
    }
    
    /* copy the output stack over the input stack */
    copystack(&outstack, tetstack);
    /* free the local output stack */
    stackdeinit(&outstack);
}

/* attempt to split edges that are too long */
void sizesplit(struct tetcomplex *mesh,
               struct arraypoolstack *tetstack,
							 bool requireminqual)
{
    struct arraypoolstack outstack;
    struct improvetet *stacktet, *outtet;
    int numedgetets;
    tag edgetets[MAXRINGTETS][4];
    tag edgefaces[2];
    bool boundedge, success;
    tag vnew; 
    static tag newfaces[MAXCAVITYFACES][3]; /* faces of tets created after insert for seeding cavity drilling */
    int numnewfaces;               
    static tag newtets[MAXCAVITYTETS][4]; /* tets that filled in cavity */
    int numnewtets;
    int beforeid;
    starreal minquality = HUGEFLOAT;
    starreal worstdeletedqual, origcavityqual, cavityqual;
    starreal longest = 0.0, shortest = HUGEFLOAT;
    starreal means[NUMMEANTHRESHOLDS], meshworst, physworst;
    int smoothkinds = 0;
		starreal requiredquality = requireminqual ? improvebehave->goalquality : MINSIZESPLITQUAL;
    bool cavityimprovefail = false;
    
    if (improvebehave->facetsmooth) smoothkinds |= SMOOTHFACETVERTICES;
    if (improvebehave->segmentsmooth) smoothkinds |= SMOOTHSEGMENTVERTICES;
    if (improvebehave->cornersmooth) smoothkinds |= SMOOTHCORNERVERTICES;

    /* initialize output stack */
    stackinit(&outstack, sizeof(struct improvetet));
    
    /* go through each tet on the stack */
    while (tetstack->top != STACKEMPTY)
    {
        int beforesmoothid;
        starreal smoothqual;
        bool smoothed = false;
        int j = 0;
      
        /* pull the top tet off the stack */
        stacktet = (struct improvetet *) stackpop(tetstack);
        
        /* check that this tet still exists */
        if (!tetexistsa(mesh, stacktet->verts))
        {
            continue;
        }
        
        /* save the mesh state before we attempt insertion */
        beforeid = lastjournalentry(); 
        
        /* fetch the ring of tets around this edge */
        boundedge = getedgering(mesh, 
                                stacktet->verts[0],
                                stacktet->verts[1],
                                stacktet->verts[2],
                                stacktet->verts[3],
                                &numedgetets,
                                edgetets, 
                                edgefaces);
                
        /* attempt to insert a vertex at the midpoint of this edge */
        success = segmentinsert(mesh,
                                stacktet->verts[0],
                                stacktet->verts[1],
                                stacktet->verts[2],
                                stacktet->verts[3], 
                                numedgetets, 
                                edgetets,
                                edgefaces,
                                &vnew, 
                                newfaces, &numnewfaces,
                                newtets, &numnewtets, boundedge);
                                
        /* if that didn't work out, reverse things */
        if (!success)
        {
            if (improvebehave->verbosity > 0)
            {
                printf("Initial edge insert for size control failed\n");
            }
            invertjournalupto(mesh, beforeid);
            /* push tet on output stack */
            if (!tetinstack(&outstack, stacktet->verts[0], stacktet->verts[1], stacktet->verts[2], stacktet->verts[3]))
            {
                /* push tet on output stack */
                outtet = (struct improvetet *) stackpush(&outstack);
                outtet->verts[0] = stacktet->verts[0];
                outtet->verts[1] = stacktet->verts[1];
                outtet->verts[2] = stacktet->verts[2];
                outtet->verts[3] = stacktet->verts[3];
                outtet->quality = stacktet->quality;
            }
            continue;
        }

        /* before we go into all this cavity stuff, just try to smooth the new vertex and see 
         where that leaves us */
        
        beforesmoothid = lastjournalentry();

        /* find vnew in newtets[0] */
        for (j = 0; j < 4; ++j) {
          if (newtets[0][j] == vnew) 
            break;
        }
        assert(j < 4);
      
        smoothed = nonsmoothsinglevertex(mesh,
                                         newtets[0][j],
                                         newtets[0][(j+1)%4],
                                         newtets[0][(j+2)%4],
                                         newtets[0][(j+3)%4],
                                         &smoothqual,
                                         smoothkinds);
       
        if (!smoothed || smoothqual < requiredquality) {              
          /* no success, undo smoothing (if it happened), continue with digging */
          invertjournalupto(mesh, beforesmoothid);
          
          /* insertion succeeded. dig out surrounding cavity, but don't allow vertex deletion */
          optimalcavity(mesh, vnew,
                        newtets, numnewtets, 
                        newfaces, numnewfaces, 
                        newtets, &numnewtets,
                        &worstdeletedqual,
                        &origcavityqual, false);
          
          assert(origcavityqual > 0.0);
          assert(worstdeletedqual > 0.0);
          
          /* improve the quality of tetrahedra in the cavity */
          cavityqual = improvecavity(mesh, vnew, newtets, numnewtets, false, NULL, &shortest, &longest);
          
          if (cavityqual < 0.0)
          {
              printf("improvecavity returned with negative quality %g\n", cavityqual);
          }
        } else {
          struct arraypoolstack newtetstack;
          int k;
          
          cavityqual = smoothqual;
          
          stackinit(&newtetstack, sizeof(struct improvetet));

          /* push new tets on stack */
          for (k = 0; k < numnewtets; ++k) {
            stacktet = (struct improvetet *) stackpush(&newtetstack);
            stacktet->verts[0] = newtets[k][0];
            stacktet->verts[1] = newtets[k][1];
            stacktet->verts[2] = newtets[k][2];
            stacktet->verts[3] = newtets[k][3];
          }
          
          /* compute longest and shortest edge lengths for the new tet stack */
          longshortstack(mesh, &newtetstack, &longest, &shortest);
                    
          stackdeinit(&newtetstack);
        }
          
        /* ensure some minimum quality for the cavity */
        if (improvebehave->dynsizing)
          cavityimprovefail |= (cavityqual < requiredquality && worstdeletedqual > cavityqual) || 
                               (shortest/longest < (improvebehave->minlengthratio));
        else 
          cavityimprovefail |= (cavityqual < requiredquality && worstdeletedqual > cavityqual) || 
                               (shortest < (improvebehave->targetedgelength * improvebehave->shorterfactor) /*|| 
                               longest > (improvebehave->targetedgelength * improvebehave->longerfactor) */);
        
        if (cavityimprovefail)
        {
            if (improvebehave->verbosity > 5)
            {
                printf("Edge insertion for size control failed. Cavity qual %g, needed %g, shortest edge %g\n", cavityqual, MINSIZESPLITQUAL, shortest);
            }
            invertjournalupto(mesh, beforeid);
            outtet = (struct improvetet *) stackpush(&outstack);
            outtet->verts[0] = stacktet->verts[0];
            outtet->verts[1] = stacktet->verts[1];
            outtet->verts[2] = stacktet->verts[2];
            outtet->verts[3] = stacktet->verts[3];
            outtet->quality = stacktet->quality;
            continue;
        }
        
        /* we successfully split the edge! */
        if (improvebehave->verbosity > 5)
        {
            printf("Succeeded in splitting too-long edge. min qual is %g\n", minquality);
        }
        
        if (SIZESPLITPARANOID)
        {
            /* compute global worst quality in isotropic space */
            meshquality(mesh, means, &meshworst);
            meshquality_physical(mesh, means, &physworst);
            printf("after successful sizing insertion\n");
            printf("    Worst quality, isotropic = %g\n", meshworst);
            printf("    Worst quality, physical = %g\n", physworst);
            assert(meshworst > 0.0);
            assert(physworst > 0.0);
        }
    }
    
    /* copy the output stack over the input stack */
    copystack(&outstack, tetstack);
    /* free the local output stack */
    stackdeinit(&outstack);
}

/* split and collapse edges until all tetrahedra have good edge length disparities */
int dynsizecontrol(struct tetcomplex *mesh,
                 struct behavior *behave,
                 struct inputs *in,
                 struct proxipool *vertexpool)
{
    starreal minvol = HUGEFLOAT;
    starreal maxvol = 0.0;
    starreal meanvol = 0.0;
    int numiters = 0;
    struct arraypoolstack splitstack;      /* stack of tets to try edge contractions on */
    struct arraypoolstack contractstack;   /* stack of tets to try edge splits on */
    int totaltets = 0;
    starreal percentbad;
    starreal worstqual;
    starreal physworst;
    starreal means[NUMMEANTHRESHOLDS];
        
    int passstartid;

    starreal worstdisparity, bestdisparity, meandisparity, mediandisparity;
	  starreal oldworst;
    starreal minedge, maxedge, meanedge, medianedge;
	  bool bailed = false;
    
    journalmarker("Start dynamic sizing pass");
    
    stackinit(&splitstack, sizeof(struct improvetet));
    stackinit(&contractstack, sizeof(struct improvetet));
    
    if (improvebehave->verbosity > 0)
    {
        printf("Starting dynamic size control...\n");
    }
    
    /* compute the min, max, average volume of tetrahedra in this mesh */
    volumestats(mesh, &minvol, &maxvol, &meanvol);
    
    if (improvebehave->verbosity > 1)
    {
        printf("Volume statistics:\n");
        printf("    Maximum: %g\n", maxvol);
        printf("    Minimum: %g\n", minvol);
        printf("    Average: %g\n", meanvol);
    }

    /* if the ideal edge length is set to zero, assign to it the value of the mean edge length */
    if (improvebehave->targetedgelength == 0.0)
    {
        /* compute physical edge length */
        edgelengthstats(mesh, &minedge, &maxedge, &meanedge, &medianedge, false);
        
				if (improvebehave->verbosity > 0)
					printf("Setting target edge length to physical median of %g\n", medianedge);
        
				if (improvebehave->verbosity > 1)
        {
            printf("PHYSICAL SPACE Edge length statistics:\n");
            printf("    Max edge length: %g\n", maxedge);
            printf("    Min edge length: %g\n", minedge);
            printf("    Mean edge length: %g\n", meanedge);
            printf("    Median edge length: %g\n", medianedge);
        }
        
        improvebehave->targetedgelength = medianedge;
    }

	  /* stop here unless explicit sizing pass is enabled */
    if (!improvebehave->sizingpass) return 3;
    
    /* compute worst edge length disparity */
	  edgelengthdisparitystats(mesh, &bestdisparity, &worstdisparity, &meandisparity, &mediandisparity, true);
    
    if (improvebehave->verbosity > 1)
    {
		printf("Worst edge length disparity: %g\n", worstdisparity);
		printf("Min allowable edge length disparity: %g\n",  improvebehave->minlengthratio);
    }
    
    /* while some tetrahedra have bad disparities, split or collapse their min/max edges */
    while (
		      (worstdisparity < improvebehave->minlengthratio) &&
              (numiters < MAXSIZEITERS)
          )
    {
        passstartid = lastjournalentry(); 
        
        /* build stacks of tets with bad disparities */
		    filldynsizestacks(mesh, &splitstack, &contractstack);
        
        /* Check how many are bad */
        totaltets = counttets(mesh);
		    percentbad = ((starreal) splitstack.top) / ((starreal) (totaltets));
        
        /* compute global worst quality in isotropic space */
        meshquality(mesh, means, &worstqual);
        meshquality_physical(mesh, means, &physworst);
        
        if (improvebehave->verbosity > 2)
        {
            printf("Before iteration %d\n", numiters);
            printf("    Worst disparity:          %g\n", worstdisparity);
            printf("    Best disparity:         %g\n", bestdisparity);
            printf("    Mean disparity:             %g\n", meandisparity);
						printf("    Median disparity:             %g\n", mediandisparity);
            printf("    Min allowable disparity:            %g\n", improvebehave->minlengthratio);
            printf("    %% Outside range:       %g\n", percentbad * 100.0);
            printf("    Worst qual (iso)       %g\n", worstqual);
            printf("    Worst qual (phys)      %g\n", physworst);
        }
        
        assert(worstqual > 0.0);
        assert(physworst > 0.0);
        
        /* Try edge contractions */
        sizecontract(mesh, &contractstack, false);
        
        if (improvebehave->verbosity > 0)
        {
            printf("Contract stack came back with %ld tets remaining\n", contractstack.top + 1 );
        }
        
        /* compute global worst quality in isotropic space */
        meshquality(mesh, means, &worstqual);
        meshquality_physical(mesh, means, &physworst);
      
        if (improvebehave->verbosity > 3) {
          printf("AFTER size contraction\n");
          printf("    Worst quality, isotropic = %g\n", worstqual);
          printf("    Worst quality, physical = %g\n", physworst);
        }
      
        assert(worstqual > 0.0);
        assert(physworst > 0.0);
        
        /* Try edge splits */
        sizesplit(mesh, &splitstack, false);
        
        if (improvebehave->verbosity > 2)
        {
            printf("Split stack came back with %ld tets remaining\n", splitstack.top + 1 );
        }
        
        /* compute global worst quality in isotropic space */
        meshquality(mesh, means, &worstqual);
        meshquality_physical(mesh, means, &physworst);
      
        if (improvebehave->verbosity > 3) {
          printf("AFTER size insertion\n");
          printf("    Worst quality, isotropic = %g\n", worstqual);
          printf("    Worst quality, physical = %g\n", physworst);
        }
      
        assert(worstqual > 0.0);
        assert(physworst > 0.0);
        
        /* Compute new disparity stats for next iteration */
				oldworst = worstdisparity;
        edgelengthdisparitystats(mesh, &bestdisparity, &worstdisparity, &meandisparity, &mediandisparity, true);
        
        numiters++;

		/* If we couldn't improve at all, then bail */
		if (oldworst == worstdisparity)
		{
			bailed = true;
			break;
		}
    }
    
    if (improvebehave->verbosity > 1)
    {
        if (numiters < MAXSIZEITERS && !bailed)
        {
            textcolor(BRIGHT, GREEN, BLACK);
            printf("Size control succeeded!\n");
            textcolor(RESET, WHITE, BLACK);
        }
        else
        {
            textcolor(BRIGHT, RED, BLACK);
            printf("Size control failed, %ld tets with too-bad edge length disparities.\n", splitstack.top+1);
            textcolor(RESET, WHITE, BLACK);
        }
    }
    
    if (improvebehave->verbosity > 3)
    {
		printf("Disparity statistics after size control:\n");
		printf("    Worst disparity:          %g\n", worstdisparity);
		printf("    Best disparity:         %g\n", bestdisparity);
		printf("    Mean disparity:             %g\n", meandisparity);
		printf("    Median disparity:             %g\n", mediandisparity);
		printf("    Min allowable disparity:            %g\n", improvebehave->minlengthratio);
    }
    
    /* clean up local stacks */
    stackdeinit(&splitstack);
    stackdeinit(&contractstack);
    
    journalmarker("Done dynamic sizing pass");
  
    return numiters+3;
}




starreal sizingtime;
/* split and collapse edges until all tetrahedra are roughly the same size */
int sizecontrol(struct tetcomplex *mesh,
                 struct behavior *behave,
                 struct inputs *in,
                 struct proxipool *vertexpool,
                 bool dynamic)
{
	starreal minedge = HUGEFLOAT;
	starreal maxedge = 0.0;
	starreal meanedge = 0.0;
	starreal medianedge = 0.0;
	starreal oldminedge, oldmaxedge;
	starreal shortestgoal, longestgoal;
	int numiters = 0;
	struct arraypoolstack longstack, oldlongstack;    /* stack of tets with edges too long */
	struct arraypoolstack shortstack, oldshortstack;   /* stack of tets with edges too short */
	struct arraypoolstack meshstack;    /* stack of all mesh tets */
	int totaltets = 0;
	starreal percentbad;
	starreal worstqual;
	starreal physworst;
	starreal means[NUMMEANTHRESHOLDS];
	
	starreal minqualbefore, minqualafter;
	starreal meanqualbefore[NUMMEANTHRESHOLDS], meanqualafter[NUMMEANTHRESHOLDS];
	starreal bestmeans[NUMMEANTHRESHOLDS];
	int smoothkinds = 0;
  
  int improvedshorts, improvedlongs;
	
	int passstartid;
	int beforeid;
	
	timerstart();
  
	if (improvebehave->facetsmooth) smoothkinds |= SMOOTHFACETVERTICES;
	if (improvebehave->segmentsmooth) smoothkinds |= SMOOTHSEGMENTVERTICES;
	if (improvebehave->cornersmooth) smoothkinds |= SMOOTHCORNERVERTICES;
	
	stackinit(&longstack, sizeof(struct improvetet));
	stackinit(&shortstack, sizeof(struct improvetet));
	stackinit(&oldlongstack, sizeof(struct improvetet));
	stackinit(&oldshortstack, sizeof(struct improvetet));
	stackinit(&meshstack, sizeof(struct improvetet));
	
	if (improvebehave->verbosity > 0)
	{
		printf("Starting size control...\n");
	}
  
	journalmarker("Start size control pass");
		
	/* if the ideal edge length is set to zero, assign to it the value of the mean edge length */
	if (improvebehave->targetedgelength == 0.0)
	{
		/* compute physical edge length */
		edgelengthstats(mesh, &minedge, &maxedge, &meanedge, &medianedge, false);
		
		if (improvebehave->verbosity > 0)
			printf("Setting target edge length to physical median of %g\n", medianedge);

		if (improvebehave->verbosity > 1)
		{
			printf("PHYSICAL SPACE Edge length statistics:\n");
			printf("    Max edge length: %g\n", maxedge);
			printf("    Min edge length: %g\n", minedge);
			printf("    Mean edge length: %g\n", meanedge);
			printf("    Median edge length: %g\n", medianedge);
		}
		
		improvebehave->targetedgelength = medianedge;
	} 
	
	/* stop here unless explicit sizing pass is enabled */
	if (!improvebehave->sizingpass) 
		return 3;
	
	/* compute anisotropic edge length */
	edgelengthstats(mesh, &minedge, &maxedge, &meanedge, &medianedge, true);
	
	longestgoal = improvebehave->targetedgelength * improvebehave->longerfactor;
	shortestgoal = improvebehave->targetedgelength * improvebehave->shorterfactor;
	
	if (improvebehave->verbosity > 1)
	{
		printf("Edge length statistics:\n");
		printf("    Max edge length: %g\n", maxedge);
		printf("    Min edge length: %g\n", minedge);
		printf("    Mean edge length: %g\n", meanedge);
		printf("    Median edge length: %g\n", medianedge);
		
		printf("Ideal edge length: %g\n", improvebehave->targetedgelength);
		printf("Longest allowable edge length: %g\n", longestgoal);
		printf("Shortest allowable edge length: %g\n", shortestgoal);
	}
	
	/* some edges might be repairable without a lot of fuss. Try that first. */
	{
    /* build stacks of tets with some edge too long or too short */
    filledgestacks(mesh, &longstack, &shortstack,
                   shortestgoal * CONTROLSHORTFAC,
                   longestgoal * CONTROLLONGFAC,
                   &minedge, &maxedge, &meanedge);
    
    if (improvebehave->verbosity > 0)
      printf("initial too short/long edges %ld/%ld\n", shortstack.top+1, longstack.top+1);
                    
    sizecontract(mesh, &shortstack, true);
    sizesplit(mesh, &longstack, true);	

    filledgestacks(mesh, &longstack, &shortstack,
                   shortestgoal * CONTROLSHORTFAC,
                   longestgoal * CONTROLLONGFAC,
                   &minedge, &maxedge, &meanedge);
	}
	
	/* while some tetrahedra have edges that are too long or short, split or collapse them */
	while (((minedge < shortestgoal) || (maxedge > longestgoal)) && (numiters < MAXSIZEITERS))
	{
		passstartid = lastjournalentry(); 
		
		/* build stacks of tets with some edge too long or too short */
		filledgestacks(mesh, &longstack, &shortstack,
									 shortestgoal * CONTROLSHORTFAC,
									 longestgoal * CONTROLLONGFAC,
									 &minedge, &maxedge, &meanedge);
				 
		if (improvebehave->verbosity > 0) {
			printf("sizing pass %d initial too short/long edges %ld/%ld\n", numiters, shortstack.top+1, longstack.top+1);
		}
			
		/* if there aren't too many outside the bounds, bail */
		totaltets = counttets(mesh);
		percentbad = ((starreal) (longstack.top + shortstack.top)) / ((starreal) (totaltets));
		
		/* compute global worst quality in isotropic space */
		meshquality(mesh, means, &minqualbefore);
    meshquality_physical(mesh, means, &physworst);
		
		if (improvebehave->verbosity > 2)
		{
			printf("Before iteration %d\n", numiters);
			printf("    Longest edge:          %g\n", maxedge);
			printf("    Longest desired edge:  %g\n", longestgoal);
			printf("    Shortest edge:         %g\n", minedge);
			printf("    Shortest desired edge: %g\n", shortestgoal);
			printf("    Mean edge:             %g\n", meanedge);
			printf("    Ideal edge:            %g\n", improvebehave->targetedgelength);
			printf("    %% Outside range:       %g\n", percentbad * 100.0);
			printf("    Worst qual (iso)       %g\n", worstqual);
			printf("    Worst qual (phys)      %g\n", physworst);
		}
		
		assert(minqualbefore > 0.0);
		assert(physworst > 0.0);
		
		if (!dynamic)
		{
			/* stop if most are in range? */
			if (percentbad < 0.2)
			{
				if (improvebehave->verbosity > 0)
					printf("quitting sizing, only %g%% of edges are bad.", 100*percentbad);
				break;
			}
		}
		
		/* contract too-short edges */
    
    /* save edge length situation before pass */
    copystack(&shortstack, &oldshortstack);
    beforeid = lastjournalentry();
		
    sizecontract(mesh, &shortstack, false);
		
		if (improvebehave->verbosity > 1)
		{
			printf("after contraction: short stack came back with %ld tets remaining\n", shortstack.top + 1);
		}
		
		/* compute global worst quality in isotropic space */
		meshquality(mesh, means, &worstqual);
    meshquality(mesh, means, &physworst);
		
		if (improvebehave->verbosity > 1) {
			printf("AFTER size contraction\n");
			printf("    Worst quality, isotropic = %g\n", worstqual);
			printf("    Worst quality, physical = %g\n", physworst);
		}
		assert(worstqual > 0.0);
		assert(physworst > 0.0);
		
		
		if (dynamic)
		{
			struct arraypoolstack longstack_tmp;
			struct arraypoolstack shortstack_tmp;
			starreal minedge_tmp, maxedge_tmp, meanedge_tmp;
			starreal oldminedge_tmp = minedge;
			
      stackinit(&longstack_tmp, sizeof(struct improvetet));
      stackinit(&shortstack_tmp, sizeof(struct improvetet));
      
      filledgestacks(mesh, &longstack_tmp, &shortstack_tmp,
                     shortestgoal * CONTROLSHORTFAC,
                     longestgoal * CONTROLLONGFAC,
                     &minedge_tmp, &maxedge_tmp, &meanedge_tmp);
			
			if (improvebehave->verbosity > 2)
			{
				printf("old min edge: %g\n", oldminedge_tmp);
				printf("new min edge: %g\n", minedge_tmp);
			}
			
      /* check if we improved the sizing situation */
      improvedshorts = lexicographicorder(&oldshortstack, &shortstack_tmp) <= 0;
      
			/* If it decreased the # of too-short edges but made quality below threshold, try a topo pass */
			if (worstqual < improvebehave->goalquality && improvedshorts)
			{
				starreal bestmeans_tmp[NUMMEANTHRESHOLDS];
				starreal meanqualafter_tmp[NUMMEANTHRESHOLDS];
				starreal minqualbefore_tmp;
				starreal minqualafter_tmp;
        starreal worstqual_tmp;

				/* create a stack with every tet */
				fillstackqual(mesh, &meshstack, HUGEFLOAT, meanqualbefore, &minqualbefore_tmp);
				
				if (improvebehave->verbosity > 0)
					printf("quality isn't great at %g, running topo pass.\n", worstqual);
				
				/* perform topological improvement pass */
				topopass(mesh, 
                 &meshstack, NULL, 
                 bestmeans_tmp, 
                 meanqualafter_tmp, 
                 &minqualafter_tmp, 
                 false);
				
				/* compute global worst quality in isotropic space */
				meshquality(mesh, means, &worstqual_tmp);
				
				/* if quality decreased and below threshold, discard these changes. */
				if (worstqual_tmp < improvebehave->goalquality && 
						worstqual_tmp < minqualbefore) {
					if (improvebehave->verbosity > 0)
						printf("quality still %g (%g before), undoing contraction pass\n", worstqual_tmp, minqualbefore);
					invertjournalupto(mesh, beforeid);
					worstqual = minqualbefore;
				} else {
					worstqual = worstqual_tmp;
					if (improvebehave->verbosity > 0)
						printf("after successful contraction pass: quality %g (%g before).\n", worstqual_tmp, minqualbefore);					
				}
			}			
			else if (worstqual < minqualbefore && worstqual < improvebehave->goalquality) {
				/* If quality dropped with no improvement in # too-short edges, revert */
				invertjournalupto(mesh, beforeid);
				worstqual = minqualbefore;
				if (improvebehave->verbosity > 0)
					printf("still %ld tets (%ld before), quality %g -> %g, undoing.\n", shortstack_tmp.top+1, oldshortstack.top+1, minqualbefore, worstqual);
			} else {
        /* quality didn't worsen or is above threshold */
				if (improvebehave->verbosity > 0)
					printf("after contraction pass: quality %g (%g before), %ld edges left.\n", worstqual, minqualbefore, shortstack_tmp.top+1);					
			}
		}
		
		minqualbefore = worstqual;
		
		/* split too-long edges */
    /* state state before pass (TODO: we should recompute longstack to get long edges close to changed tets) */
		beforeid = lastjournalentry();
    copystack(&longstack, &oldlongstack);
    
		sizesplit(mesh, &longstack, false);
		
		if (improvebehave->verbosity > 1)
		{
			printf("after splitting: long stack came back with %ld tets remaining\n", longstack.top + 1);
		}
		
		/* compute global worst quality in isotropic space */
		meshquality(mesh, means, &worstqual);
                meshquality_physical(mesh, means, &physworst);
		
		if (improvebehave->verbosity > 1) {
			printf("AFTER size insertion\n");
			printf("    Worst quality, isotropic = %g\n", worstqual);
			printf("    Worst quality, physical = %g\n", physworst);
		}
		
		assert(worstqual > 0.0);
		assert(physworst > 0.0);
		
		if (dynamic)
		{
			struct arraypoolstack longstack_tmp;
			struct arraypoolstack shortstack_tmp;
			starreal minedge_tmp, maxedge_tmp, meanedge_tmp;
			starreal oldmaxedge_tmp = maxedge;
			
      stackinit(&longstack_tmp, sizeof(struct improvetet));
      stackinit(&shortstack_tmp, sizeof(struct improvetet));
      
      filledgestacks(mesh, &longstack_tmp, &shortstack_tmp,
                     shortestgoal * CONTROLSHORTFAC,
                     longestgoal * CONTROLLONGFAC,
                     &minedge_tmp, &maxedge_tmp, &meanedge_tmp);
			
			if (improvebehave->verbosity > 2) {
				printf("old max edge: %g\n", oldmaxedge_tmp);
				printf("new max edge: %g\n", maxedge_tmp);
			}
      
      /* check if we improved the long edges */
			improvedlongs = lexicographicorder(&oldlongstack, &longstack_tmp) >= 0;
      
			/* If it decreased the # of too-long edges but made quality below threshold, try a topo pass */
			if (worstqual < improvebehave->goalquality && improvedlongs)
			{				
				starreal bestmeans_tmp[7];
				starreal meanqualafter_tmp[7];
				starreal minqualafter_tmp;
				starreal minqualbefore_tmp;
        starreal worstqual_tmp;

        if (improvebehave->verbosity > 0)
          printf("quality isn't great at %g, running topo pass.\n", worstqual);

        /* create a stack with every tet */
				fillstackqual(mesh, &meshstack, HUGEFLOAT, meanqualbefore, &minqualbefore_tmp);
				
				/* perform topological improvement pass */
				topopass(mesh, 
                 &meshstack, NULL, 
                 bestmeans_tmp, 
                 meanqualafter_tmp, 
                 &minqualafter_tmp, 
                 false);
				
				/* compute global worst quality in isotropic space */
				meshquality(mesh, means, &worstqual_tmp);
				
				/* if quality decreased and below threshold, discard these changes. */
				if (worstqual_tmp < improvebehave->goalquality && worstqual_tmp < minqualbefore) {
					if (improvebehave->verbosity > 0)
						printf("quality still %g (%g before), undoing splitting pass\n", worstqual_tmp, minqualbefore);
					invertjournalupto(mesh, beforeid);
					worstqual = minqualbefore;
				} else {
					worstqual = worstqual_tmp;
					if (improvebehave->verbosity > 0)
						printf("after successful splitting pass: quality %g (%g before)\n", worstqual_tmp, minqualbefore);					
				}
			}			
			else if (worstqual < minqualbefore && worstqual < improvebehave->goalquality) {
				/* If quality dropped below threshold with no improvement in # too-long edges, revert */
				invertjournalupto(mesh, beforeid);
				worstqual = minqualbefore;
				if (improvebehave->verbosity > 0)
					printf("after splitting: still %ld edges (%ld before), quality %g -> %g, undoing.\n", longstack_tmp.top+1, oldlongstack.top+1, minqualbefore, worstqual);
			} else {
        /* all good */
				if (improvebehave->verbosity > 0)
					printf("after splitting: quality %g (%g before), %ld edges left.\n", worstqual, minqualbefore, longstack_tmp.top+1);					
			}
		}
		
		oldminedge = minedge;
		oldmaxedge = maxedge;
		/* compute the same for edge length */
		edgelengthstats(mesh, &minedge, &maxedge, &meanedge, &medianedge, true);
		
		if (!dynamic)
		{
			/* if there has been no reduction in extreme edge length, try a smooth + topo */
			if ((minedge <= oldminedge && maxedge >= oldmaxedge) || 1)
			{
				if (improvebehave->verbosity > 0)
				{
					printf("Performing global smoothing pass...\n");
				}
				
				/* create a stack with every tet */
				fillstackqual(mesh, &meshstack, HUGEFLOAT, meanqualbefore, &minqualbefore);
				
				/* perform optimization smoothing pass */
				smoothpass(mesh, 
                   &meshstack, 
                   NULL, NULL, 
                   HUGEFLOAT, 
                   bestmeans, 
                   meanqualafter, 
                   &minqualafter, 
                   smoothkinds, 
                   false);
				
				/* create a stack with every tet */
				fillstackqual(mesh, &meshstack, HUGEFLOAT, meanqualbefore, &minqualbefore);
				
				/* perform topological improvement pass */
				topopass(mesh, 
                 &meshstack, NULL, 
                 bestmeans, 
                 meanqualafter, 
                 &minqualafter, 
                 false);
			}
		}
		
		/* finish early if we didn't do anything this pass */
		if (passstartid == lastjournalentry()) {
			if (improvebehave->verbosity > 0) {
				printf("Aborting size control because a pass did nothing.\n");
			}
			numiters = MAXSIZEITERS;
		}
		
		numiters++;
	}
	
	if (improvebehave->verbosity > 0)
	{
		filledgestacks(mesh, &longstack, &shortstack,
                   shortestgoal,
                   longestgoal,
                   &minedge, &maxedge, &meanedge);

		if (numiters < MAXSIZEITERS)
		{
			textcolor(BRIGHT, GREEN, BLACK);
			printf("Size control succeeded, %ld edges too long, %ld edges too short.\n", longstack.top+1, shortstack.top+1);
			textcolor(RESET, WHITE, BLACK);
		}
		else
		{			
			textcolor(BRIGHT, RED, BLACK);
			printf("Size control failed, %ld edges too long, %ld edges too short.\n", longstack.top+1, shortstack.top+1);
			textcolor(RESET, WHITE, BLACK);
		}
	}
	
	if (improvebehave->verbosity > 2)
	{
    /* compute the same for edge length */
    edgelengthstats(mesh, &minedge, &maxedge, &meanedge, &medianedge, true);
    
		printf("Edge length statistics after size control:\n");
		printf("    Longest edge:          %g\n", maxedge);
		printf("    Longest desired edge:  %g\n", longestgoal);
		printf("    Shortest edge:         %g\n", minedge);
		printf("    Shortest desired edge: %g\n", shortestgoal);
		printf("    Mean edge:             %g\n", meanedge);
		printf("    Median edge:           %g\n", medianedge);
		printf("    Ideal edge:            %g\n", improvebehave->targetedgelength);
	}
	
	/* clean up local stacks */
	stackdeinit(&longstack);
	stackdeinit(&shortstack);
	stackdeinit(&meshstack);
	
	/* starexit(1); */
	
	journalmarker("Done size control pass");
	
	sizingtime = timerstop();
  
	return numiters+3;
}

void sizereportstream(FILE *o, struct tetcomplex *mesh)
{
  starreal minedge, maxedge, meanedge, medianedge;
  
  edgelengthstats(mesh, &minedge, &maxedge, &meanedge, &medianedge, true);
  
  fprintf(o, "Edge length statistics:\n");
  fprintf(o, "    Longest edge:          %g\n", maxedge);
  fprintf(o, "    Longest desired edge:  %g\n", improvebehave->targetedgelength * improvebehave->longerfactor);
  fprintf(o, "    Shortest edge:         %g\n", minedge);
  fprintf(o, "    Shortest desired edge: %g\n", improvebehave->targetedgelength * improvebehave->shorterfactor);
  fprintf(o, "    Mean edge:             %g\n", meanedge);
  fprintf(o, "    Median edge:           %g\n", medianedge);
  fprintf(o, "    Ideal edge:            %g\n", improvebehave->targetedgelength);
}

/* print a report on edge lengths in the mesh */
void sizereport(struct tetcomplex *mesh)
{
  sizereportstream(stdout, mesh);
}

