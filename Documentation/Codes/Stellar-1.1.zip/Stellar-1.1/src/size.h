#pragma once

#include "structs.h"

/* attempt to collapse edges that are too short */
void sizecontract(struct tetcomplex *mesh,
                  struct arraypoolstack *tetstack, 
                  bool requireminqual);

/* attempt to split edges that are too long */
void sizesplit(struct tetcomplex *mesh,
               struct arraypoolstack *tetstack,
               bool requireminqual);

/* split and collapse edges until all tetrahedra have good edge length disparities */
int dynsizecontrol(struct tetcomplex *mesh,
                   struct behavior *behave,
                   struct inputs *in,
                   struct proxipool *vertexpool);

/* split and collapse edges until all tetrahedra are roughly the same size */
int sizecontrol(struct tetcomplex *mesh,
                struct behavior *behave,
                struct inputs *in,
                struct proxipool *vertexpool,
                bool dynamic);

/* split and collapse edges until all tetrahedra have good edge length disparities */
int dynsizecontrol(struct tetcomplex *mesh,
                   struct behavior *behave,
                   struct inputs *in,
                   struct proxipool *vertexpool);


/* print a report on edge lengths in the mesh */
void sizereportstream(FILE *o, struct tetcomplex *mesh);
void sizereport(struct tetcomplex *mesh);
