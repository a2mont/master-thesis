/*****************************************************************************/
/*                                                                           */
/*  smoothing functions                                                      */
/*                                                                           */
/*****************************************************************************/

#include "smoothing.h"
#include "vector.h"
#include "print.h"
#include "anisotropy.h"
#include "util.h"
#include "quality.h"
#include "quadric.h"
#include "classify.h"
#include "journal.h"
#include "arraypoolstack.h"

void getoptinfo(struct tetcomplex *mesh, struct opttet *opttet) {
  starreal point[4][3];
  struct vertextype *vinfo;
  int i;
  
  tensortransformtet(mesh, opttet->verts[0], opttet->verts[1], opttet->verts[2], opttet->verts[3], point);
    
  if (improvebehave->verbosity > 6)
  {
    printf("computing opt info for the following tet:\n");
    printtetverts(mesh, opttet->verts);
    printf("\n");
  }
  
  /* fill in opttet fields */
  improvebehave->optinfo_cb((const starreal (*)[3]) point, opttet);
  
  /* take care to project gradients if the optimized vertex is not actually free */

  vinfo = get_info(opttet->verts[0]);
    
  if (vinfo->kind == FACETVERTEX) {
    for (i = 0; i < opttet->numqualities; ++i) {
      vprojecttoplane(opttet->qualitygrad[i], vinfo->vec, opttet->qualitygrad[i]);
    }
  }
  
  if (vinfo->kind == SEGMENTVERTEX) {
    for (i = 0; i < opttet->numqualities; ++i) {
      vproject(opttet->qualitygrad[i], vinfo->vec, opttet->qualitygrad[i]);
    }
  }  
}


/* run through a stack of tets, initializing each vertex with
 a flag indicating that it has not yet been smoothed */
void initsmoothedvertlist(struct arraypoolstack *tetstack,
                          struct arraypool *vertlist)
{
  int i,j;                  /* loop index */
  struct improvetet *tet;   /* current tet */
  
  if (improvebehave->verbosity > 5)
  {
    printf("Initializing %lu tets of vertices to not smoothed... ", tetstack->top);
  }
  
  /* for every vertex in the stack */
  for (i=0; i<=tetstack->top; i++)
  {
    /* fetch this item from the stack */
    tet = (struct improvetet *) arraypoolfastlookup(&(tetstack->pool), (unsigned long) i);
    /* for each vertex */
    for (j = 0; j<4; j++)
    {
      /* initialize this vertex to not smoothed */
      *((bool *) arraypoolforcelookup(vertlist, tet->verts[j])) = false;
    }
  }
  
  if (improvebehave->verbosity > 5)
  {
    printf("done.\n");
  }
}


/* returns the basis B of S union M. S is a set of points known
   to be in the basis */
void findbasis(starreal S[][3],
               starreal M[][3],
               starreal B[][3],
               int sizeS,
               int sizeM,
               int *sizeB)
{
    starreal p[3],q[3],r[3],s[3];        /* vertices */
    starreal s1[3], t1[3], d1[3], d2[3]; /* temporary vertices */
    starreal origin[3] = {0.0, 0.0, 0.0};
    starreal localS[4][3];               /* for passing to recursive calls */
    starreal localM[MAXINCIDENTTETS][3]; /* for passing to recursive colls */
    
    assert(sizeM > 0);
    
    if (improvebehave->verbosity > 5) printbasisarrays(S,M,B,sizeS,sizeM,sizeB,p);
    
    /* we assume that M was passed to us shuffled, so that taking
       the last element is equivalent to removing a random one. */
    vcopy(M[sizeM-1],p);
    
    /* if M has only one element */
    if (sizeM == 1)
    {
        /* and S has no elements */
        if (sizeS == 0)
        {
            if (improvebehave->verbosity > 5) printf("M has one element, and S is empty. Copying M to B and sending it back...\n");
            
            /* then the single element in M must be the
               entire basis, just send back M */
            pointarraycopy(M, B, 1);
            *sizeB = 1;
            return;
        }
        
        if (improvebehave->verbosity > 5) printf("M has one element p. Assume it's not in basis and set B = S...\n");
        
        /* otherwise, because we assume the last element
           we just removed is not part of the basis, assign
           the basis to be the elements of S */
        pointarraycopy(S, B, sizeS);
        *sizeB = sizeS;
    }
    /* M has more than one element. Throw one out (p), and look for the
       basis assuming p is not part of it. */
    else
    {
        if (improvebehave->verbosity > 5) printf("M has more than one element, tossing one out and recursing...\n");
        
        /* make a new copy of M minus the last element */
        pointarraycopy(M, localM, sizeM-1);
        pointarraycopy(S, localS, sizeS);
        findbasis(localS, localM, B, sizeS, sizeM-1, sizeB);
    }
    
    /* now the we have determined the basis without p, we need to 
       go back and check whether p actually is part of the basis. */
    
    switch (*sizeB)
    {
        /* if the returned basis has just one point q, we just need to check
           whether p is closer to the origin than q */
        case 1:
            /* fetch the actual coordinates from the mesh */
            vcopy(B[0],q);
        
            /* compute the vector from q to p */
            vsub(p, q, d1);
            
            /* check the sign of the dot product. >=0 means p doesn't
               improve the basis */
            if (dot(q,d1) >= 0)
            {
                /* this is a good B, send it back!*/
                return;
            }
            break;
            
        /* check whether p improves the basis using math I don't understand */        
        case 2:
            /* fetch coordinates from the mesh */
            vcopy(B[0],q);
            vcopy(B[1],r);
            
            /* compute vector s from r to p */
            vsub(p, r, s1);
            /* compute vector t from r to q */
            vsub(q, r, t1);
            
            /* now a couple of cross products */
            cross(s1, t1, d1);
            cross(r, t1, d2);
            
            /* can p improve the basis? */
            if (dot(d1,d2) >= 0)
            {
                /* nope! send back B as is. */
                return;
            }            
            break;
        case 3:
            /* fetch coordinates from the mesh */
            vcopy(B[0],q);
            vcopy(B[1],r);
            vcopy(B[2],s);
            
            /* does p improve the basis? */
            if (orient3d(&improvebehave->behave, p, q, r, s) * orient3d(&improvebehave->behave, origin, q, r, s) <= 0)
            {
                /* nope! send back B as is. */
                return;
            }
            break;
        default:
            /* B has size of 4, and any basis of this size is optimal */
            return;
            break;
    }
    
    /* if we have made it this far, we know that p actually is a part of
       any basis of S union M */
       
    /* if p was the last element of M, or if S already has three other basis
       points, we're done and just need to send back S union p. */
    if ((sizeM == 1) || (sizeS == 3))
    {
        if (improvebehave->verbosity > 5) printf("p in basis and it's the last possible point, return S U p\n");
        /* the final size of B is the size of S + 1 */
        *sizeB = sizeS + 1;
        /* copy S into B */
        pointarraycopy(S, B, sizeS);
        /* and add p at the end */
        vcopy(p, B[*sizeB - 1]);
        
        return;
    }
    /* there may be more basis points to find! move p from M to the known
       basis point set S, and go again */
    else
    {
        if (improvebehave->verbosity > 5)
        {
            printf("p in basis, more points to check. Moving p from M to S\n");
            printf("here's how everything looked before the move:\n");
            printbasisarrays(S,M,B,sizeS,sizeM,sizeB,p);
        } 
        
        /* create the new S */
        pointarraycopy(S, localS, sizeS);
        /* add p to the end of it */
        vcopy(p, localS[sizeS]);
        
        /* create the new M, leaving off the last element */
        pointarraycopy(M, localM, sizeM-1);
        
        /* find any basis points remaining in M */
        findbasis(localS, localM, B, sizeS+1, sizeM-1, sizeB);
        
        return;
    }        
}

/* finds the point on the convex hull of P nearest
   the origin */
void minconvexhullpoint(starreal P[][3],
                        int sizeP,
                        starreal nearest[])
{
    starreal B[4][3];                /* the basis for the convex hull point */
    int sizeB=0;                   /* size of the basis */
    starreal empty[4][3];            /* empty set for known basis */
    starreal *p, *q, *r;             /* basis points */
    starreal pmq[3];                 /* p minus q */
    starreal c, d, l;                /* scalar factors */
    starreal s[3], t[3], s2[3], t2[3];/* temporary points */
    starreal sxt[3], sxr[3], rxt[3], temp[3]; /* temporary cross products */
    int i;
    
    assert(sizeP > 0);
    
    /* find a basis for the minimum point on the convex hull */
    findbasis(empty, P, B, 0, sizeP, &sizeB);
    
    if (improvebehave->verbosity > 5)
    {
        printf("\nbasis size is %d\n", sizeB);
        printf("here are the basis points:\nbasis=[");
        for (i=0; i<sizeB; i++)
        {
            printf("%.17g %.17g %.17g;\n",B[i][0],B[i][1],B[i][2]);
        }
        printf("]\n");
        
    }
    
    switch(sizeB)
    {
        /* if the basis is just a single point, return that point */
        case 1:
            vcopy(B[0], nearest);
            return;
            break;
        /* for two points, find the closest point to the origin on
           the line between the two points */
        case 2:
            p = B[0];
            q = B[1];
            vsub(p,q,pmq);
            
            /*
              nearest = q - dot(q,p-q)/(length(p-q)^2) * (p-q)
            */
            l = vlength(pmq);
            
            /* if these points are the same, just return one of them */
            if (l == 0.0)
            {
                vcopy(B[0], nearest);
                return;
            }
            
            c = dot(q,pmq) / (l * l);
            vscale(c,pmq,nearest);
            vsub(q,nearest,nearest);
            
            return; 
            break;
        /* for three points, find the point closest to the origin
           on the triangle that the they form */
        case 3:
            p = B[0];
            q = B[1];
            r = B[2];
            
            vsub(p,r,s);
            vsub(q,r,t);
            
            cross(s,t,sxt);
            cross(r,t,rxt);
            cross(s,r,sxr);
            
            /* if any of these cross products is really tiny, give up
               and return the origin */
            if (vlength(sxt) < NEARESTMIN || vlength(rxt) < NEARESTMIN || vlength(sxr) < NEARESTMIN)
            {
                if (improvebehave->verbosity > 5)
                {
                    printf("Encountered tiny factor (< %g) in nearest point computation, returning origin.\n", NEARESTMIN);
                    printf("sxt= %.17g %.17g %.17g\n", sxt[0], sxt[1], sxt[2]);
                    printf("rxt= %.17g %.17g %.17g\n", rxt[0], rxt[1], rxt[2]);
                    printf("sxr= %.17g %.17g %.17g\n", sxr[0], sxr[1], sxr[2]);
                }
                nearest[0] = 0.0;
                nearest[1] = 0.0;
                nearest[2] = 0.0;
                return;
            }
            
            c = dot(sxt,rxt) / dot(sxt,sxt);
            d = dot(sxt,sxr) / dot(sxt,sxt);
            
            vscale(c,s,s2);
            vscale(d,t,t2);
            
            vsub(r,s2,temp);
            vsub(temp,t2,nearest);
            
            return;
            break;
        /* if the basis has four points, they must enclose the origin
           so just return the origin. */
        case 4:
            nearest[0] = 0.0;
            nearest[1] = 0.0;
            nearest[2] = 0.0;
            return;
            break;
        default:
            printf("Error, basis size %d is bogus, dying\n",sizeB);
            starexit(1);
            break;
    }
}



/* find the best step to take to improve all of the quality
   functions affected by a vertex vtx in the search direction
   d with an expected rate of improvement r */
void nonsmoothlinesearch(struct tetcomplex *mesh,
                         tag vtx,
                         starreal d[],
                         starreal inworstqual,
                         starreal *alpha,
                         starreal r,
                         struct opttet incidenttets[],
                         int numincident,
                         int vtxkind,
                         starreal vtxvec[3])
{
    int numiter = 0;      /* number of iterations */
    starreal *v;            /* the vertex to be modified */
    starreal origvertex[3]; /* to save the original vertex position */
    starreal offset[3];     /* the offset to move the vertex, alpha * d */
    starreal worstqual;     /* the current worst quality */
    starreal origworstqual; /* the original worst quality */
    starreal thisqual;    /* the quality of the current tet */
    starreal oldworstqual;  /* the worst quality at the last step */
    int i;                /* loop index */
    
    /* save the original worst quality */
    origworstqual = oldworstqual = inworstqual;
    
    /* fetch the original vertex coordinates from the mesh */
    v = ((struct vertex *) tetcomplextag2vertex(mesh, vtx))->coord;
    vcopy(v, origvertex);
    
    /* keep trying until alpha gets too small or we exceed maximum
       number of iterations */
    while ((*alpha > MINSTEPSIZE) && (numiter < MAXLINEITER))
    {
        if (improvebehave->verbosity > 5) printf("In line search, alpha=%g numiter=%d\n",*alpha,numiter);
        
        /* compute the offset from original vertex positon,
           alpha * d */
        vscale(*alpha, d, offset);
        /* move the vertex */
        vadd(v, offset, v);
        
        /* recompute all of the quality functions affected
           by v's position, taking note of the smallest one */
        worstqual = HUGEFLOAT; 
        for (i=0; i<numincident; i++)
        {
            thisqual = tetquality(mesh,
                                  incidenttets[i].verts[0],
                                  incidenttets[i].verts[1],
                                  incidenttets[i].verts[2],
                                  incidenttets[i].verts[3]);
        
            if (improvebehave->verbosity > 5 && thisqual < 0.0)
            {
                printf("in line search, after taking step we have negative quality = %g\n", thisqual);
            }
            
            /* is this the worst quality we've seen? */
            if (thisqual < worstqual) worstqual = thisqual;
        }
        
        /* if we're using surface quadrics */
        if (improvebehave->usequadrics && hasquadric(vtx) && get_info(vtx)->kind == CORNERVERTEX)
        /* if (improvebehave->usequadrics && hasquadric(vtx) && ((struct vertextype *) arraypoolforcelookup(&vertexinfo, vtx))->kind != FREEVERTEX) */
        {
            /* check whether the surface quadric is the worse than all the tets */
            starreal qe = quadricerrortet(mesh, vtx);
            if (qe < worstqual) 
            {
                if (improvebehave->verbosity > 5)
                {
                    printf("In line search, vertex %d's quadric error (%g raw, %g normalized) is worse than any tet quality!\n", (int) vtx, quadricerror(mesh, vtx), qe);
                }
                worstqual = qe;
            }
        }
        
        
        if (improvebehave->verbosity > 5) printf("The old worst was %g, the new worst is %g, diff is %g\n",oldworstqual,worstqual,worstqual-oldworstqual);
            
            /* if this is not the first iteration, and
           we did better on the last iteration, use
           the step size from the previous iteration */
        if ((oldworstqual > origworstqual) && (oldworstqual > worstqual))
        {
            if (improvebehave->verbosity > 5) printf("last step did better than current alpha, return it.\n");
            
            /* use the previous step's alpha */
            *alpha = (*alpha) * 2;
            assert(*alpha > 0.0);
            
            /* put vertex back where it started */
            vcopy(origvertex, v);
            
            return;
        }
        
        /* if we have succeeded in gaining 90% of the expected
           improvement, accept this initial step size */
        if ((worstqual - origworstqual) > (0.9 * (*alpha) * r))
        {
            if (improvebehave->verbosity > 5) printf("diff between origworstqual=%g and curworstqual=%g is >90%% expected improvement %g.\nthis step is a success, return alpha=%g\n",origworstqual,worstqual,*alpha * r * 0.9, *alpha);
            
            /* put vertex back where it started */
            vcopy(origvertex, v);
            
            return;
        }
        
        if (improvebehave->verbosity > 5) printf("this alpha isn't working, going to half it...\n");
        
        /* put vertex back where it started */
        vcopy(origvertex, v);
        
        /* cut alpha down by half and try again */
        *alpha = (*alpha) / 2.0;
        
        /* save the worst quality from this step */
        oldworstqual = worstqual;
    }
    
    if (improvebehave->verbosity > 5)
    {
        printf("whoa, failed to find an appropriate alpha! numiter = %d, alpha = %g\n", numiter, *alpha);
    }
    
    /* no positive alpha could be found that improved things... give up and return zero */
    *alpha = 0.0;
}



/* given a set of tets incident to a vertex, and the quality
   of the worst quality function that varies with that vertex,
   compute the active set A of quality functions very near
   the worst */
void getactiveset(struct tetcomplex *mesh,
                  struct opttet incidenttets[],
                  int numincident,
                  starreal activegrads[][3],
                  int *numactive,
                  starreal worstqual)
{
    int i,j;
    tag vtx = incidenttets[0].verts[0];
    
    /* reset number of active gradients to zero */
    *numactive = 0;
	
    if (improvebehave->verbosity > 5)
    {
        printf("worstqual is %g\n", worstqual);
    }
    
    /* if we are including surface quadrics, give them a chance to
       enter the active set */
    assert(numincident > 0);
    /* if (improvebehave->usequadrics && hasquadric(vtx) && ((struct vertextype *) arraypoolforcelookup(&vertexinfo, vtx))->kind != FREEVERTEX) */
    if (improvebehave->usequadrics && hasquadric(vtx) && get_info(vtx)->kind == CORNERVERTEX)
    {
        /* if the quadric is close enough to worst, add it to the active set */
        if (quadricerrortet(mesh, vtx) <= (worstqual * ACTIVESETFACTOR))
        {
            /* fetch the gradient of this quadric */
            starreal quadgrad[3];
            quadricgradtet(mesh, vtx, quadgrad);
            
            if (improvebehave->verbosity > 5)
            {
                printf("Vertex %d's quadric error (%g raw, %g normalized, gradient = [%g %g %g]) is in the active set (worstqual = %g)!\n", 
											 (int) vtx, quadricerror(mesh, vtx), quadricerrortet(mesh, vtx), quadgrad[0], quadgrad[1], quadgrad[2], worstqual);
            }
            
            /* copy the gradient into the list of active gradients */
            vcopy(quadgrad, activegrads[*numactive]);
            (*numactive)++;
        }
    }
    
    for (i=0; i<numincident; i++)
    {
      for (j=0; j<incidenttets[i].numqualities; j++)
      {
        /* is this close enough to the worst? */
        if (incidenttets[i].quality[j] < (worstqual * ACTIVESETFACTOR))
        {
          /* get the actual gradient value */
          vcopy(incidenttets[i].qualitygrad[j], activegrads[*numactive]);          
          (*numactive)++;
        }
      }      
    }
    
    if (*numactive == 0)
    {
        printf("didn't find any active quality functions.");
        for (i=0; i<numincident; i++)
        {
            printopttet(&incidenttets[i]);
        }
    }
    
    /* we must have at least found the worst */
    /* assert(*numactive > 0); */
}

/* for our initial step size, we use the distance
   to the next intersection with another quality funtion.
   this is the point at which the other quality function
   becomes the worst. we use a single-term taylor expansion
   to approximate all of the quality functions as lines,
   so we'll have to do a line search to find our ultimate
   step size. */
starreal getinitialalpha(struct tetcomplex *mesh,
                         struct opttet incidenttets[],
                         int numincident,
                         starreal d[3],
                         starreal r,
                         starreal worstqual)
{
    int i,j;
    /* MW was HUGE_FLOAT, which might be more principled, but leads to too many tensor evaluations */
    starreal alpha = HUGEFLOAT; 
    starreal newalpha;
    starreal rate;
    tag vtx = incidenttets[0].verts[0];
    
    /* if we are including surface quadrics add check for it */
    assert(numincident > 0);
    if (improvebehave->usequadrics && hasquadric(vtx) && get_info(vtx)->kind == CORNERVERTEX)
    {
        /* fetch the gradient of this quadric */
        starreal quadgrad[3];
        quadricgradtet(mesh, vtx, quadgrad);
        
        /* if this function improves more slowly
           than any in the active set, then it might
           end up as the objective. */
        rate = dot(d, quadgrad);
        if (rate + RATEEPSILON < r)
        {
            /* compute the approximation of when this
               function will become the objective */
            newalpha = (quadricerrortet(mesh, vtx) - worstqual) / (r - rate);
    
            /* if this is smaller than our current step size,
               use it for the step size */
            if (newalpha < alpha)
            {
                alpha = newalpha;
                if (improvebehave->verbosity > 5)
                {
                    printf("Vertex %d's quadric error sets initial alpha (%g raw, %g normalized, gradient = [%g %g %g])\n", (int) vtx, quadricerror(mesh, vtx), quadricerrortet(mesh, vtx), quadgrad[0], quadgrad[1], quadgrad[2]);
                }
            }
        }
    }
    
    for (i=0; i<numincident; i++)
    {
      for (j=0; j<incidenttets[i].numqualities; j++)
      {
        /* if this function improves more slowly
         than any in the active set, then it might
         end up as the objective. */
        rate = dot(d,incidenttets[i].qualitygrad[j]);
        if (rate + RATEEPSILON < r)
        {
          /* compute the approximation of when this
           function will become the objective */
          newalpha = (incidenttets[i].quality[j] - worstqual) / (r - rate);
          
          /* if this is smaller than our current step size,
           use it for the step size */
          if (newalpha < alpha)
          {
            alpha = newalpha;
          }
        }
      }      
    }
    
    if (alpha < 0.0)
    {
        alpha = 0.0;
    }
    return alpha;
}

/* find an interpolated value for vtx' attributes. vtx used to be at position origpoint, 
   and attributes still contains its original attribute values. It has moved somwhere 
   within incidenttets (if on the boundary, maybe also outside), use incidendtets to interpolate
   new attribute values for vtx.
*/
void interpolateattributesintets(struct tetcomplex *mesh, 
                                 tag vtx, starreal origpos[3], 
                                 struct opttet incidenttets[], int numincident, 
                                 starreal *attributes) {
  int i;
  tag faces[MAXINCIDENTTETS][3];
  int minidx = 0;
  starreal mincoord = -1e10;
  starreal coords[MAXINCIDENTTETS][4];
  starreal *newpos = ((struct vertex *) tetcomplextag2vertex(mesh, vtx))->coord;
  starreal newattr[MAXNUMATTRIBUTES];
  tag verts[4];

  assert(numincident);
  
  /* first, if vtx is inside one of the incident tets, interpolate within that tet, done. */
  for (i = 0; i < numincident; ++i) {
    int vtxidx = 0;
    starreal *v1, *v2, *v3;
    
    while (incidenttets[i].verts[vtxidx] != vtx) {
      assert(vtxidx < 3);
      vtxidx++;
    }
    
    faces[i][0] = incidenttets[i].verts[(vtxidx+1)%4];
    faces[i][1] = incidenttets[i].verts[(vtxidx+2)%4];
    faces[i][2] = incidenttets[i].verts[(vtxidx+3)%4];

    /* get vertex coordinates */
    v1 = ((struct vertex *) tetcomplextag2vertex(mesh, faces[i][0]))->coord;
    v2 = ((struct vertex *) tetcomplextag2vertex(mesh, faces[i][1]))->coord;
    v3 = ((struct vertex *) tetcomplextag2vertex(mesh, faces[i][2]))->coord;
    
    /* compute barycentric coordinates wrt this tet */
    getbarycentriccoordinates(origpos, v1, v2, v3, newpos, coords[i]);
    
    /* if it is inside, we're done. */
    if (coords[i][0] >= 0 && coords[i][0] <= 1 &&
        coords[i][1] >= 0 && coords[i][1] <= 1 && 
        coords[i][2] >= 0 && coords[i][2] <= 1 && 
        coords[i][3] >= 0 && coords[i][3] <= 1) {
      verts[0] = vtx;
      verts[1] = faces[i][0];
      verts[2] = faces[i][1];
      verts[3] = faces[i][2];
      interpolateattributes(mesh, 4, verts, coords[i], newattr);
      attrcopy(newattr, attributes);
      return;
    } else {
      /* not inside, but might still be closest */
#define MIN(a,b) ((a) < (b) ? (a) : (b))
      starreal thismin = MIN(coords[i][0], MIN(coords[i][1], MIN(coords[i][2], coords[i][3])));
      assert(thismin < 0);
      if (thismin > mincoord) {
        mincoord = thismin;
        minidx = i;
      }
    }
  }
  
  /* use the best incident tet found */
  verts[0] = vtx;
  verts[1] = faces[minidx][0];
  verts[2] = faces[minidx][1];
  verts[3] = faces[minidx][2];
  interpolateattributes(mesh, 4, verts, coords[minidx], newattr);
  attrcopy(newattr, attributes);  
}


/* perform non-smooth optimization of a vertex's position.
   vtx - the vertex to be smoothed, is in tet (vtx, vtx2, vtx3, vtx4).
   This tet gives us a starting point to build the list of incident
   elements.
   
   If we end up moving the vertex, return true.
   If for some reason we can't, return false.
*/
bool nonsmooth(struct tetcomplex *mesh,
               tag vtx,
               struct opttet incidenttets[],
               int numincident,
               starreal *outworstqual,
               int smoothkinds)
{
    starreal *v;           /* the vertex to be altered */
    starreal origpoint[3]; /* to save the original vertex location */
    starreal *attributes;  /* the attributes of said vertex */
    starreal oldattributes[MAXNUMATTRIBUTES]; /* save original attributes */
    int numactive;         /* number of quality functions in the active set */
    int i,k;               /* loop index */
    int numiter = 0;       /* number of optimization iterations */
    starreal worstqual;      /* the numerical value of the worst quality function */
    starreal worstqual_pure; /* worst non-quadric quality function */
    starreal inworstqual_pure;    /* at the beginning of the procedure */
    starreal thisqual;       /* quality of the current tet */
    starreal oldworstqual;   /* the numerical value of the worst quality function at the last step */
    starreal improvement;    /* how much we've improved this step */
    starreal d[3];           /* direction to move vertex */
    starreal dlength;        /* length of d */
    starreal r;              /* expected rate of improvement */
    starreal newr;           /* temp r var */
    starreal alpha;          /* step size */
    starreal newalpha;       /* candidate new step size */
    starreal rate;           /* the rate a particular function will improve in the direction d */
    starreal change[3];      /* change we'll make to the point */
    struct vertextype *vinfo;
    starreal qe;
    starreal allgrads[3];
    /* the gradients in the active set */
    starreal activegrads[MAXINCIDENTTETS][3];
    
    vinfo = get_info(vtx);
      
    /* if corner vertex smoothing is enabled, and this vertex is a facet
       or segment vertex, we need to check that it still is */
    if ((vinfo->kind == FACETVERTEX || vinfo->kind == SEGMENTVERTEX) &&
        improvebehave->cornersmooth)
    {
        if (improvebehave->verbosity > 4)
        {
            printf("Reclassifying in smooth, old type is %d", vinfo->kind);
        }
        
        /* reclassify this vertex */
        assert(incidenttets[0].verts[0] == vtx);
        vertexclassify(mesh, vtx, incidenttets[0].verts[1], incidenttets[0].verts[2], incidenttets[0].verts[3]);
        
        if (improvebehave->verbosity > 4)
        {
            printf(" new type is %d\n", vinfo->kind);
        }
    }
    /* Else, we still need to execute the callback reclassifier in case any
       constraints have changed */
    else
    {
            assert(incidenttets[0].verts[0] == vtx);
            vertexclassify_sim(mesh, vtx);
    }
    
    /* check whether to try to smooth facet/segment/corner vertices */
    if (vinfo->fixed)
    {
        return false;
    }
    if (vinfo->kind == FACETVERTEX && ((smoothkinds & SMOOTHFACETVERTICES) == 0))
    {
        return false;
    }
    if (vinfo->kind == SEGMENTVERTEX && ((smoothkinds & SMOOTHSEGMENTVERTICES) == 0))
    {
        return false;
    }
    if (vinfo->kind == CORNERVERTEX && ((smoothkinds & SMOOTHCORNERVERTICES) == 0))
    {
        return false;
    }
    
    switch (vinfo->kind)
    {
        case FREEVERTEX:
            improvestats.freesmoothattempts++;
            break;
        case FACETVERTEX:
            improvestats.facetsmoothattempts++;
            break;
        case SEGMENTVERTEX:
            improvestats.segmentsmoothattempts++;
            break;
        case CORNERVERTEX:
            improvestats.cornersmoothattempts++;
            break;
        default:
            printf("i don't know vertex type %d, dying\n", vinfo->kind);
            starexit(1);
    }
    improvestats.nonsmoothattempts++;
    
    /* get vertex to be altered */
    v = ((struct vertex *) tetcomplextag2vertex(mesh, vtx))->coord;
    attributes = (starreal *) tetcomplextag2attributes(mesh, vtx);
  
    /* save the original position and attributes of the vertex */
    vcopy(v, origpoint);
    attrcopy(attributes, oldattributes);
  
    /* find the worst quality of all incident tets */
    worstqual = HUGEFLOAT; 
    for (i=0; i<numincident; i++)
    {
        thisqual = tetquality(mesh,
                              incidenttets[i].verts[0],
                              incidenttets[i].verts[1],
                              incidenttets[i].verts[2],
                              incidenttets[i].verts[3]);
        
        /* is this the worst quality we've seen? */
        if (thisqual < worstqual) 
          worstqual = thisqual;
    }
  
    worstqual_pure = worstqual;
    inworstqual_pure = worstqual;
    
    if (improvebehave->verbosity > 4)
    {
      printf("Vertex %d's worst adjacent tet has quality %f before smoothing.\n", (int) vtx, worstqual);
    }  
  
    if (worstqual <= 0.0)
    {
        printf("Starting up smoothing, input tet has quality %g\n", worstqual);
    }
    assert(worstqual > 0.0);
    
    /* if we're using surface quadrics */
    /* if (improvebehave->usequadrics && vinfo->kind != FREEVERTEX) */
    if (improvebehave->usequadrics && vinfo->kind == CORNERVERTEX)
    {
        /* this vertex had better have an initialized quadric */
        assert(hasquadric(vtx));
        
        /* check whether the surface quadric is worse than all the tets */
        qe = quadricerrortet(mesh, vtx);
        if (qe < worstqual) 
        {
            if (improvebehave->verbosity > 3)
            {
                printf("Vertex %d's quadric error (%g raw, %g normalized) is worse than any tet quality!\n", (int) vtx, quadricerror(mesh, vtx), qe);
            }
            worstqual = qe;
        }
    }
    
    *outworstqual = worstqual_pure;
    
    allgrads[0] = allgrads[1] = allgrads[2] = 0.0;
    
    /* if this is a corner vertex, we have to compute the plane that it
         can move in first. do this by first getting the volume gradient for all tets */
    /* we're not doing this for now, vertices are free to move anywhere */
    if (vinfo->kind == CORNERVERTEX && false)
    {
        for (i=0; i<numincident; i++)
        {
            /* compute gradient info for this tet, faking that it's free */
            getoptinfo(mesh, &incidenttets[i]);
            /* accumulate the volume gradients as we go */
            vadd(incidenttets[i].volumegrad, allgrads, allgrads);
        }
        /* normalize the summed gradient vector */
        vscale(1.0 / vlength(allgrads), allgrads, allgrads);
        vcopy(allgrads, vinfo->vec);
        
        if (improvebehave->verbosity > 4)
        {
            printf("here are the incident tets:\n");
            printopttets(mesh, incidenttets, numincident);
            printf("normal to the constant volume plane is (%g %g %g)\n",  vinfo->vec[0], vinfo->vec[1], vinfo->vec[2]);
        }
    }
    
    /* identify the active set A of quality functions that are
       nearly as bad as f, the worst of them all */
    for (i=0; i<numincident; i++)
    {
        /* compute gradient info for this tet */
        getoptinfo(mesh, &incidenttets[i]);
    }
    
    getactiveset(mesh,
                 incidenttets,
                 numincident,
                 activegrads,
                 &numactive,
                 worstqual);
    
    if (numactive == 0)
    {
        return false;
    }
    
    /* d <- point on the convex hull of all gradients nearest origin */
    minconvexhullpoint(activegrads, numactive, d);
    
    /* if d is the origin, we can't improve this vertex with smoothing. */
    dlength = vlength(d);
    if (dlength < DEPSILON)
    {
        return false;
    }
    
    if (improvebehave->verbosity > 4 && vinfo->kind == CORNERVERTEX)
    {
        starreal normald[3];
        vscale(1.0 / dlength, d, normald);
        printf("the search direction (length %g) for corner is (%g, %g, %g)\n", dlength, normald[0], normald[1], normald[2]);
    }
    
    /* otherwise, it's time to do some smoothing! */
    do
    {
        /* find r, the expected rate of improvement. r is computed as the minimum
           dot product between the improvment direction d and all of the active 
           gradients, so it's like "how fast do we move in the direction of the
           gradient least favored by d." */
        
        /* start with an absurdly big r */
        r = HUGEFLOAT;
        /* find the smallest dot product */
        for (i=0; i<numactive; i++)
        {
            newr = dot(d,activegrads[i]);
            
            if (newr <= 0.0)
            {
                if (improvebehave->verbosity > 4)
                {
                    printf("\n\n r=%g is negative, hmm.\n",newr);
                    printf("d is (%g %g %g)\n", d[0], d[1], d[2]);
                    printf("the gradient in question i=%d is (%.17g %.17g %.17g)\n",i,activegrads[i][0],activegrads[i][1],activegrads[i][2]);
                    printf("here are all the gradients:\ngrads=[");
                    for(k=0; k<numactive; k++)
                    {
                        printf("%.17g %.17g %.17g;\n", activegrads[k][0],activegrads[k][1],activegrads[k][2]);
                    }
                    printf("]\nd=[%.17g %.17g %.17g]\n", d[0], d[1], d[2]);
                }
                
                /* if we have already moved the vertex some, this might still be a success */
                if (vequal(v, origpoint) == false)
                {
                  /* only record if we actually improved some tets, not only quadrics */
                  if (worstqual_pure >= inworstqual_pure) {
                    
                    /* compute attributes at new position */
                    /* find which old incident tet the vertex lies in */
                    /* if in one of them, interpolate within this tet */
                    /* if not in any (can happen only on the surface), extrapolate from the closest one */
                    interpolateattributesintets(mesh, vtx, origpoint, incidenttets, numincident, attributes);
                    
                    /* record this change in the journal */
                    journalsmooth(mesh, vtx, origpoint, v, oldattributes, attributes);
                    
                    *outworstqual = worstqual_pure;
              
                    if (improvebehave->verbosity > 4)
                    {
                        textcolor(BRIGHT, RED, BLACK);
                        printf("Just recorded a smooth that ended with d going bad!\n");
                        textcolor(RESET, WHITE, BLACK);
                    }
                    
                    /* record stats */
                    switch (vinfo->kind)
                    {
                        case FREEVERTEX:
                            improvestats.freesmoothsuccesses++;
                            break;
                        case FACETVERTEX:
                            improvestats.facetsmoothsuccesses++;
                            break;
                        case SEGMENTVERTEX:
                            improvestats.segmentsmoothsuccesses++;
                            break;
                        case CORNERVERTEX:
                            improvestats.cornersmoothsuccesses++;
                            break;
                        default:
                            printf("i don't know vertex type %d, dying\n", vinfo->kind);
                            starexit(1);
                    }
                    improvestats.nonsmoothsuccesses++;
                    return true;
                  } else {
                    /* move point back to original position */
                    vcopy(origpoint, v);
                    attrcopy(oldattributes, attributes);
                    return false;
                  }
                }
                else
                {
                    vcopy(origpoint, v);
                    attrcopy(oldattributes, attributes);
                    return false;
                }
            }
            
            /* this had better be positive */
            assert(newr > 0.0);
            
            if (newr < r)
            {
                r = newr;
            }
        }
        
        /* save the worst quality from the previous step */
        oldworstqual = worstqual;
      
        /* initialize alpha to the nearest intersection with another
           quality function */
        alpha = getinitialalpha(mesh,
                                incidenttets,
                                numincident,
                                d, r, worstqual);
        
        assert(alpha >= 0.0);

        /* if we didn't find a limit for alpha above, at least limit it
           so that we don't invert any elements. */
        if (alpha == HUGEFLOAT)
        {
            if (improvebehave->verbosity > 4) printf("using volume gradients to pick alpha...\n");
            
            for (i=0; i<numincident; i++)
            {
                /* if moving in the direction d will decrease 
                   this element's volume */
                rate = dot(d,incidenttets[i].volumegrad);
                if (rate < 0.0)
                {
                    newalpha = -incidenttets[i].volume / (2.0 * rate);
                    
                    /* if this is smaller than the current step size,
                       use it */
                    if (newalpha < alpha)
                    {
                        alpha = newalpha;
                    }
                }
            }
        }
        
        if (improvebehave->verbosity > 4) 
					printf("In non-smooth opt, found alpha_0 = %g, numiter = %d\n", alpha, numiter);
        
        /* do normal line search */
        nonsmoothlinesearch(mesh, vtx, d, worstqual, &alpha, r, incidenttets, numincident, vinfo->kind, vinfo->vec);
      
        assert(alpha >= 0.0);
        
        /* move vertex in direction d step size alpha */
        vscale(alpha, d, change);
        vadd(v, change, v);
         
        /* recompute quality information */
        oldworstqual = worstqual;
        worstqual = HUGEFLOAT; 
        for (i=0; i<numincident; i++)
        {
            thisqual = tetquality(mesh,
                                  incidenttets[i].verts[0],
                                  incidenttets[i].verts[1],
                                  incidenttets[i].verts[2],
                                  incidenttets[i].verts[3]);
            
            if (thisqual < 0.0)
            {
                printf("Just smooothed a vertex then found a tet with negative quality.\n");
                printf("alpha = %g\n", alpha);
            }
            
            /* is this the worst quality we've seen? */
            if (thisqual < worstqual) 
              worstqual = thisqual;
        }
      
        worstqual_pure = worstqual;
      
        /* if we're using surface quadrics */
        /* if (improvebehave->usequadrics && vinfo->kind != FREEVERTEX) */
        if (improvebehave->usequadrics && vinfo->kind == CORNERVERTEX)
        {
            /* this vertex had better have an initialized quadric */
            assert(hasquadric(vtx));

            /* check whether the surface quadric is the worse than all the tets */
            qe = quadricerrortet(mesh, vtx);
            if (qe < worstqual) 
            {
                if (improvebehave->verbosity > 3)
                {
                    printf("Vertex %d's quadric error (%g raw, %g normalized) is worse than any tet quality AFTER vertex move!\n", (int) vtx, quadricerror(mesh, vtx), qe);
                }
                worstqual = qe;
            }
        }

        /* unfortunately, this is not true. Quadrics might compell us to worsen tets. */
        /* assert(worstqual_pure >= inworstqual_pure); */
        
        if (improvebehave->verbosity > 5 || worstqual < 0.0) 
          printf("After moving vertex worstqual went from %g to %g, diff of %g\n\n",oldworstqual,worstqual,worstqual-oldworstqual);
        
        assert(worstqual >= 0.0);
        
        /* how much did we improve this step? */
        improvement = worstqual - oldworstqual;
        if (improvement < 0)
        {    
            textcolor(BRIGHT, RED, BLACK);
            printf("whoa, negative improvement!\n");
            printf("In non-smooth opt, found alpha_0 = %g, numiter = %d\n", alpha, numiter);
            printf("After moving vertex worstqual went from %g to %g, diff of %g\n\n",oldworstqual,worstqual,worstqual-oldworstqual);
            textcolor(RESET, WHITE, BLACK);
          
            assert(false);
          
            /* move point back to original position */
            vcopy(origpoint, v);
            attrcopy(oldattributes, attributes);
            return false;
        }
        assert(improvement >= 0);
      
        if (improvebehave->verbosity > 4)
          printf("smoothing vtx %d iter %d improvement %f q_before %f q_old %f q_now %f\n", (int) vtx, numiter, improvement, inworstqual_pure, oldworstqual, worstqual);
        
        /* recompute the active set */
        for (i=0; i<numincident; i++)
        {
            /* compute gradient info for this tet */
            getoptinfo(mesh, &incidenttets[i]);
        }
        getactiveset(mesh,
                     incidenttets,
                     numincident,
                     activegrads,
                     &numactive,
                     worstqual);
        assert(numactive > 0);
        
        /* d <- point on the convex hull of all gradients nearest origin */
        minconvexhullpoint(activegrads, numactive, d);
        
        numiter++;
        
        dlength = vlength(d);
    } while ((dlength > DEPSILON) && 
             (numiter < MAXSMOOTHITER) &&
             (improvement > MINSMOOTHITERIMPROVE));
    
    if (improvebehave->verbosity > 4)
    {
        printf("finished optimizing a vertex. d=(%g, %g, %g), numiter=%d, improvement=%g\n\n",d[0],d[1],d[2],numiter,improvement);
    }
    
    /* do not allow the quadric error to fall below the improvement threshold */
    if (worstqual_pure >= inworstqual_pure && (worstqual >= improvebehave->goalquality || improvebehave->dynamic == false)) {
      /* compute attributes at new position */
      /* find which old incident tet the vertex lies in */
      /* if in one of them, interpolate within this tet */
      /* if not in any (can happen only on the surface), extrapolate from the closest one */
      interpolateattributesintets(mesh, vtx, origpoint, incidenttets, numincident, attributes);
      
      /* record this change in the journal */
      journalsmooth(mesh, vtx, origpoint, v, oldattributes, attributes);
      
      *outworstqual = worstqual_pure;
        
      /* record stats */
      switch (vinfo->kind)
      {
          case FREEVERTEX:
              improvestats.freesmoothsuccesses++;
              break;
          case FACETVERTEX:
              improvestats.facetsmoothsuccesses++;
              break;
          case SEGMENTVERTEX:
              improvestats.segmentsmoothsuccesses++;
              break;
          case CORNERVERTEX:
              improvestats.cornersmoothsuccesses++;
              break;
          default:
              printf("i don't know vertex type %d, dying\n", vinfo->kind);
              starexit(1);
      }
      improvestats.nonsmoothsuccesses++;
      return true;
    } else {
      /* move point back to original position */
      vcopy(origpoint, v);
      attrcopy(oldattributes, attributes);
      return false;
    }
}

/* optimization-based smoothing for a single vertex
   v1, part of the existing tet (1,2,3,4) */
bool nonsmoothsinglevertex(struct tetcomplex *mesh,
                        tag v1,
                        tag v2,
                        tag v3,
                        tag v4,
                        starreal *worstout,
                        int kinds)
{
    int numincident = 0;
    bool noghosts = true;
    int incIter;
    bool smoothed;
    
    /* a list of all the tets incident to this vertex */
    tag incidenttettags[MAXINCIDENTTETS][4];
    /* a list of information about all the incident tets */
    struct opttet incidenttets[MAXINCIDENTTETS];
    
    if (tetexists(mesh, v1, v2, v3, v4) == false)
    {
        return false;
    }
    
    /* don't smooth if smoothing disabled */
    if (improvebehave->nonsmooth == 0) return false;
    
    getincidenttets(mesh, 
                    v1,
                    v2,
                    v3,
                    v4, 
                    incidenttettags,
                    &numincident,
                    &noghosts);
    assert(numincident > 0);
    
    if (improvebehave->verbosity > 4)
    {
        printf("here are the incident tets:\n");
        printtets(mesh, incidenttettags, numincident);
    }
    
    /* copy tags to incident tet data structure */
    for (incIter=0; incIter<numincident; incIter++)
    {
        /* copy vertex tags */
        incidenttets[incIter].verts[0] = incidenttettags[incIter][0];
        incidenttets[incIter].verts[1] = incidenttettags[incIter][1];
        incidenttets[incIter].verts[2] = incidenttettags[incIter][2];
        incidenttets[incIter].verts[3] = incidenttettags[incIter][3];
    }
  
    /* smooth the new vertex. */
    smoothed = nonsmooth(mesh,
                         v1,
                         incidenttets,
                         numincident,
                         worstout,
                         kinds);
  
    /*
    // check quadric error we created
    starreal qe = quadricerrortet(mesh, v1);
    starreal newpos[3], oldpos[3];
    int type = ((struct vertextype *) arraypoollookup(&vertexinfo, v1))->kind;
    vcopy(((struct vertex *) tetcomplextag2vertex(mesh, v1))->coord, newpos);
    vcopy(((struct quadric *) arraypoollookup(&surfacequadrics, v1))->origpos, oldpos);
    printf("ns: tag %d, type %d, qe %g, d [%g %g %g], success %d\n", v1, type, qe, newpos[0]-oldpos[0], newpos[1]-oldpos[1], newpos[2]-oldpos[2], smoothed);
    */
  
    if (smoothed) return true;
    return false;
}

/* combination lap/opt smoothing for a single vertex
   v1, part of the existing tet (1,2,3,4) */
bool smoothsinglevertex(struct tetcomplex *mesh,
                        tag v1,
                        tag v2,
                        tag v3,
                        tag v4,
                        starreal threshold,
                        starreal *worstout,
                        int kinds,
                        int *optattempts,
                        int *optsuccesses,
                        struct arraypoolstack *outstack)
{
    int numincident = 0;
    bool noghosts = true;
    int i;
    bool optsmoothed = false;
    struct improvetet *outtet;
    starreal thisqual, startworstqual=HUGEFLOAT;
    
    /* a list of all the tets incident to this vertex */
    tag incidenttettags[MAXINCIDENTTETS][4];
    /* a list of information about all the incident tets */
    struct opttet incidenttets[MAXINCIDENTTETS];
    
    if (tetexists(mesh, v1, v2, v3, v4) == false)
    {
        return false;
    }
    
    getincidenttets(mesh, 
                    v1,
                    v2,
                    v3,
                    v4, 
                    incidenttettags,
                    &numincident,
                    &noghosts);
    assert(numincident > 0);
    
    if (improvebehave->verbosity > 5)
    {
        printf("here are the incident tets:\n");
        printtets(mesh, incidenttettags, numincident);
    }
    
    /* copy tags to incident tet data structure */
    for (i=0; i<numincident; i++)
    {
        /* copy vertex tags */
        incidenttets[i].verts[0] = incidenttettags[i][0];
        incidenttets[i].verts[1] = incidenttettags[i][1];
        incidenttets[i].verts[2] = incidenttettags[i][2];
        incidenttets[i].verts[3] = incidenttettags[i][3];
        
        /* compute starting worst quality */
        if (SMOOTHPARANOID)
        {
            thisqual = tetquality(mesh, 
                                  incidenttets[i].verts[0],
                                  incidenttets[i].verts[1],
                                  incidenttets[i].verts[2],
                                  incidenttets[i].verts[3]);
        
            /* is this the worst quality incident tet? */
            if (thisqual < startworstqual) startworstqual = thisqual;
        }
    }
    
    /* if that fails to acheive desired quality, use non-smooth optimization-based smoothing */
    if (improvebehave->nonsmooth)
    {
      (*optattempts)++;
    
      optsmoothed = nonsmooth(mesh,
                              v1,
                              incidenttets,
                              numincident,
                              worstout,
                              kinds);
        
			if (improvebehave->verbosity > 4) {
				printf("done smoothing vertex %d, quality %f -> %f, result: %d\n", (int) v1, startworstqual, *worstout, optsmoothed);
			}
			
      if (SMOOTHPARANOID) {
        if (improvebehave->verbosity > 5) { 
          int m;
          printf("here are the incident tets:\n");
          for (m = 0; m < numincident; ++m) {
            printf("tet: %d %d %d %d, quality: %f\n", 
                   (int)incidenttettags[m][0], (int)incidenttettags[m][1], 
                   (int)incidenttettags[m][2], (int)incidenttettags[m][3], 
                   tetquality(mesh, incidenttettags[m][0], incidenttettags[m][1], incidenttettags[m][2], incidenttettags[m][3]));
          }
        }

        if (optsmoothed == true) {
          assert(*worstout >= startworstqual);
        }
      }
      
      if (optsmoothed == true) {
        (*optsuccesses)++;       
      }
    }
  
    /*
    // check quadric error we created
    starreal qe = quadricerrortet(mesh, v1);
    starreal newpos[3], oldpos[3];
    int type = ((struct vertextype *) arraypoollookup(&vertexinfo, v1))->kind;
    vcopy(((struct vertex *) tetcomplextag2vertex(mesh, v1))->coord, newpos);
    vcopy(((struct quadric *) arraypoollookup(&surfacequadrics, v1))->origpos, oldpos);
    printf("s: tag %d, type %d, qe %g, d [%g %g %g], success %d\n", v1, type, qe, newpos[0]-oldpos[0], newpos[1]-oldpos[1], newpos[2]-oldpos[2], optsmoothed);
    */
  
    if (optsmoothed)
    {
        /* if we are given an output stack, add all the incident tets to it*/
        if (outstack != NULL)
        {
            for (i=0; i<numincident; i++)
            {
                /* if we don't already have this one */
                if (tetinstack(outstack,
                               incidenttettags[i][0],
                               incidenttettags[i][1],
                               incidenttettags[i][2],
                               incidenttettags[i][3]) == false)
                {
                    outtet = (struct improvetet *) stackpush(outstack);
                    outtet->verts[0] = incidenttettags[i][0];
                    outtet->verts[1] = incidenttettags[i][1];
                    outtet->verts[2] = incidenttettags[i][2];
                    outtet->verts[3] = incidenttettags[i][3];
                }
            }
        }
        return true;
    }
    return false;
}

/* perform a pass of combination Laplacian / optimization-based smoothing. */
#define SKIPCHECKSIZE 0
bool smoothpass(struct tetcomplex *mesh,
                struct arraypoolstack *tetstack,
                struct arraypoolstack *outstack,
                struct arraypoolstack *influencestack,
                starreal threshold,
                starreal bestmeans[],
                starreal meanqualafter[],
                starreal *minqualafter,
                int smoothkinds,
                bool quiet)
{
    struct improvetet *stacktet;   /* point to stack tet */
    struct improvetet *outtet;     /* point to stack tet */
    int origstacksize;             /* number of tets in the original stack */
    int optattempts=0;             /* number of times optimization-based is tried */
    int optsuccesses=0;            /* number of times it succeeds */
    int cornerverts[2] = {0,0};
    int facetverts[2] = {0,0};
    int segmentverts[2] = {0,0};
    int freeverts[2] = {0,0};
    starreal worstqual;
    int i,j,k,l;                   /* loop indices */
    bool smoothed;                 /* was smoothing successful? */
    int numsmoothed = 0;           /* number of successful smoothing operations */
    int kind;                      /* number of degrees of freedom for vertex */
    int beforeid = lastjournalentry();
    starreal minqualbefore = HUGEFLOAT;
    starreal meshqualbefore = HUGEFLOAT;
    starreal meanqualbefore[NUMMEANTHRESHOLDS];
    int nonexist = 0;
    struct vertextype *smoothedvert;
    struct arraypool smoothedverts; /* list of vertices that have already been smoothed */
    bool *thisvertsmoothed;
    bool skip = false;
    
    *minqualafter = HUGEFLOAT;
    
    origstacksize = tetstack->top + 1;
    
    /* reset output stack */
    if (outstack != NULL)
    {
        assert(influencestack != NULL);
        
        /* copy the input stack to output stack */
        stackrestart(outstack);
        copystack(tetstack, outstack);
    }
    
    if (improvebehave->verbosity > 5 && outstack != NULL)
    {
        printf("input stack:\n");
        printstack(mesh, tetstack);
    }
    
    /* because if we smooth each vertex of each tet, we'll smooth some vertices
       over and over again, keep track of which vertices have been smoothed */
    
    /* initialize the list */
    arraypoolinit(&smoothedverts, sizeof(bool), LOG2TETSPERSTACKBLOCK, 0);
    if (origstacksize > SKIPCHECKSIZE)
    {
        /* set initial value of "smoothed or not" for every vertex */
        initsmoothedvertlist(tetstack, &smoothedverts);
    }
    
    /* compute worst input quality. do it global if no output stack */
    if (outstack != NULL)
    {
        stackquality(mesh, tetstack, meanqualbefore, &minqualbefore);
    }
    else
    {
        meshquality(mesh, meanqualbefore, &minqualbefore);
    }
  
    if (SMOOTHPARANOID) {
      starreal meanmeshqualbefore[NUMMEANTHRESHOLDS];
      meshquality(mesh, meanmeshqualbefore, &meshqualbefore);
    }
    
    /* try to pop all the tets off the stack */
    while (tetstack->top != STACKEMPTY)
    {
        /* pull the top tet off the stack */
        stacktet = (struct improvetet *) stackpop(tetstack);
        
        /* make sure this tet exists */
        if (tetexists(mesh, stacktet->verts[0], 
                            stacktet->verts[1], 
                            stacktet->verts[2], 
                            stacktet->verts[3]) == false)
        {
            nonexist++;
            continue;
        }
        
        if (outstack != NULL)
        {
            /* save this tet in the influenced tets stack */
            outtet = (struct improvetet *) stackpush(influencestack);
            outtet->quality = 0.0;
            outtet->verts[0] = stacktet->verts[0];
            outtet->verts[1] = stacktet->verts[1];
            outtet->verts[2] = stacktet->verts[2];
            outtet->verts[3] = stacktet->verts[3];
        }
        
        /* we're not doing simultaneous smoothing; try to smooth each vertex of this tet */
        for (i = 0; i < 4; i++) 
        {
            j = (i + 1) & 3;
            if ((i & 1) == 0) {
                l = (i + 3) & 3;
                k = (i + 2) & 3;
            } else {
                l = (i + 2) & 3;
                k = (i + 3) & 3;
            }
            
            skip = false;
            
            /* if we have not yet smoothed this vertex */
            if (origstacksize > SKIPCHECKSIZE)
            {
                thisvertsmoothed = (bool *) arraypoollookup(&smoothedverts, stacktet->verts[i]);
                assert(thisvertsmoothed != NULL);
                if (*thisvertsmoothed == true)
                {
                    if (improvebehave->verbosity > 5)
                    {
                        printf("skipping double smoothing of vertex %d\n", (int) stacktet->verts[i]);
                    }
                    skip = true;
                }
            }
            
            if (skip == false)
            {
                if (origstacksize > SKIPCHECKSIZE)
                {
                    *((bool *) arraypoolforcelookup(&smoothedverts, stacktet->verts[i])) = true;
                }
                
                /* record that we have smoothed this vertex */
                arraypoolforcelookup(&smoothedverts, stacktet->verts[i]);
                
                /* look up vertex type */
                smoothedvert = get_info(stacktet->verts[i]);
                assert(smoothedvert != NULL);
                assert(smoothedvert->kind != INPUTVERTEX);
                kind = smoothedvert->kind;
                /* record smoothing attempt */
                switch (kind)
                {
                    case FREEVERTEX: 
                        freeverts[0]++;
                        break;
                    case FACETVERTEX:
                        facetverts[0]++;
                        break;
                    case SEGMENTVERTEX:
                        segmentverts[0]++;
                        break;
                    case CORNERVERTEX:
                        cornerverts[0]++;
                        break;
                    default:
                        printf("bizarre vertex type %d in smooth, dying\n", kind);
                        assert(false);
                        break;
                }
                
                /* try to smooth it */
                /* only record affected tets if we were given an output stack */
                worstqual = 1e-100;
                smoothed = smoothsinglevertex(mesh,
                                   stacktet->verts[i],
                                   stacktet->verts[j],
                                   stacktet->verts[k],
                                   stacktet->verts[l],
                                   threshold,
                                   &worstqual,
                                   smoothkinds,
                                   &optattempts,
                                   &optsuccesses,
                                   influencestack);
                
                /* record number of successful smooths for this type of vertex */
                if (smoothed)
                {
                    numsmoothed++;
                  
                    switch (kind)
                    {
                        case FREEVERTEX: 
                            freeverts[1]++;
                            break;
                        case FACETVERTEX:
                            facetverts[1]++;
                            break;
                        case SEGMENTVERTEX:
                            segmentverts[1]++;
                            break;
                        case CORNERVERTEX:
                            cornerverts[1]++;
                            break;
                    }
                }
                
                if (improvebehave->verbosity > 5 && optattempts % 1000 == 0 && quiet == false && optattempts != 0)
                {
                    printf("Attempted %d smooths, stack size currently %lu\n", optattempts, tetstack->top);
                }
            }
        }
    }
    
    if (outstack != NULL)
    {
        /* check the quality of all influenced tets */
        stackquality(mesh, influencestack, meanqualafter, minqualafter);
        
        if (improvebehave->verbosity > 4 && quiet == false)
        {
            printf("just finished smoothing pass.\n");
            printf("    in stack size: %d - %d nonexistent = %d\n", origstacksize, nonexist, origstacksize-nonexist);
            printf("    influence stack size: %lu\n", influencestack->top+1);
            printf("    before min qual is %g\n", minqualbefore);
            printf("    after min qual is %g\n", *minqualafter);
            printf("    Mean qualities before:\n");
            printmeans(meanqualbefore);
            printf("    Mean qualities after:\n");
            printmeans(meanqualafter);
        }
        
        /* the output stack must have at least as many tets as the input stack */
        assert(influencestack->top + 1 >= origstacksize - nonexist);
      
        /* the individual smoothing attempts cannot decrease quality -- so this can never happen */
        if (SMOOTHPARANOID) {
          /* compute minimum quality for input stack and make sure it hasn't decreased. */
          starreal meshqualafter, meshmeanqualafter[100];
          meshquality(mesh, meshmeanqualafter, &meshqualafter);
          if (improvebehave->verbosity > 2) {
            printf("done smoothing, quality %f -> %f\n", meshqualbefore, meshqualafter);
          }
          assert(meshqualafter >= meshqualbefore);
        }
      
        /* if we failed to improve the worst quality, undo this pass */
        if (numsmoothed == 0)
        {
            if (improvebehave->verbosity > 5)
            {
                printf("Undoing last smoothing pass, minqualbefore was %g but after was %g\n", minqualbefore, *minqualafter);
            }
            invertjournalupto(mesh, beforeid);
            
            /* reset minimum output quality */
            *minqualafter = minqualbefore;
            
            /*starreal invertworst;
            stackquality(mesh, outstack, meanqualafter, &invertworst);
            
            if (invertworst != minqualbefore)
            {
                printf("after inverting journal, worst is %g, before pass it was %g\n", invertworst, minqualbefore);
            }
            
            assert(invertworst == minqualbefore); */
            
            arraypooldeinit(&smoothedverts);
            return false;
        }
    }
    
    if (quiet == false && outstack == NULL)
    {
        /* what's the worst quality element in the mesh now? */
        meshquality(mesh, meanqualafter, minqualafter);
    }
    
    /* print report */
    if (improvebehave->verbosity > 3 && quiet == false)
    {
        printf("Completed pass of optimization-based smoothing on stack of %d tets.\n", origstacksize);
        if (improvebehave->verbosity > 5)
        {
            if (bestmeans != NULL)
            {
                printf("    Best previous means:\n");
                printmeans(bestmeans);
            }
            printf("    Mean qualities after:\n");
            printmeans(meanqualafter);
        }
        printf("    Worst quality before: %g\n", minqualbefore);
        if (minqualbefore < *minqualafter)
        {
            textcolor(BRIGHT, GREEN, BLACK);
        }
        printf("    Worst quality after:  %g\n", *minqualafter);
        textcolor(RESET, WHITE, BLACK);
        if (improvebehave->verbosity > 4)
        {
            printf("    Optimization smoothing attempts:  %d\n", optattempts);
            printf("    Optimization smoothing successes: %d\n", optsuccesses);
            printf("    Free vertices (succ/tries):       %d/%d\n", freeverts[1], freeverts[0]); 
            printf("    Facet vertices (succ/tries):      %d/%d\n", facetverts[1], facetverts[0]);
            printf("    Segment vertices (succ/tries):    %d/%d\n", segmentverts[1], segmentverts[0]);
            printf("    Corner vertices (succ/tries):      %d/%d\n", cornerverts[1], cornerverts[0]);
        }
    }
    
    /* free list of smoothed verts */
    arraypooldeinit(&smoothedverts);
    return true;
}
