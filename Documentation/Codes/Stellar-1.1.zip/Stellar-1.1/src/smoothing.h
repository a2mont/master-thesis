#pragma once

#include "structs.h"

/* optimization-based smoothing for a single vertex
 v1, part of the existing tet (1,2,3,4) */
bool nonsmoothsinglevertex(struct tetcomplex *mesh,
                           tag v1,
                           tag v2,
                           tag v3,
                           tag v4,
                           starreal *worstout,
                           int kinds);

/* perform a pass of combination Laplacian / optimization-based smoothing. */
bool smoothpass(struct tetcomplex *mesh,
                struct arraypoolstack *tetstack,
                struct arraypoolstack *outstack,
                struct arraypoolstack *influencestack,
                starreal threshold,
                starreal bestmeans[],
                starreal meanqualafter[],
                starreal *minqualafter,
                int smoothkinds,
                bool quiet);
