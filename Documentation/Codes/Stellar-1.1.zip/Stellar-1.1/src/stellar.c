#include "stellar.h"
#include "convert.h"
#include "improve.h"
#include "improvedyn.h"
#include "quality.h"
#include "util.h"
#include "quadric.h"
#include "arraypoolstack.h"

void stellar_prepare(struct improvebehavior *i) {
  
  char *cl[2] = {"-rNE", "dummy.node"};
  
  /* copy improvebehave into our global configuration */
  improvebehave = i;
  
  /* initialize Star with a fake command line */
  parsecommandline(2, cl, &i->behave);
  primitivesinit();
  i->behave.quiet = 1;
}

starreal pulsar(int numinnodes,
                               starreal innodes[][3],
                               int numintets,
                               int intets[][4],
                               int numattr,
                               starreal *inattr,
                               int numignoretets,
                               int ignoretets[][4],
                               int *numoutnodes,
                               starreal **outnodesptr,
                               starreal **outattrptr,
                               int *numouttets,
                               int **outtetsptr,
                               int *nodemap) {
  int i,j;
  starreal vol;
  bool foundinverted = false;
  starreal result = 0.0;
  starreal (*outnodes)[3];
  int (*outtets)[4];
  starreal meanquality[NUMMEANTHRESHOLDS], minq, volumechange;
  
  if (improvebehave->verbosity > 1)
  {
    printf("Performing dynamic mesh improvement. \n");
  }
  
  /* read in vertices from array into vertexpool structure.
   this mimics polyfile = inputverticesreadsortstore(&behave, &in, &vertexpool); */
  assert(innodes != NULL);
  inputverts(numinnodes, innodes, inattr, numattr, &improvebehave->vertexpool, &improvebehave->in);
  inputmaketagmap(&improvebehave->vertexpool, improvebehave->in.firstnumber, improvebehave->in.vertextags);
  
  if (improvebehave->verbosity > 1)
  {
    printf("Finished reading in vertices. Pool has %lu vertices and occupies %lu bytes.\n", (long unsigned int)proxipoolobjects(&improvebehave->vertexpool), (long unsigned int)proxipoolbytes(&improvebehave->vertexpool));
  }
  
  for (i=0; i < numintets; i++)
  {
    /* compute the volume */
    vol = orient3d(&improvebehave->behave,
                   innodes[intets[i][0]],
                   innodes[intets[i][1]],
                   innodes[intets[i][2]],
                   innodes[intets[i][3]]) / 6.0;
    if (vol <= 0.0)
    {
      printf("input tet %d (%d %d %d %d) has negative volume %10g, shite.\n", i, intets[i][0], intets[i][1], intets[i][2], intets[i][3],  vol);
      printf("has verts:\n");
      for (j=0; j<4; j++)
      {
        printf("    (%g %g %g)\n", innodes[intets[i][j]][0], innodes[intets[i][j]][1], innodes[intets[i][j]][2]);
      }
      foundinverted = true;
    }
  }
  if (foundinverted)
  {
    printf("Pulsar encountered an inverted tet in input. Dying.");
    return false;
  }  
  
  /* read in tets from array into the mesh
   this mimics inputtetrahedra(&behave, &in, &vertexpool, &out, &mesh); */
  assert(intets != NULL);
  inputtets(numintets, intets, &improvebehave->behave, &improvebehave->in, &improvebehave->vertexpool, &improvebehave->out, &improvebehave->mesh);
  
  if (improvebehave->verbosity > 1)
  {
    printf("Finished reading in tets.\n");
  }
  
  /* do the actual mesh improvement here */
  result = dodynimprove(&improvebehave->behave, &improvebehave->in, &improvebehave->vertexpool, &improvebehave->mesh, numignoretets, ignoretets, &volumechange);
  
  /* compute output quality */
  meshquality(&improvebehave->mesh, meanquality, &minq);
  result = minq;
  
  /* convert back to flat arrays to pass back to the simulator */
  outputvertsarray(&improvebehave->vertexpool, numoutnodes, outnodesptr, outattrptr);
  outputtetsarray(&improvebehave->mesh, numouttets, outtetsptr);
  outnodes = ((starreal(*)[3])(*outnodesptr));
  
  /* check all output tets for positive volume */
  outnodes = ((starreal(*)[3])(*outnodesptr));
  outtets = ((int(*)[4])(*outtetsptr));
  for (i=0; i < *numouttets; i++)
  {
    /* compute the volume */
    vol = orient3d(&improvebehave->behave,
                   outnodes[outtets[i][0] - 1],
                   outnodes[outtets[i][1] - 1],
                   outnodes[outtets[i][2] - 1],
                   outnodes[outtets[i][3] - 1]) / 6.0;
    if (vol <= 0.0)
    {
      printf("output tet %d (%d %d %d %d) has negative volume %10g, shite.\n", i, outtets[i][0], outtets[i][1], outtets[i][2], outtets[i][3],  vol);
      printf("has verts:\n");
      for (j=0; j<4; j++)
      {
        printf("    (%g %g %g)\n", outnodes[outtets[i][j]-1][0], outnodes[outtets[i][j]-1][1], outnodes[outtets[i][j]-1][2]);
      }
      foundinverted = true;
    }
  }
  
  /* build array to pass back with node correspondences */
  for (i=0; i < improvebehave->in.vertexcount; i++)
  {
    /* check that vertex hasn't moved */
    if (
        (innodes[i][0] == outnodes[improvebehave->in.vertextags[i]][0]) &&
        (innodes[i][1] == outnodes[improvebehave->in.vertextags[i]][1]) &&
        (innodes[i][2] == outnodes[improvebehave->in.vertextags[i]][2])
        )
    {
      nodemap[i] = improvebehave->in.vertextags[i];
    }
    else
    {
      nodemap[i] = NOTINLIST;
    }
  }
  
  if (improvebehave->verbosity > 1)
  {
    printf("Dynamic mesh improvement complete. \n");
  }
  
  return result;
}

starreal stellar(int numinnodes,
                              starreal innodes[][3],
                              int numintets,
                              int intets[][4],
                              int numattr,
                              starreal *inattr,
                              int *numoutnodes,
                              starreal **outnodesptr,
                              starreal **outattrptr,
                              int *numouttets,
                              int **outtetsptr,
                              int *nodemap) {
  int i,j;
  starreal vol;
  bool foundinverted = false;
  starreal result = 0.0;
  starreal (*outnodes)[3];
  int (*outtets)[4];
  starreal meanquality[NUMMEANTHRESHOLDS], minq;
  
  if (improvebehave->verbosity > 1)
  {
    printf("Performing dynamic mesh improvement. \n");
  }
  
  /* read in vertices from array into vertexpool structure.
   this mimics polyfile = inputverticesreadsortstore(&behave, &in, &vertexpool); */
  assert(innodes != NULL);
  inputverts(numinnodes, innodes, inattr, numattr, &improvebehave->vertexpool, &improvebehave->in);
  inputmaketagmap(&improvebehave->vertexpool, improvebehave->in.firstnumber, improvebehave->in.vertextags);
  
  if (improvebehave->verbosity > 1)
  {
    printf("Finished reading in vertices. Pool has %lu vertices and occupies %lu bytes.\n", (long unsigned int)proxipoolobjects(&improvebehave->vertexpool), (long unsigned int)proxipoolbytes(&improvebehave->vertexpool));
  }
  
  for (i=0; i < numintets; i++)
  {
    /* compute the volume */
    vol = orient3d(&improvebehave->behave,
                   innodes[intets[i][0]],
                   innodes[intets[i][1]],
                   innodes[intets[i][2]],
                   innodes[intets[i][3]]) / 6.0;
    if (vol <= 0.0)
    {
      printf("input tet %d (%d %d %d %d) has negative volume %10g, shite.\n", i, intets[i][0], intets[i][1], intets[i][2], intets[i][3],  vol);
      printf("has verts:\n");
      for (j=0; j<4; j++)
      {
        printf("    (%g %g %g)\n", innodes[intets[i][j]][0], innodes[intets[i][j]][1], innodes[intets[i][j]][2]);
      }
      foundinverted = true;
    }
  }
  if (foundinverted)
  {
    printf("Stellar encountered an inverted tet in input. Dying.");
    return false;
  }  
  
  /* read in tets from array into the mesh
   this mimics inputtetrahedra(&behave, &in, &vertexpool, &out, &mesh); */
  assert(intets != NULL);
  inputtets(numintets, intets, &improvebehave->behave, &improvebehave->in, &improvebehave->vertexpool, &improvebehave->out, &improvebehave->mesh);
  
  if (improvebehave->verbosity > 1)
  {
    printf("Finished reading in tets.\n");
  }
  
  staticimprove(&improvebehave->behave, &improvebehave->in, &improvebehave->vertexpool, &improvebehave->mesh);
  
  /* compute output quality */
  meshquality(&improvebehave->mesh, meanquality, &minq);
  result = minq;
  
  /* convert back to flat arrays to pass back to the simulator */
  outputvertsarray(&improvebehave->vertexpool, numoutnodes, outnodesptr, outattrptr);
  outputtetsarray(&improvebehave->mesh, numouttets, outtetsptr);
  outnodes = ((starreal(*)[3])(*outnodesptr));
  
  /* check all output tets for positive volume */
  outnodes = ((starreal(*)[3])(*outnodesptr));
  outtets = ((int(*)[4])(*outtetsptr));
  for (i=0; i < *numouttets; i++)
  {
    /* compute the volume */
    vol = orient3d(&improvebehave->behave,
                   outnodes[outtets[i][0] - 1],
                   outnodes[outtets[i][1] - 1],
                   outnodes[outtets[i][2] - 1],
                   outnodes[outtets[i][3] - 1]) / 6.0;
    if (vol <= 0.0)
    {
      printf("output tet %d (%d %d %d %d) has negative volume %10g, shite.\n", i, outtets[i][0], outtets[i][1], outtets[i][2], outtets[i][3],  vol);
      printf("has verts:\n");
      for (j=0; j<4; j++)
      {
        printf("    (%g %g %g)\n", outnodes[outtets[i][j]-1][0], outnodes[outtets[i][j]-1][1], outnodes[outtets[i][j]-1][2]);
      }
    }
  }
  
  /* build array to pass back with node correspondences */
  for (i=0; i < improvebehave->in.vertexcount; i++)
  {
    /* check that vertex hasn't moved */
    if (
        (innodes[i][0] == outnodes[improvebehave->in.vertextags[i]][0]) &&
        (innodes[i][1] == outnodes[improvebehave->in.vertextags[i]][1]) &&
        (innodes[i][2] == outnodes[improvebehave->in.vertextags[i]][2])
        )
    {
      nodemap[i] = improvebehave->in.vertextags[i];
    }
    else
    {
      nodemap[i] = NOTINLIST;
    }
  }
  
  if (improvebehave->verbosity > 1)
  {
    printf("Dynamic mesh improvement complete. \n");
  }
  
  return result;
}

/* free memory, etc. */
void stellar_finalize() {
  /* free the vertexinfo, quadrics, journal, allocated by the improvement */
  arraypooldeinit(&improvebehave->vertexinfo);
  stackdeinit(&improvebehave->journal);
  arraypooldeinit(&improvebehave->surfacequadrics);  
  
  /* Free the array of vertex tags allocated by inputall(). */
  if (improvebehave->in.vertextags != (tag *) NULL) {
    starfree(improvebehave->in.vertextags);
    improvebehave->in.vertextags = (tag *) NULL;
  }
  /* Free the pool of vertices initialized by inputall(). */
  proxipooldeinit(&improvebehave->vertexpool);
  
  /* Free the mesh */
  tetcomplexdeinit(&improvebehave->mesh);
}

/* information access functions (useful in progress callback, or after improvement but before finalize) */
struct quadric *stellar_getquadric(int vtag) {
  return get_quadric(vtag);
}

struct vertextype *stellar_getinfo(int vtag) {
  return get_info(vtag);
}

starreal *stellar_getcoords(int vtag) {
  return get_coords(vtag);
}

starreal *stellar_getattributes(int vtag) {
  return get_attributes(vtag);
}



















