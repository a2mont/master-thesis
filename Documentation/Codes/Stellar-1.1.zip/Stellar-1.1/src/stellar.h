#pragma once

#ifdef __cplusplus
namespace Stellar {
extern "C" {
#endif

#include "structs.h"

/* C prototypes */
  
  /* prepare for improvement of a mesh */
  void stellar_prepare(struct improvebehavior *);
  
  /* improve a mesh using the static improvement schedule */
  starreal stellar(int numinnodes,
                   starreal innodes[][3],
                   int numintets,
                   int intets[][4],
                   int numattr,
                   starreal *inattr,
                   int *numoutnodes,
                   starreal **outnodesptr,
                   starreal **outattrptr,
                   int *numouttets,
                   int **outtetsptr,
                   int *nodemap);
  /* improve a mesh using the dynamic improvement schedule */
  starreal pulsar(int numinnodes,
                  starreal innodes[][3],
                  int numintets,
                  int intets[][4],
                  int numattr,
                  starreal *inattr,
                  int numignoretets,
                  int ignoretets[][4],
                  int *numoutnodes,
                  starreal **outnodesptr,
                  starreal **outattrptr,
                  int *numouttets,
                  int **outtetsptr,
                  int *nodemap);
  
  /* free memory, etc. */
  void stellar_finalize();
  
  /* information access functions (useful in progress callback, or after improvement but before finalize) */
  struct quadric *stellar_getquadric(int vtag);
  struct vertextype *stellar_getinfo(int vtag);
  starreal *stellar_getattributes(int vtag);
  starreal *stellar_getcoords(int vtag);
  
#ifdef __cplusplus
/* C++ prototypes */  

#endif
  
#ifdef __cplusplus
} /* extern "C" */
} /* namespace Pulsar */
#endif
