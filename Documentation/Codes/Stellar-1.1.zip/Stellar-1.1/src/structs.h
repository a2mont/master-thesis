#pragma once

/*
 
 datatype definitions

 Martin Wicke
 
 */

/* this should include should get us everything we need from star            */
#include "Starbase.h"

#include <assert.h>
#include <stdio.h>

#include "config.h"

/*****************************************************************************/
/*                                                                           */
/*  Data structures                                                          */
/*                                                                           */
/*****************************************************************************/

struct opttet;
struct vertextype;

/* a stack implemented with an arraypool */
struct arraypoolstack
{
  struct arraypool pool; /* the array pool that makes up the stack */
  long top;     /* the index of the top element in the array */
  long maxtop;  /* the maximum size the stack has ever been */
};

/* structure to hold all the options for improvement */
struct improvebehavior
{
  starreal goalquality;        /* terminate improvement when this minimum quality is reached */
  
  int dynamic;                 /* flag to optimize improvement for the dynamic case */
  
  /* Quadric smoothing options */
  int usequadrics;             /* incorporate quadric error into the objective function */
  starreal quadricoffset;      /* quality to start every quadric at */
  starreal quadricscale;       /* factor to scale quadric by */
  starreal sizecontractquadricscale; /* factor for scaling during sizing contraction passes */
	
  /* Smoothing options */
  int nonsmooth;               /* enable non-smooth optimization-based smoothing */
  int facetsmooth;             /* enable smoothing of facet vertices */
  int segmentsmooth;           /* enable smoothing of segment vertices */
  int cornersmooth;             /* enable smoothing of corner vertices */
  
  /* Topological options */
  int edgeremoval;             /* enable edge removal */
  int edgecontraction;         /* enable edge contraction */
  int boundedgeremoval;        /* enable boundary edge removal */
  int singlefaceremoval;       /* enable single face removal (2-3 flips) */
  int multifaceremoval;        /* enable multi face removal */
  int flip22;                  /* enable 2-2 flips */
  starreal flip22volumetol;	   /* tolerance for volume change in 2-2 flips */
  starreal flip22normaltol;	   /* tolerance for normal change in 2-2 flips */
  
  /* Insertion options */
  int enableinsert;            /* global enable of insertion */
  starreal insertthreshold;    /* percent worst tets */
  int insertbody;              /* enable body vertex insertion */
  int insertfacet;             /* enable facet insertion */
  int insertsegment;           /* enable segment insertion */
  int cavityconsiderdeleted;   /* consider enlarging cavity for deleted tets? */
  int cavdepthlimit;           /* only allow initial cavity to includes tets this deep */
  
  /* sizing options */
  int sizing;                  /* globally enable mesh element size control */
  int sizingpass;              /* enable or disable initial edge length control */
  starreal targetedgelength;   /* edge length of the ideal edge for this mesh */
  starreal longerfactor;       /* factor by which an edge can be longer */
  starreal shorterfactor;      /* factor by which an edge can be shorter */
  int dynsizing;               /* globally enable dynamic size control */
  starreal minlengthratio;     /* min tolerated ratio of minedgelength/maxedgelength */
  
  /* fine-tuning options */
  starreal minstepimprovement; /* demand at least this much improvement in the mean per step */
  starreal mininsertionimprovement; /* demand in improvement for insertion */
  starreal maxinsertquality;   /* never attempt insertion in a tet better than this */
  
  /* for static improvement only */
  starreal meanthresholds[NUMMEANTHRESHOLDS]; /* quality thresholds for averages */
  
  /* verbosity & output */
  int verbosity;
  int usecolor;
  
  /* callback functions */
  
  /* sizing tensor field. If NULL, defaults to identity */
  void (*tensor_cb)(const starreal point[3], 
                    starreal tensor[3][3]);
  
  /* quality evaluation for tets and optimization information, must be non-NULL. */
  starreal (*quality_cb)(const starreal point[4][3]);
  void (*optinfo_cb)(const starreal point[4][3], 
                     struct opttet *opttet);
  
  /* classification callback for imposing constraints on the smoothing. Can be NULL. */
  void (*classifyvertex_cb)(int vtag, const starreal vpoint[3], const starreal* vattr, 
                            struct vertextype* vtype);
  
  /* called after each pass (for UI updates etc.), can be NULL. Return false to stop remeshing. */
  bool (*progress_cb)(struct improvebehavior *);  
  
  /* internal (set during mesh load / improvement) */
  int attribcount;             /* number of attributes with each node */
  struct tetcomplex mesh;      /* the mesh we work on */
  struct proxipool vertexpool; /* the vertex coordinates and attributes */
  struct arraypool vertexinfo; /* additional vertex info */
  struct arraypool surfacequadrics; /* quadrics */
  struct arraypoolstack journal; /* journal */
  struct inputs in;            /* Star data structure */
  struct outputs out;
  struct behavior behave;
};

/* structure to hold global improvement statistics */
struct improvestats
{
  /* smoothing stats */
  int nonsmoothattempts;
  int nonsmoothsuccesses;
  int freesmoothattempts;
  int freesmoothsuccesses;
  int facetsmoothattempts;
  int facetsmoothsuccesses;
  int segmentsmoothattempts;
  int segmentsmoothsuccesses;
  int cornersmoothattempts;
  int cornersmoothsuccesses;
  
  /* topological stats */
  int edgeremovals;
  int boundaryedgeremovals;
  int edgeremovalattempts;
  int boundaryedgeremovalattempts;
  int ringsizesuccess[MAXRINGTETS];
  int ringsizeattempts[MAXRINGTETS];
  int faceremovals;
  int faceremovalattempts;
  int facesizesuccess[MAXFACETREESIZE];
  int facesizeattempts[MAXFACETREESIZE];
  int flip22attempts;
  int flip22successes;
  int edgecontractionattempts;
  int edgecontractions;
  int edgecontractcaseatt[NUMEDGECASES+1];
  int edgecontractcasesuc[NUMEDGECASES+1];
  int edgecontractringatt[MAXRINGTETS];
  int edgecontractringsuc[MAXRINGTETS];
  
  /* insertion stats */
  int bodyinsertattempts;
  int bodyinsertsuccesses;
  int facetinsertattempts;
  int facetinsertsuccesses;
  int segmentinsertattempts;
  int segmentinsertsuccesses;
  int maxcavitysizes[MAXCAVITYTETS];
  int finalcavitysizes[MAXCAVITYTETS];
  int biggestcavdepths[MAXCAVDEPTH];
  int lexmaxcavdepths[MAXCAVDEPTH];
  
  /* timing stats */
#ifndef NO_TIMER
  struct timeval starttime;
#endif /* not NO_TIMER */
  int totalmsec;
  int smoothmsec;
  int topomsec;
  int contractmsec;
  int insertmsec;
  int smoothlocalmsec;
  int topolocalmsec;
  int insertlocalmsec;
  int contractlocalmsec;
  int biggestcavityusec;
  int finalcavityusec;
  int cavityimproveusec;
  
  /* general stats */
  int startnumtets;
  int finishnumtets;
  int startnumverts;
  int finishnumverts;
  starreal dynchangedvol;
  
  /* quality stats */
  starreal finishworstqual;
  starreal startworstqual;
  starreal startminangle;
  starreal startmaxangle;
  starreal startmeanquals[NUMMEANTHRESHOLDS];
  starreal finishmeanquals[NUMMEANTHRESHOLDS];
};

/* a tet for the improvement stack, referred to by the tuple of its vertices
 and a single quality measure */
struct improvetet
{
  tag verts[4];
  starreal quality;
};

/* structure for holding quality and gradient information for non-smooth
 optimization-based vertex smoothing */
struct opttet
{
  tag verts[4];               /* vertices of the tetrahedron */
  starreal volume;            /* volume of tetrahedron */
  starreal volumegrad[3];     /* the gradient of the volume of the tet wrt vtx1 */
  
  /* for nonsmooth optimization, we need to know the function values and gradients of all functions
     whose minimum is the final quality */
  starreal quality[MAXQUALITYCOMPONENTS];
  starreal qualitygrad[MAXQUALITYCOMPONENTS][3];
  int numqualities;	
};

/* store mappings from tags to vertex types */
struct vertextype
{
  int kind;                             /* the kind of vector this is (FREEVERTEX, FACETVERTEX, etc) */
  starreal vec[3];			/* a vector associated with the vertex. for FACETVERTEX,
                                           this is the normal to the plane that the vertex can move in.
                                           for SEGMENTVERTEX, this is a vector in the direction of the
                                           segment. */
  bool fixed;				/* If true, this vertex cannot be smoothed */
};

/* stack data structure using arraypool */

/* cardinal value for empty stack */
#define STACKEMPTY -1

/* use 1024 tets per level-two block */
#define LOG2TETSPERSTACKBLOCK 10

/* surface error quadric */
struct quadric
{
  starreal a2, ab, ac, ad;
  starreal     b2, bc, bd;
  starreal         c2, cd;
  starreal             d2;
  starreal origpos[3];     /* original vertex position */
  bool hasquadric;
  
  /* TODO: deprecated and unused */
  int numfaces;            /* number of incident faces */
  starreal facesum;        /* sum of incident face areas */
  starreal weightsum;      /* sum of incident face weights */
  starreal edge2harm;      /* harmonic mean of squares of inc. edge lengths */  
};

/* improvement journal entry. this should be general enough
 to store information on any change to the mesh, and for each
 change should store enough information to invert it */

enum journalentryclasses
{
  ALLENTRIES,    /* match all entries */
  META,          /* Comments and the like */
  INSERTDELETE,  /* insertion or deletion of vertices */
  SMOOTH,        /* change position of a single vertex */
  TOPOLOGICAL,   /* topological change involving multiple vertices */
  LABEL,         /* classify a vertex */
  SURFACE        /* change/add a quadric */
};

enum journalentrytypes
{
  MARKER,        /* no semantics, just to give context */
  INSERTVERTEX,  /* insertion of a vertex */
  DELETEVERTEX,  /* deletion of a vertex */
  SMOOTHVERTEX,  /* smoothing of a vertex */
  DELETETET,     /* single tet deletion */
  INSERTTET,     /* single tet insertion */
  FLIP23,        /* 2-3 flip, base case for face removal */
  FLIP32,        /* 3-2 flip, base case for edge removal */
  FLIP22,        /* 2-2 flip */
  FLIP41,        /* 4-1 flip (precedes deletion of interior vertex) */
  FLIP14,        /* 1-4 flip (follows insertion of interior vertex) */
  FLIP13,        /* 1-3 flip (same as 1-4 but inserted vertex is on facet) */
  FLIP31,        /* the inverse of a 1-3 flip */
  FLIP12,        /* 1-2 flip (same as 1-4 but inserted vertex is on edge) */
  FLIP21,        /* inverse of 1-2 */
  CLASSIFY,      /* classify vertex (FREEVERTEX, FACETVERTEX, etc) */
  QUADRIC        /* recompute a quadric */
};

struct journalentry
{
  int id;             /* unique identifier for this entry */
  int category;          /* class (smoothing, topological, etc) */
  int type;           /* type of entry, selected from jounalentrytypes */
  tag verts[5];       /* up to five vertices involved in the operation */
  int numverts;       /* the exact number involved in the operation */
  int old_classification, classification; /* classification for CLASSIFY entries*/
  starreal newpos[3]; /* the new position of the vertex, if it was smoothed */
  starreal oldpos[3]; /* the old position of the vertex, if it was moved */
  starreal newattributes[MAXNUMATTRIBUTES]; /* new attributes (for smoothing and insertion) */
  starreal oldattributes[MAXNUMATTRIBUTES]; /* old attributes (for smoothing) */
  struct quadric oldquadric;  /* the old quadric (for quadric changes) */
  struct quadric newquadric;  /* the new quadric (for quadric changes) */
  char context[80];  /* a comment or something like that */
};


/* globals.c */
extern struct improvebehavior *improvebehave;
extern struct improvestats improvestats;

