#include "timer.h"

#ifndef NO_TIMER
/* returns the number of milliseconds elapsed between tv1 and tv2 */
int msecelapsed(struct timeval tv1, struct timeval tv2)
{
  return 1000l * (tv2.tv_sec - tv1.tv_sec) + (tv2.tv_usec - tv1.tv_usec) / 1000l;
}

/* returns the number of microseconds elapsed between tv1 and tv2 */
int usecelapsed(struct timeval tv1, struct timeval tv2)
{
  return 1000000l * (tv2.tv_sec - tv1.tv_sec) + (tv2.tv_usec - tv1.tv_usec);
}

#if defined(_MSC_VER)
#include "Windows.h"
#endif

#if defined(_MSC_VER)
DWORD lastTime;
#else
struct timeval lastTime;
#endif

void timerstart() {
  /* TODO: use QueryPerformanceTimer?, clock()? */
#if defined(_MSC_VER)
  lastTime = GetTickCount();
#else
  gettimeofday(&lastTime, NULL);
#endif
}

starreal timerstop() {
  starreal dt;
#ifdef _MSC_VER
  DWORD currentTime = GetTickCount();
  dt = (starreal)(currentTime - lastTime)*0.001f; 
#else
  struct timeval currentTime;
  gettimeofday(&currentTime, NULL);
  dt = (starreal)((currentTime.tv_sec - lastTime.tv_sec) + 1e-6*(currentTime.tv_usec - lastTime.tv_usec));
#endif
  return dt;
}

#endif /* not NO_TIMER */
