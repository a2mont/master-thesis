#pragma once

#include "structs.h"

#ifndef NO_TIMER

#include <sys/time.h>

/* returns the number of milliseconds elapsed between tv1 and tv2 */
int msecelapsed(struct timeval tv1, struct timeval tv2);

/* returns the number of microseconds elapsed between tv1 and tv2 */
int usecelapsed(struct timeval tv1, struct timeval tv2);

/* a simple timer */
void timerstart();
starreal timerstop();

#endif