#pragma once

#include "structs.h"

/* my wrapper for single tet insertion, gets recorded in the journal */
bool inserttet(struct tetcomplex *mesh,
               tag vtx1,
               tag vtx2,
               tag vtx3,
               tag vtx4,
               bool record, bool failonerror);

/* my wrapper for single tet deletion, gets recorded in the journal */
void deletetet(struct tetcomplex *mesh,
               tag vtx1,
               tag vtx2,
               tag vtx3,
               tag vtx4,
               bool record);

/* bryan's own version of 2-3 flip that uses explicit
 delete and insert calls to perform the flip */
void flip23(struct tetcomplex *mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtxbot,
            tag vtxtop,
            bool record);


/* bryan's own version of a 3-2 flip that uses explicit
 delete and insert calls to perform the flip */
void flip32(struct tetcomplex *mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtxbot,
            tag vtxtop,
            bool record);

/* perform a 2-2 flip using the edge from vtx1 to vtx2 */
void flip22(struct tetcomplex *mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtxbot,
            tag vtxtop,
            bool record);


/* given the tet (1,2,3,4), and the vertex bodyvertex
 in its interior, delete the original tet and connect
 the interior vertex to the old vertices, forming 4 new
 tets */
void flip14(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag bodyvtx,
            bool record);



/* reverses a 1-4 flip */
void flip41(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag bodyvtx,
            bool record);



/* given a tetrahedron with a boundary face and a new vertex that
 lies inside that face, remove the old tet and create three new
 ones. vtx2, vtx3, vtx4 should be the boundary face oriented
 toward vtx1 with a right-hand rule */
void flip13(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag facetvtx,
            bool record);


/* the opposite of a 1-3 flip. Given three tets that share
 a facet vertex and an interior vertex, remove the facet
 vertex and replace them with one tet. vtx1 is the 
 interior vertex, facetvtx is the facet vtx, and 
 the other three vertices are on the future boundary
 facet and will form face (2,3,4) oriented toward vtx1 */
void flip31(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag facetvtx,
            bool record);



/* given a tetrahedron with a boundary edge and a new vertex that
 lies on that segment, remove the old tet and create two new
 ones. vtx1, vtx2 should be the boundary edge */
void flip12(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag segmentvtx,
            bool record);


/* reverse the above 1-2 flip */
void flip21(struct tetcomplex* mesh,
            tag vtx1,
            tag vtx2,
            tag vtx3,
            tag vtx4,
            tag segmentvtx,
            bool record);



/* try to contract all six edges of a tet */
bool tryedgecontract(struct tetcomplex *mesh,
                     tag vtx1, tag vtx2, tag vtx3, tag vtx4,
                     struct arraypoolstack *outstack,
                     starreal *minqualbefore,
                     starreal *minqualafter,
                     bool requireimprove,
                     bool justfirstedge);

/* try contracting the edge from v1 to v2 that is in the
 tet (v1, v2, v3, v4). Return true if edge contraction
 succeeds in improving quality of all affected tets,
 and false otherwise (mesh unchanged on failure) */
bool edgecontract(struct tetcomplex *mesh,
                  tag v1,
                  tag v2,
                  tag v3,
                  tag v4,
                  starreal *minqualbefore,
                  starreal *minqualafter,
                  int *numouttets,
                  tag outtets[MAXINCIDENTTETS][4],
                  bool requireimprove);



/* perform a pass of topological improvement.
 for now, this means trying to remove each edge
 of each tet in the stack that is passed in,
 and if no edge can be removed, trying to remove
 each face. */
bool topopass(struct tetcomplex *mesh,
              struct arraypoolstack *tetstack,
              struct arraypoolstack *outstack,
              starreal bestmeans[],
              starreal meanqualafter[],
              starreal *minqualafter,
              bool quiet);

/* for each tet in the stack, try to contract its edges */
bool contractpass(struct tetcomplex *mesh,
                  struct arraypoolstack *tetstack,
                  struct arraypoolstack *outstack,
                  starreal bestmeans[],
                  starreal meanqualafter[],
                  starreal *minqualafter,
                  bool justfirstedge,
                  bool quiet);


/* go after the worst tets with contraction */
void contractworst(struct tetcomplex *mesh,
                   starreal percentinsert,
                   starreal bestmeans[],
                   starreal outmeanqual[],
                   starreal *outminqual,
                   bool desperate);







