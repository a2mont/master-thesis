/*****************************************************************************/
/*                                                                           */
/*  Convenience functions                                                    */
/*                                                                           */
/*****************************************************************************/

#include "util.h"
#include "anisotropy.h"
#include "vector.h"

starreal *get_attributes(tag vtag) {
  /* the parantheses around &improvebehave->mesh are necessary because tetcomplex2* is a badly written macro */
  return (starreal *) tetcomplextag2attributes((&improvebehave->mesh), vtag);  
}

starreal *get_coords(tag vtag) {
  /* the parantheses around &improvebehave->mesh are necessary because tetcomplex2* is a badly written macro */
  return ((struct vertex *) tetcomplextag2vertex((&improvebehave->mesh), vtag))->coord;
}

struct vertextype *get_info(int vtag) {
  return (struct vertextype *) arraypoolforcelookup(&improvebehave->vertexinfo, vtag);
}

void attrcopy(starreal *a1, starreal *a2) {
  int k;
  for (k = 0; k < improvebehave->attribcount; ++k) {
    a2[k] = a1[k];
  }  
}

void interpolateattributes(struct tetcomplex *mesh, int n, tag verts[], starreal weights[], starreal attributes[]) {
  int i;
  int k;
  
  for (k = 0; k < improvebehave->attribcount; ++k) {
    attributes[k] = 0;
  }
  
  for (i = 0; i < n; ++i) {
    /* replace attributes with new values */
    starreal *vattr = (starreal *) tetcomplextag2attributes(mesh, verts[i]);
    for (k = 0; k < improvebehave->attribcount; ++k) {
      attributes[k] += weights[i] * vattr[k];
    }    
  }
}

/* find the barycentric coordinates of x within v1-v2-v3-v4. */
void getbarycentriccoordinates(starreal v0[3], starreal v1[3], starreal v2[3], starreal v3[3], starreal x[3], starreal coordinates[4]) {
  starreal dif[3];
  starreal tmpB_Tet[9], baryMat[9], fDet;
  tmpB_Tet[0] = v1[0] - v0[0];
  tmpB_Tet[1] = v2[0] - v0[0];
  tmpB_Tet[2] = v3[0] - v0[0];
  
  tmpB_Tet[3] = v1[1] - v0[1];
  tmpB_Tet[4] = v2[1] - v0[1];
  tmpB_Tet[5] = v3[1] - v0[1];
  
  tmpB_Tet[6] = v1[2] - v0[2];
  tmpB_Tet[7] = v2[2] - v0[2];
  tmpB_Tet[8] = v3[2] - v0[2];
  
  /* Invert a 3x3 using cofactors.  This is faster than using a generic
   Gaussian elimination because of the loop overhead of such a method.
   */
  
  baryMat[0] = tmpB_Tet[4]*tmpB_Tet[8] - tmpB_Tet[5]*tmpB_Tet[7];
  baryMat[1] = tmpB_Tet[2]*tmpB_Tet[7] - tmpB_Tet[1]*tmpB_Tet[8];
  baryMat[2] = tmpB_Tet[1]*tmpB_Tet[5] - tmpB_Tet[2]*tmpB_Tet[4];
  baryMat[3] = tmpB_Tet[5]*tmpB_Tet[6] - tmpB_Tet[3]*tmpB_Tet[8];
  baryMat[4] = tmpB_Tet[0]*tmpB_Tet[8] - tmpB_Tet[2]*tmpB_Tet[6];
  baryMat[5] = tmpB_Tet[2]*tmpB_Tet[3] - tmpB_Tet[0]*tmpB_Tet[5];
  baryMat[6] = tmpB_Tet[3]*tmpB_Tet[7] - tmpB_Tet[4]*tmpB_Tet[6];
  baryMat[7] = tmpB_Tet[1]*tmpB_Tet[6] - tmpB_Tet[0]*tmpB_Tet[7];
  baryMat[8] = tmpB_Tet[0]*tmpB_Tet[4] - tmpB_Tet[1]*tmpB_Tet[3];
  
  fDet = tmpB_Tet[0]*baryMat[0] + tmpB_Tet[1]*baryMat[3] + tmpB_Tet[2]*baryMat[6];
  
  if (fabs(fDet) <= 1e-9) {
    baryMat[0] = 
    baryMat[1] = 
    baryMat[2] = 
    baryMat[3] = 
    baryMat[4] = 
    baryMat[5] = 
    baryMat[6] = 
    baryMat[7] =
    baryMat[8] = 0.0;
  } else {  
    int i;
    starreal invDet = 1.0/fDet;
    for (i = 0; i < 9; i++)
      baryMat[i] *= invDet;
  }
  
  /* compute coordinates */
  dif[0] = x[0] - v0[0];
  dif[1] = x[1] - v0[1];
  dif[2] = x[2] - v0[2];
  coordinates[1] = baryMat[0]*dif[0] + baryMat[1]*dif[1] + baryMat[2]*dif[2];
  coordinates[2] = baryMat[3]*dif[0] + baryMat[4]*dif[1] + baryMat[5]*dif[2];
  coordinates[3] = baryMat[6]*dif[0] + baryMat[7]*dif[1] + baryMat[8]*dif[2];
  coordinates[0] = 1.0 - (coordinates[1] + coordinates[2] + coordinates[3]);
}



int mytetcomplexconsistency(struct tetcomplex *plex) {
  struct tetcomplexposition pos;
  tag nexttet[4];
  arraypoolulong horrors;
  
  horrors = 0;
  tetcomplexiteratorinit(plex, &pos);
  tetcomplexiterateall(&pos, nexttet);
  while (nexttet[0] != STOP) {
    horrors += tetcomplexmissingtet(plex, nexttet[0], nexttet[2],
                                    nexttet[3], nexttet[1]);
    horrors += tetcomplexmissingtet(plex, nexttet[0], nexttet[3],
                                    nexttet[1], nexttet[2]);
    horrors += tetcomplexmissingtet(plex, nexttet[1], nexttet[2],
                                    nexttet[0], nexttet[3]);
    horrors += tetcomplexmissingtet(plex, nexttet[1], nexttet[3],
                                    nexttet[2], nexttet[0]);
    horrors += tetcomplexmissingtet(plex, nexttet[2], nexttet[3],
                                    nexttet[0], nexttet[1]);
    tetcomplexiterateall(&pos, nexttet);
  }
  
  /*if (horrors == 0) {
   printf("  Tremble before my vast wisdom, with which "
   "I find the mesh to be consistent.\n");
   } else if (horrors == 1) {
   printf("  !! !! !! !! Precisely one oozing cyst sighted.\n");
   } else {
   printf("  !! !! !! !! %d monstrosities witnessed.\n", horrors);
   }*/
  if (horrors == 0)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

/* copy the values from one array of points to the other */
void pointarraycopy(starreal A1[][3],
                    starreal A2[][3],
                    int length)
{
  memcpy(A2, A1, sizeof(starreal)*3*length);
}

/* function to sort the vertices of a tet */
#define swaptag(x, y) do {tag tmp; tmp = x; x = y; y = tmp; } while (0)
void sorttetverts(tag tet[4])
{
  if (tet[1] < tet[0]) swaptag(tet[1], tet[0]);
  if (tet[2] < tet[1]) swaptag(tet[2], tet[1]);
  if (tet[3] < tet[2]) swaptag(tet[3], tet[2]);
  if (tet[1] < tet[0]) swaptag(tet[1], tet[0]);
  if (tet[2] < tet[1]) swaptag(tet[2], tet[1]);
  if (tet[1] < tet[0]) swaptag(tet[1], tet[0]);
}

/* Compute the parity of the permutation of the array perm.
 The array should be length long, and contain integers from
 0 up to length -1. The even/oddness is in relation to the
 permutation frem 0...length-1, in order. It returns 0 if 
 perm is an even permutation, and 1 if it is odd */
int permutationparity(int *perm, int length)
{
  int inversions = 0; /* number of inversions */
  int i,j;            /* loop indices */
  
  for (i=0; i<length-1; i++)
  {
    for (j=i+1; j<length; j++)
    {
      /* check if i < j AND p(i) > p(j). If so, inversion */
      if (perm[i] > perm[j])
      {
        inversions++;
      }
    }
  }
  
  /* if there are an odd number of inversions, odd parity */
  return inversions % 2;
}

/* a new, faster way to test tet equivalence ? */
bool sametet(tag v11, tag v12, tag v13, tag v14,
             tag v21, tag v22, tag v23, tag v24)
{
  /* we just need to verify that every vertex in tet one is in
   tet two */
  if (
      (v11 == v21 || v11 == v22 || v11 == v23 || v11 == v24) &&
      (v12 == v21 || v12 == v22 || v12 == v23 || v12 == v24) &&
      (v13 == v21 || v13 == v22 || v13 == v23 || v13 == v24) &&
      (v14 == v21 || v14 == v22 || v14 == v23 || v14 == v24)
      )
  {
    return true;
  }
  return false;
}

/* tests whether the two tetrahedra are the same,
 where "sameness" is gauged by whether they share
 all the same vertices, and the orientation is the same.
 orientation being the same means that the order of the
 vertices of one is an even permutation of the other */
bool oldsametet(tag vtx11, tag vtx12, tag vtx13, tag vtx14,
                tag vtx21, tag vtx22, tag vtx23, tag vtx24)
{
  tag tet1sorted[4];
  tag tet2sorted[4];
  
  tet1sorted[0] = vtx11;
  tet1sorted[1] = vtx12;
  tet1sorted[2] = vtx13;
  tet1sorted[3] = vtx14;
  
  tet2sorted[0] = vtx21;
  tet2sorted[1] = vtx22;
  tet2sorted[2] = vtx23;
  tet2sorted[3] = vtx24;
  
  /* sort the vertices of each tet */
  sorttetverts(tet1sorted);
  sorttetverts(tet2sorted);
  
  /* make sure they both have the same vertices */
  if ( 
      (tet1sorted[0] != tet2sorted[0]) ||
      (tet1sorted[1] != tet2sorted[1]) ||
      (tet1sorted[2] != tet2sorted[2]) ||
      (tet1sorted[3] != tet2sorted[3])
      )
  {
    return false;
  }
  
  /* the rest is unnecessary because same verts but different
   parity implies that one of the tets is invalid anyway */
  return true;
}

/* determine of two sets of three tags represent
 the same oriented face, meaning that they have the
 same vertices and that the vertices come in the same
 order, with wrapping allowed. So (1,2,3) = (3,1,2). */
bool sameface(tag f11, tag f12, tag f13,
              tag f21, tag f22, tag f23)
{
  /* for speed, explicitly check all three possible 
   situations where the two faces are equal */
  if (
      ((f11 == f21) && (f12 == f22) && (f13 == f23)) ||
      ((f11 == f22) && (f12 == f23) && (f13 == f21)) ||
      ((f11 == f23) && (f12 == f21) && (f13 == f22))
      )
  {
    return true;
  }
  return false;
}

/* check whether the specified tet exists in the mesh. if it does, return 1.
 otherwise, return 0 */
int tetexists(struct tetcomplex *mesh, tag vtx1, tag vtx2, tag vtx3, tag vtx4)
{
  tag topbot[2];
  int foundface;
  int horrors = 0;
  
  foundface = tetcomplexadjacencies(mesh, vtx2, vtx3, vtx4, topbot);
  if (foundface == 0)
  {
    if (improvebehave->verbosity > 5)
    {
      printf("tet doesn't exist because face (%d %d %d) isn't found...\n", (int) vtx2, (int) vtx3, (int) vtx4);
    }
    return 0;
  }
  /* face was found... is top vertex correct? */
  if (topbot[0] != vtx1)
  {
    if (improvebehave->verbosity > 5)
    {
      printf("tet doesn't exist because top vertex doesn't match...\n");
    }
    return 0;
  }
  
  if (improvebehave->verbosity > 6)
  {
    printf("verified that tet with verts %d %d %d %d exists in mesh\n", (int) vtx1, (int) vtx2, (int) vtx3, (int) vtx4);
    printf("face %d %d %d was found and the vert opposite it was %d\n", (int) vtx2, (int) vtx3, (int) vtx4, (int) topbot[0]);
  }
  
  /* taken from tetcomplexconsistency(), except just checks one tet */
  if (IMPROVEPARANOID)
  {
    horrors += tetcomplexmissingtet(mesh, vtx1, vtx3,
                                    vtx4, vtx2);
    horrors += tetcomplexmissingtet(mesh, vtx1, vtx4,
                                    vtx2, vtx3);
    horrors += tetcomplexmissingtet(mesh, vtx2, vtx3,
                                    vtx1, vtx4);
    horrors += tetcomplexmissingtet(mesh, vtx2, vtx4,
                                    vtx3, vtx1);
    horrors += tetcomplexmissingtet(mesh, vtx3, vtx4,
                                    vtx1, vtx2);
    
    if (horrors != 0)
    {
      printf("everything was cool with your check but horrors != 0...\n");
      return 0;
    }
  }
  
  return 1;
}

/* wrapper for checking tet existence with an array */
int tetexistsa(struct tetcomplex *mesh, tag tet[4])
{
  return tetexists(mesh, tet[0], tet[1], tet[2], tet[3]);
}

/* get all the tets incident on vtx1 which is in the tet 
 (vtx1, vtx2, vtx3, vtx4). This function is recursive and
 should first be called with numincident = 0.
 return 0 if the number of incident tets exceed the
 maximum allowed. Set boundary flag if vertex lies on
 boundary (i.e., has at least one ghost tet incident) */
int getincidenttets(struct tetcomplex *mesh,
                    tag vtx1,
                    tag vtx2,
                    tag vtx3,
                    tag vtx4,
                    tag incidenttets[][4],
                    int *numincident,
                    bool *noghostflag)
{
  tag neightets[3][4];  /* neighbor tetrahedra */
  tag topbot[2];        /* the top and bottom vertices from adjacency query */
  int foundface;        /* checks whether adjacency query finds the face at all */
  tag neighfaces[3][4]; /* the three faces we want to check, last vertex is leftover */
  int i,j;              /* loop indices */
  bool visited = false; /* whether each neighbor has been visited */
  tag i2, i3, i4;       /* incident tet vertices, excluding central vertex */
  tag n2, n3, n4;       /* neighbor tet vertices, excluding central vertex */
  
  /* first, check to make sure this tet still exists in the mesh */
  if (tetexists(mesh, vtx1, vtx2, vtx3, vtx4) == 0)
  {
    return 0;
  }
  
  /* add the this tet to the list of incident tets */
  incidenttets[*numincident][0] = vtx1;
  incidenttets[*numincident][1] = vtx2;
  incidenttets[*numincident][2] = vtx3;
  incidenttets[*numincident][3] = vtx4;
  *numincident = (*numincident) + 1;
  
  /* check to make sure we aren't going crazy */
  if (*numincident > MAXINCIDENTTETS)
  {
    printf("when finding incident tets, exceeded %d tets, giving up\n", MAXINCIDENTTETS);
    return 0;
  }
  
  /* the three neighbor tets to this one that are also
   incident on vtx1 can be found using adjacency queries
   on the faces:
   
   (vtx1, vxt2, vtx3),
   (vtx1, vtx4, vtx2), and
   (vtx1, vtx3, vtx4).
   
   the "top" vertices from these queries will be apexes
   of the three adjoining tetrahedra. the "bottom" vertices
   will be the fourth vertex of the current tetrahedron.
   */
  neighfaces[0][0] = vtx1;
  neighfaces[0][1] = vtx2;
  neighfaces[0][2] = vtx3;
  neighfaces[0][3] = vtx4; /* should be the bottom vertex in adj query */
  
  neighfaces[1][0] = vtx1;
  neighfaces[1][1] = vtx4;
  neighfaces[1][2] = vtx2;
  neighfaces[1][3] = vtx3; /* should be the bottom vertex in adj query */
  
  neighfaces[2][0] = vtx1;
  neighfaces[2][1] = vtx3;
  neighfaces[2][2] = vtx4;
  neighfaces[2][3] = vtx2; /* should be the bottom vertex in adj query */
  
  /* for each neighbor face */
  for (i=0; i<3; i++)
  {
    /* make sure the original tet exists from this perspective */
    assert(tetexists(mesh,
                     neighfaces[i][3],
                     neighfaces[i][0],
                     neighfaces[i][2],
                     neighfaces[i][1]));
    
    foundface = tetcomplexadjacencies(mesh, 
                                      neighfaces[i][0], 
                                      neighfaces[i][1], 
                                      neighfaces[i][2], 
                                      topbot);
    
    /* check that the face was found */
    assert(foundface == 1);
    
    /* if any tet adjacent to this vertex is a ghost tet,
     set the boundary flag */
    if (topbot[0] == GHOSTVERTEX)
    {
      *noghostflag = false;
    }
    
    /* the bottom vertex was the other vertex in the tet */
    assert(topbot[1] == neighfaces[i][3]);
    
    
    /* otherwise, we've got a neighbor tet. To keep same vertex as vtx1,
     save this tet as (neigh[0], neigh[1], top, neigh[2].  */
    neightets[i][0] = neighfaces[i][0];
    neightets[i][1] = neighfaces[i][1];
    neightets[i][2] = topbot[0];
    neightets[i][3] = neighfaces[i][2];
    
  }
  
  /* now, figure out which neighbors we've visited */
  
  /* for each neighbor tet */
  for (i=0; i<3; i++)
  {
    /* if this neighbor tet is a ghost tet, no need to visit */
    if (neightets[i][2] == GHOSTVERTEX)
    {
      visited = true;
    }
    else
    {
      visited = false;
      
      /* get the vertices of this neighbor tet, excluding central vertex */
      n2 = neightets[i][1];
      n3 = neightets[i][2];
      n4 = neightets[i][3];
      
      /* for each tet visited so far */
      for (j=0; j<*numincident; j++)
      {
        /* get the vertices of this tet, excluding central vertex */
        i2 = incidenttets[j][1];
        i3 = incidenttets[j][2];
        i4 = incidenttets[j][3];
        
        /* is this tet the same as the current neighbor tet? */
        /* because we know that all of the tets have the same first
         vertex (the one we're find incident elements for), all
         we need to check whether the face vertices are the same,
         and that they come in the same order (wrapping allowed).
         This means that face (3,2,1) is the same as face (1,3,2) */
        if (sameface(n2,n3,n4, i2,i3,i4))
        {
          /* then mark this neighbor as visited and don't check any more */
          visited = true;
          break;
        } 
      }
    }
    
    /* if it hasn't been visited */
    if (visited != true)
    {
      /* find incident tets using DFS on it */
      getincidenttets(mesh, 
                      neightets[i][0], 
                      neightets[i][1], 
                      neightets[i][2],
                      neightets[i][3],
                      incidenttets,
                      numincident,
                      noghostflag);
    }
  }
  
  return 1;
}



/* determine if a tet has any boundary vertices.
 return the number of boundary verts as well as
 their tags in boundtags */
int boundverts(struct tetcomplex *mesh,
               tag vtx1,
               tag vtx2,
               tag vtx3,
               tag vtx4,
               tag boundtags[])
{
  int i,j,k,l;     /* loop indices */
  bool noghosts;   /* any ghost tets incident to this vertex? */
  tag tet[4];      /* array version of tet indices */
  int numincident; /* number of incident tets */
  int numbound=0;  /* number of boundary verts */
  /* a list of all the tets incident to this vertex */
  tag incidenttettags[MAXINCIDENTTETS][4];
  
  tet[0] = vtx1;
  tet[1] = vtx2;
  tet[2] = vtx3;
  tet[3] = vtx4;
  
  /* check each vertex */
  for (i = 0; i < 4; i++) 
  {
    j = (i + 1) & 3;
    if ((i & 1) == 0) {
      l = (i + 3) & 3;
      k = (i + 2) & 3;
    } else {
      l = (i + 2) & 3;
      k = (i + 3) & 3;
    }
    
    /* get all the tets incident to this vertex. */
    numincident = 0;
    noghosts = true;
    getincidenttets(mesh, 
                    tet[i],
                    tet[j],
                    tet[k],
                    tet[l], 
                    incidenttettags,
                    &numincident,
                    &noghosts);
    
    /* is this a boundary vertex? */
    if (noghosts == false)
    {
      boundtags[numbound] = tet[i];
      numbound++;
    }
  }
  
  return numbound;
}







/* Retrieve the ring of tetrahedra around a particular edge, and meanwhile
 detect whether it's a boundary edge. Potentially don't store the ring of
 tets if the array to store them is null. Return a boolean indicating 
 whether it is a bounary edge, as well as the third vertices of the boundary
 faces */
#define NOBOUNDFACE -2
bool getedgering(struct tetcomplex *mesh,
                 tag vtx1, /* first vertex of the edge */
                 tag vtx2, /* second vertex of the edge */
                 tag vtx3, /* third vertex of a tet that contains the edge */
                 tag vtx4, /* fourth vertex of a tet that contains the edge */
                 int *numringtets, /* number of tets in the ring */
                 tag ringtets[MAXRINGTETS][4], /* the vertices of tets in the ring */
                 tag boundfaceverts[2] /* the third vertex of the two boundary faces */
                 )
{
  tag ring[MAXRINGTETS]; /* array of tags for ring of vertices around edge */
  tag start;             /* the first vertex tag in an edge's ring */
  int ringcount = 0;     /* the number of vertices found in the ring so far */
  tag nextprev[2];       /* the next and previous vertices around the ring */
  int foundface;         /* indicates whether the face in the adj query exists */
  bool reverse = false;  /* for going back to find the other boundary face */
  bool forward = true;
  tag ev1, ev2;          /* first and second edge vertex */
  
  /* initialize boundary face vertex tags to cardinal value */
  boundfaceverts[0] = boundfaceverts[1] = (tag) NOBOUNDFACE;
  
  /* we will proceed around the ring of tets surrounding an edge by using
   repeated face adjancency queries until we reach the start of the ring
   again. If at any point we encounter a ghost tetrahedron, we'll know 
   that this edge must lie on the boundary, and to complete the ring we
   must return to the begining and proceed around the other direction */
  
  /* if we're recording the identity of the tets in the ring */
  if (numringtets != NULL)
  {
    *numringtets = 0;
    
    /* record the first tetrahedron in the ring, which is just
     the input tet. take care to record the edge verts as the
     first two */
    ringtets[*numringtets][0] = vtx1;
    ringtets[*numringtets][1] = vtx2;
    ringtets[*numringtets][2] = vtx3;
    ringtets[*numringtets][3] = vtx4;
    assert(tetexistsa(mesh, ringtets[*numringtets]));
    (*numringtets)++;
  }
  
  /* start by going one way around the edge. If we find a boundary face,
   then look back the other way */
  while (forward || reverse)
  {
    forward = false;
    
    /* the first vertex in the ring is set to another vertex in the
     current tet. We choose one that will orient the first face adjacency
     query out of the current tet: if the edge is ij, the third vertex is k
     swap order for reverse rotation. */
    start = (reverse) ? vtx4 : vtx3;
    ev1 = (reverse) ? vtx2 : vtx1;
    ev2 = (reverse) ? vtx1 : vtx2;
    ring[0] = start;
    ringcount = 0;
    
    /* now, use adjacency tests to move around the ring, until we get back where
     we started or the ring gets too big*/
    foundface = tetcomplexadjacencies(mesh, ev1, ev2, start, nextprev);
    assert(foundface == 1);
    assert(nextprev[1] == ((reverse) ? vtx3 : vtx4));
    
    /* check if we are at the boundary */
    if (nextprev[0] == GHOSTVERTEX)
    {
      /* record the identity of the face where we hit the boundary */
      if (reverse == false)
      {
        assert(boundfaceverts[0] == NOBOUNDFACE);
        boundfaceverts[0] = ring[ringcount];
      }
      else
      {
        assert(boundfaceverts[0] != NOBOUNDFACE);
        boundfaceverts[1] = ring[ringcount];
      }
      
      if (improvebehave->verbosity > 5)
      {
        printf("on first ring query found bound face with vert %d, reverse=%d\n", (int) ring[ringcount], (int) reverse);
      }
      
      /* if we aren't on a reverse run already, schedule one */
      reverse = (reverse) ? false : true;
      
      /* don't try to proceed any further around this ring */
      continue;
    }
    
    /* we found a legitimate tet next in the ring */
    ringcount++;
    
    /* as long as we don't complete the ring, keep moving around */
    while ((ringcount < MAXRINGTETS) && (nextprev[0] != start))
    {
      /* add the next vertex to the ring */
      ring[ringcount] = nextprev[0];
      
      /* record the new tet in the ring */
      if (numringtets != NULL)
      {
        /* we found a tet! record it the list of tets, always
         recording the two edge vertices first */
        ringtets[*numringtets][0] = ev1;
        ringtets[*numringtets][1] = ev2;
        ringtets[*numringtets][2] = ring[ringcount];
        ringtets[*numringtets][3] = ring[ringcount - 1];
        assert(tetexistsa(mesh, ringtets[*numringtets]));
        (*numringtets)++;
      }
      
      /* look for next vertex */
      foundface = tetcomplexadjacencies(mesh, ev1, ev2, nextprev[0], nextprev);
      assert(foundface == 1);
      assert(nextprev[1] == ring[ringcount-1]);
      
      /* check again for ghost vertex */
      if (nextprev[0] == GHOSTVERTEX)
      {
        /* record the identity of the face where we hit the boundary */
        if (reverse == false)
        {
          assert(boundfaceverts[0] == NOBOUNDFACE);
          boundfaceverts[0] = ring[ringcount];
        }
        else
        {
          assert(boundfaceverts[0] != NOBOUNDFACE);
          boundfaceverts[1] = ring[ringcount];
        }
        
        if (improvebehave->verbosity > 5)
        {
          printf("on query %d found bound face with vert %d, reverse=%d\n", (int) ringcount, (int) ring[ringcount], (int) reverse);
        }
        
        /* if we aren't on a reverse run already, schedule one */
        reverse = (reverse) ? false : true;
        
        /* stop looking in this direction */
        break;
      }
      
      ringcount++;
    }
  }
  
  assert(ringcount >= 0 && ringcount < MAXRINGTETS);
  
  /* we've now finished looking forward and potentially back around
   the edge. Return true if this is a boundary edge, false if not */
  if (boundfaceverts[0] != NOBOUNDFACE)
  {
    /* we must have found both boundary faces */
    assert(boundfaceverts[1] != NOBOUNDFACE);
    /* and they can't be the same */
    assert(boundfaceverts[0] != boundfaceverts[1]);
    
    return true;
  }
  return false;
}







/* returns the number of edges of this tet that lie on the boundary
 along with a list of them */
int boundedges(struct tetcomplex *mesh,
               tag vtx1,
               tag vtx2,
               tag vtx3,
               tag vtx4,
               tag edgelist[][2],
               tag edgefaces[6][2],
               int numedgetets[6],
               tag edgetets[6][MAXRINGTETS][4])
{
  tag tet[4];            /* the current tet we are trying to improve */
  int i,j,k,l;           /* loop indices for each tet vertex */
  int temp;
  bool boundedge;        /* whether a particular edge is a boundary edge */
  int numboundedges = 0; /* number of boundary edges found */
  
  tet[0] = vtx1;
  tet[1] = vtx2;
  tet[2] = vtx3;
  tet[3] = vtx4;
  
  
  for (i = 0; i < 3; i++) 
  {
    for (j = i + 1; j < 4; j++) 
    {
      k = (i > 0) ? 0 : (j > 1) ? 1 : 2;
      l = 6 - i - j - k;
      /* to get right sequence, need to swap k and l sometimes */
      if ((i+j) % 2 == 0)
      {
        temp = k;
        k = l;
        l = temp;
      }
      
      /* now our tet is (i,j,k,l). check if this is a boundary edge */
      boundedge = getedgering(mesh, tet[i], tet[j], tet[k], tet[l],
                              (numedgetets == NULL) ? NULL : &numedgetets[numboundedges],
                              edgetets[numboundedges], 
                              edgefaces[numboundedges]);
      /* if this was a boundary edge */
      if (boundedge)
      {
        /* save this edge in the list of boundary edges */
        edgelist[numboundedges][0] = tet[i];
        edgelist[numboundedges][1] = tet[j];
        numboundedges++;
      }
    }
  }
  
  return numboundedges;
}







/* determine if any of the faces of a tet lie on
 the boundary. if so, return true, and put
 the boundary faces in boundfaces */
bool boundfaces(struct tetcomplex *mesh,
                tag vtx1,
                tag vtx2,
                tag vtx3,
                tag vtx4,
                tag boundfaces[][3],
                int *numboundary)
{
  int foundface;
  tag topbot[2];
  
  *numboundary = 0;
  
  /* make sure this tet actually exists */
  assert(tetexists(mesh, vtx1, vtx2, vtx3, vtx4));
  
  /* check adjacencies of each face looking for ghost vertex */
  /* faces are oriented out from tet */
  foundface = tetcomplexadjacencies(mesh, vtx1, vtx2, vtx3, topbot);
  assert(foundface == 1);
  assert(topbot[1] == vtx4);
  if (topbot[0] == GHOSTVERTEX)
  {
    boundfaces[*numboundary][0] = vtx1;
    boundfaces[*numboundary][1] = vtx2;
    boundfaces[*numboundary][2] = vtx3;
    *numboundary = *numboundary + 1;
  }
  
  foundface = tetcomplexadjacencies(mesh, vtx1, vtx3, vtx4, topbot);
  assert(foundface == 1);
  assert(topbot[1] == vtx2);
  if (topbot[0] == GHOSTVERTEX)
  {
    boundfaces[*numboundary][0] = vtx1;
    boundfaces[*numboundary][1] = vtx3;
    boundfaces[*numboundary][2] = vtx4;
    *numboundary = *numboundary + 1;
  }
  
  foundface = tetcomplexadjacencies(mesh, vtx1, vtx4, vtx2, topbot);
  assert(foundface == 1);
  assert(topbot[1] == vtx3);
  if (topbot[0] == GHOSTVERTEX)
  {
    boundfaces[*numboundary][0] = vtx1;
    boundfaces[*numboundary][1] = vtx4;
    boundfaces[*numboundary][2] = vtx2;
    *numboundary = *numboundary + 1;
  }
  
  foundface = tetcomplexadjacencies(mesh, vtx2, vtx4, vtx3, topbot);
  assert(foundface == 1);
  assert(topbot[1] == vtx1);
  if (topbot[0] == GHOSTVERTEX)
  {
    boundfaces[*numboundary][0] = vtx2;
    boundfaces[*numboundary][1] = vtx4;
    boundfaces[*numboundary][2] = vtx3;
    *numboundary = *numboundary + 1;
  }
  
  if (*numboundary > 0)
  {
    return true;
  }
  else
  {
    return false;
  }
}








/* returns true if any of this tet's faces lie
 on the boundary */
bool boundtet(struct tetcomplex *mesh,
              tag vtx1,
              tag vtx2,
              tag vtx3,
              tag vtx4)
{
  tag boundfacetags[4][3];
  int numboundfaces;
  return (boundfaces(mesh, vtx1, vtx2, vtx3, vtx4, boundfacetags, &numboundfaces) == true);
}








/* generate a list of all boundary faces in the mesh */
void getsurface(struct tetcomplex *mesh,
                struct arraypool *facepool,
                int *numfaces)
{
  struct tetcomplexposition pos;
  tag tet[4];         /* current tet */
  tag tetfaces[4][3]; /* a list of boundary faces for the current tet */
  int numtetfaces;    /* the number of boundary faces for the current tet */
  int i;
  tag *newface;       /* pointer to new face in pool */
  
  *numfaces = 0;
  
  tetcomplexiteratorinit(mesh, &pos);
  tetcomplexiteratenoghosts(&pos, tet);
  
  /* get boundary faces of all tets */
  while (tet[0] != STOP) 
  {
    /* does this tet have any boundary faces? */
    if (boundfaces(mesh, tet[0], tet[1], tet[2], tet[3], tetfaces, &numtetfaces))
    {
      /* if so, copy them to the pool of surface faces */
      for (i=0; i<numtetfaces; i++)
      {
        /* allocate a new face in the array pool */
        newface = (tag *) arraypoolforcelookup(facepool, (unsigned long) *numfaces);
        
        /* assign vertices from this face */
        newface[0] = tetfaces[i][0];
        newface[1] = tetfaces[i][1];
        newface[2] = tetfaces[i][2];
        
        /* increment count of faces */
        *numfaces = *numfaces + 1;
      }
    }
    
    tetcomplexiteratenoghosts(&pos, tet);
  }
}









/* return the volume of a tetrahedron */
starreal tetvolume(struct tetcomplex *mesh,
                   tag vtx1,
                   tag vtx2,
                   tag vtx3,
                   tag vtx4)
{
  starreal point[4][3];      /* the vertices of the tet */
  
  tensortransformtet(mesh, vtx1, vtx2, vtx3, vtx4, point);
  
  /* calculate the volume of the tetrahedron */
  return orient3d(&improvebehave->behave, point[0], point[1], point[2], point[3]) / 6.0;
}









/* return the length of a tet's longest (shortest) edge,
 as well as the indices of its endpoints. "getlong" 
 argument set to true computes longest, otherwise shortest */
starreal tetedge(struct tetcomplex *mesh,
                 tag vtx1,
                 tag vtx2,
                 tag vtx3,
                 tag vtx4,
                 int edge[2],
                 bool getlong)
{
  int i,j;                  /* loop indices */
  starreal point[2][3];     /* the vertices of the tet */
  starreal length;          /* the current edge length */
  starreal longest;         /* the longest (shortest) edge */
  starreal edgev[3];
  tag tet[4];
  
  longest = (getlong) ? 0.0 : HUGEFLOAT;
  
  tet[0] = vtx1;
  tet[1] = vtx2;
  tet[2] = vtx3;
  tet[3] = vtx4;
  
  /* for each edge in the tet */
  for (i=0; i<3; i++)
  {
    for (j=i+1; j<4; j++)
    {
      tensortransformedge(mesh, tet[i], tet[j], point);
      vsub(point[0], point[1], edgev);
      length = vlength(edgev);
      
      if ((length > longest && getlong) || (length < longest && (!getlong)))
      {
        longest = length;
        edge[0] = i;
        edge[1] = j;
      }
    }
  }
  
  assert(longest > 0.0);
  return longest;
}






/* returns true if the tet (1,2,3,4) has
 positive orientation, and false otherwise */
bool positivetet(struct tetcomplex *mesh,
                 tag v1,
                 tag v2,
                 tag v3,
                 tag v4)
{
  return (orient3d(&improvebehave->behave,
                   ((struct vertex *) tetcomplextag2vertex(mesh, v1))->coord,
                   ((struct vertex *) tetcomplextag2vertex(mesh, v2))->coord,
                   ((struct vertex *) tetcomplextag2vertex(mesh, v3))->coord,
                   ((struct vertex *) tetcomplextag2vertex(mesh, v4))->coord) > 0);
}

/* convert from a sin of an angle to that angle in degrees (does not test obtuseness) */
starreal sintodeg(starreal insine)
{
  return asin(insine) * 180.0 / PI;
}

/* convert from an angle in degrees to sin */
starreal degtosin(starreal inangle)
{
  return sin((inangle) * (PI / 180.0));
}

starreal tantodeg(starreal intan)
{
  return atan(intan) * 180.0 / PI;
}

starreal radtodeg(starreal inangle)
{
  return (inangle * 180) / PI;
}

void textcolor(int attr, int fg, int bg)
{	char command[13];
  
	/* Command is the control command to the terminal */
	if (improvebehave->usecolor == true)
	{
    sprintf(command, "%c[%d;%d;%dm", 0x1B, attr, fg + 30, bg + 40);
    printf("%s", command);
	}
}

/* zero out the stats structure */
void initimprovestats(void)
{
  memset(&improvestats, 0, sizeof(struct improvestats));
}

int countverts(struct proxipool *vertpool)
{
  tag vertextag;
  int numverts = 0;
  vertextag = proxipooliterate(vertpool, NOTATAG);
  
  while (vertextag != NOTATAG)
  {
    numverts++;
    vertextag = proxipooliterate(vertpool, vertextag);
  }
  
  return numverts;
}

int counttets(struct tetcomplex *mesh)
{
  struct tetcomplexposition pos; /* position of iterator in the mesh */
  tag tet[4];
  int numtets = 1;
  
  /* initialize the iterator over the mesh */
  tetcomplexiteratorinit(mesh, &pos);
  /* retrieve the first tet in the mesh */
  tetcomplexiteratenoghosts(&pos, tet);
  
  /* for each tet */
  while (tet[0] != STOP) 
  {
    numtets++;
    tetcomplexiteratenoghosts(&pos, tet);
  }
  return numtets;
}

/* given two values a and b and their gradients, compute the 
 gradient of their product grad(a*b) */
void gradproduct(starreal a, 
                 starreal b, 
                 starreal grada[3],
                 starreal gradb[3],
                 starreal prod[3])
{
  prod[0] = grada[0] * b + gradb[0] * a;
  prod[1] = grada[1] * b + gradb[1] * a;
  prod[2] = grada[2] * b + gradb[2] * a;
}

/* given two values top and bottom and their gradients, compute the 
 gradient of their quotient grad(top / bottom) */
void gradquotient(starreal top, 
                  starreal bot, 
                  starreal gradtop[3],
                  starreal gradbot[3],
                  starreal quot[3])
{
  starreal denom = bot * bot;
  quot[0] = (bot * gradtop[0] - top * gradbot[0]) / denom;
  quot[1] = (bot * gradtop[1] - top * gradbot[1]) / denom;
  quot[2] = (bot * gradtop[2] - top * gradbot[2]) / denom;
}

starreal parallelepiped(const starreal *p0, const starreal *p1, const starreal *p2, const starreal *p3) {
  return orient3d(&improvebehave->behave, (starreal *)p0, (starreal *)p1, (starreal *)p2, (starreal *)p3);
}


