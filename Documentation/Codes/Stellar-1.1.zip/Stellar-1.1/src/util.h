#pragma once

#include "structs.h"

starreal *get_attributes(tag vtag);

starreal *get_coords(tag vtag);

struct vertextype *get_info(int vtag);

void attrcopy(starreal *a1, starreal *a2);

void interpolateattributes(struct tetcomplex *mesh, int n, tag verts[], starreal weights[], starreal attributes[]);

/* find the barycentric coordinates of x within v1-v2-v3-v4. */
void getbarycentriccoordinates(starreal v0[3], starreal v1[3], starreal v2[3], starreal v3[3], starreal x[3], starreal coordinates[4]);

int mytetcomplexconsistency(struct tetcomplex *plex);

/* copy the values from one array of points to the other */
void pointarraycopy(starreal A1[][3],
                    starreal A2[][3],
                    int length);

/* function to sort the vertices of a tet */
void sorttetverts(tag tet[4]);

/* Compute the parity of the permutation of the array perm.
 The array should be length long, and contain integers from
 0 up to length -1. The even/oddness is in relation to the
 permutation frem 0...length-1, in order. It returns 0 if 
 perm is an even permutation, and 1 if it is odd */
int permutationparity(int *perm, int length);

/* a new, faster way to test tet equivalence ? */
bool sametet(tag v11, tag v12, tag v13, tag v14,
             tag v21, tag v22, tag v23, tag v24);

/* determine of two sets of three tags represent
 the same oriented face, meaning that they have the
 same vertices and that the vertices come in the same
 order, with wrapping allowed. So (1,2,3) = (3,1,2). */
bool sameface(tag f11, tag f12, tag f13,
              tag f21, tag f22, tag f23);


/* check whether the specified tet exists in the mesh. if it does, return 1.
 otherwise, return 0 */
int tetexists(struct tetcomplex *mesh, tag vtx1, tag vtx2, tag vtx3, tag vtx4);

/* wrapper for checking tet existence with an array */
int tetexistsa(struct tetcomplex *mesh, tag tet[4]);

/* get all the tets incident on vtx1 which is in the tet 
 (vtx1, vtx2, vtx3, vtx4). This function is recursive and
 should first be called with numincident = 0.
 return 0 if the number of incident tets exceed the
 maximum allowed. Set boundary flag if vertex lies on
 boundary (i.e., has at least one ghost tet incident) */
int getincidenttets(struct tetcomplex *mesh,
                    tag vtx1,
                    tag vtx2,
                    tag vtx3,
                    tag vtx4,
                    tag incidenttets[][4],
                    int *numincident,
                    bool *noghostflag);


/* determine if a tet has any boundary vertices.
 return the number of boundary verts as well as
 their tags in boundtags */
int boundverts(struct tetcomplex *mesh,
               tag vtx1,
               tag vtx2,
               tag vtx3,
               tag vtx4,
               tag boundtags[]);

/* Retrieve the ring of tetrahedra around a particular edge, and meanwhile
 detect whether it's a boundary edge. Potentially don't store the ring of
 tets if the array to store them is null. Return a boolean indicating 
 whether it is a bounary edge, as well as the third vertices of the boundary
 faces */
bool getedgering(struct tetcomplex *mesh,
                 tag vtx1, /* first vertex of the edge */
                 tag vtx2, /* second vertex of the edge */
                 tag vtx3, /* third vertex of a tet that contains the edge */
                 tag vtx4, /* fourth vertex of a tet that contains the edge */
                 int *numringtets, /* number of tets in the ring */
                 tag ringtets[MAXRINGTETS][4], /* the vertices of tets in the ring */
                 tag boundfaceverts[2] /* the third vertex of the two boundary faces */
                 );

/* returns the number of edges of this tet that lie on the boundary
 along with a list of them */
int boundedges(struct tetcomplex *mesh,
               tag vtx1,
               tag vtx2,
               tag vtx3,
               tag vtx4,
               tag edgelist[][2],
               tag edgefaces[6][2],
               int numedgetets[6],
               tag edgetets[6][MAXRINGTETS][4]);

/* determine if any of the faces of a tet lie on
 the boundary. if so, return true, and put
 the boundary faces in boundfaces */
bool boundfaces(struct tetcomplex *mesh,
                tag vtx1,
                tag vtx2,
                tag vtx3,
                tag vtx4,
                tag boundfaces[][3],
                int *numboundary);



/* returns true if any of this tet's faces lie
 on the boundary */
bool boundtet(struct tetcomplex *mesh,
              tag vtx1,
              tag vtx2,
              tag vtx3,
              tag vtx4);



/* generate a list of all boundary faces in the mesh */
void getsurface(struct tetcomplex *mesh,
                struct arraypool *facepool,
                int *numfaces);

/* given the two vertices of a known boundary edge,
 compute the angle between it's two incident
 boundary faces */
starreal getboundaryedgeangle(struct tetcomplex *mesh,
                              tag v1,
                              tag v2,
                              tag vleft,
                              tag vright);


/* return the length of a tet's longest (shortest) edge,
 as well as the indices of its endpoints. "getlong" 
 argument set to true computes longest, otherwise shortest */
starreal tetedge(struct tetcomplex *mesh,
                 tag vtx1,
                 tag vtx2,
                 tag vtx3,
                 tag vtx4,
                 int edge[2],
                 bool getlong);


/* return the volume of a tetrahedron */
starreal tetvolume(struct tetcomplex *mesh,
                   tag vtx1,
                   tag vtx2,
                   tag vtx3,
                   tag vtx4);




/* returns true if the tet (1,2,3,4) has
 positive orientation, and false otherwise */
bool positivetet(struct tetcomplex *mesh,
                 tag v1,
                 tag v2,
                 tag v3,
                 tag v4);


/* convert from a sin of an angle to that angle in degrees (does not test obtuseness) */
starreal sintodeg(starreal insine);

/* convert from an angle in degrees to sin */
starreal degtosin(starreal inangle);

starreal tantodeg(starreal intan);
starreal radtodeg(starreal inangle);


/* for printing color in output to the screen */
#define RESET		0
#define BRIGHT 		1
#define DIM         2
#define UNDERLINE 	3
#define BLINK		4
#define REVERSE		7
#define HIDDEN		8

#define BLACK 		0
#define RED		    1
#define GREEN		2
#define YELLOW		3
#define BLUE		4
#define MAGENTA		5
#define CYAN		6
#define	WHITE		7

void textcolor(int attr, int fg, int bg);

/* zero out the stats structure */
void initimprovestats(void);

int countverts(struct proxipool *vertpool);

int counttets(struct tetcomplex *mesh);

/* given two values a and b and their gradients, compute the 
 gradient of their product grad(a*b) */
void gradproduct(starreal a, 
                 starreal b, 
                 starreal grada[3],
                 starreal gradb[3],
                 starreal prod[3]);

/* given two values top and bottom and their gradients, compute the 
 gradient of their quotient grad(top / bottom) */
void gradquotient(starreal top, 
                  starreal bot, 
                  starreal gradtop[3],
                  starreal gradbot[3],
                  starreal quot[3]);

/* compute the volume of the parallelepiped spanned by the given points */
starreal parallelepiped(const starreal *p0, const starreal *p1, const starreal *p2, const starreal *p3);

