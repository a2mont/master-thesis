#pragma once

#include "structs.h"

/* compute the dot product of two vectors u and v */
starreal dot(starreal u[3],
             starreal v[3]);

/*
 given two normalized normals, return whether the planes are coplanar (without respect for orientation)
 */
bool coplanar(starreal n1[3], starreal n2[3]);  

/* compute the cross product of two vectors u and v */
void cross(starreal u[3],
           starreal v[3],
           starreal prod[3]);

/* scale a vector by a constant */
void vscale(starreal scale,
            starreal v[3],            
            starreal scaled[3]);

/* add two vectors u and v */
void vadd(starreal u[3],
          starreal v[3],
          starreal sum[3]);

/* subtract two vectors u and v */
void vsub(const starreal u[3],
          const starreal v[3],
          starreal sum[3]);

/* copy one vector's values into another */
void vcopy(starreal u[3],
           starreal v[3]);

/* return the length of a vector */
starreal vlength(starreal u[3]);

/* return if u and v are the same vector, false otherwise */
bool vequal(starreal u[3],
            starreal v[3]);

/* compute the euclidean distance between two points u and v */
starreal vdist(starreal u[3],
               starreal v[3]);

/* project the vector u onto the vector v */
void vproject(starreal u[3],
              starreal v[3],
              starreal vout[3]);

/* project the vector v onto the plane through the origin with normal n */
void vprojecttoplane(starreal v[3],
                     starreal n[3],
                     starreal vout[3]);
